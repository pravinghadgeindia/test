using System;
using System.Collections.Generic;
using System.Text;

namespace Packing
{
    class GlobalVariables
    {
        #region Global Variable

        private static bool oboolCFLSelected;
        private static int iRowNo, iColNo;
        private static string sBaseFormUID;

        #endregion


        #region Variables

        public static bool boolCFLSelected
        {
            get { return oboolCFLSelected; }
            set { oboolCFLSelected = value; }
        }

        public static int RowNo
        {
            get { return iRowNo; }
            set { iRowNo = value; }
        }

        public static int ColNo
        {
            get { return iColNo; }
            set { iColNo = value; }
        }

        public static string BaseFormUID
        {
            get { return sBaseFormUID; }
            set { sBaseFormUID = value; }
        }
        #endregion

    }
}

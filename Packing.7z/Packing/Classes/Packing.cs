﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Xml;
using System.Threading;
using System.Windows.Forms;
using System.Collections;
using System.Globalization;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.Net;
using System.Drawing;
using System.Diagnostics;
using System.Timers;
using System.Net.Mail;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Microsoft.Win32;
using Packing.Transactions;

namespace Packing
{
    class Packing
    {
        #region Variable
        public bool lost = true;
        public static SAPbouiCOM.Application SBO_Application;
        public static SAPbobsCOM.Company oCompany = null;
        System.Globalization.DateTimeFormatInfo dtformat = new System.Globalization.DateTimeFormatInfo();
        DataAcessLayer oDAL = new DataAcessLayer();
        SqlCommand cmd = new SqlCommand();

        public bool CRMEntry;
        public bool BPPresent = false;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.Form xForm;
        private SAPbouiCOM.Item oItem;
        string[,] ArrayBP = new string[10, 2];
        public string VarCost = "";
        public string FactCost = "";

        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.ComboBox oCombo;
        private SAPbouiCOM.CheckBox oCheckBox;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Column oColumn;
        private SAPbouiCOM.Columns oColumns;

        public SAPbouiCOM.DataTable oDataTable = null;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbobsCOM.Recordset InsertRec = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromListCollection oCFLs = null;
        public SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams = null;
        public SAPbouiCOM.IChooseFromListEvent oCFLE = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Condition oCon = null;
        public bool CatlogChecked = false;
        public bool Update = false;
        public static SAPbobsCOM.Recordset oRs;
        public string UserIdLogin = null;
        public string UserIdName = null;
        public string UserDiv = null;
        public string UserDesignation = null;

        public static string c_ip = "";
        public static string c_user = "";
        public static string c_pass = "";
        public static string c_location = "";
        public static string fgd_doc = "";

        public static int selrow = 0;

        public int SerNo = 0;
        public string SerName = "";

        public static string DBName, ServerName = null;
        public string Series = "";
        public static bool chkrate = false;

        public string Docentry;
        public string DocNum;
        public string VendCd;
        public string VendNm;
        public string Label;
        public string ProgramSerial;

        public static string ParentForm;
        public static int parentformcnt;
        public static string batchnum = "";
        public static string ParentFormBatch = "";
        public static string ParentFormBatch_Creation = "";
        public static int ParentFormBatch_Creation_count = 0;
        public static string QuantityBatch = "";
        public static string ParentForm_CFPO = "";
        public static int ParentCount_CFPO = 0;

        public static string[] batch_debit = new string[5000];
        public static string[] qty_debit = new string[5000];
        public static int debit_cnt = 0;
        public static int PrgSheet_CurrentRow = 0;

        public static int ParentCount_PackDet = 0;
        public static string ParentForm_PackDet = "";

        public static string OPCH_Series = "";
        public static string OPCH_DocNum = "";

        public static string[] batch_Transporter = new string[5000];
        public static string[] batch_LRNO = new string[5000];
        public static string[] batch_LRDT = new string[5000];
        public static string[] batch_PartyChallan = new string[5000];
        public static string[] batch_Pcs = new string[5000];
        public static string[] batch_StartBale = new string[5000];
        public static string[] batch_EndBale = new string[5000];
        public static string[] batch_batch = new string[5000];
        public static bool batch_Excess = false;
        public static int batch_cnt = 0;

        public static string[] IT_batch = new string[5000];
        public static int IT_batch_cnt = 0;

        public static string whse = "";

        public static int ParentCount_ServiceItem = 0;

        Checking objChecking = new Checking();
        Cutting objCutting = new Cutting();
        StdPack objStdPack = new StdPack();
        ExtPack objExtPack = new ExtPack();

        #endregion

        #region Constructor
        public Packing()
        {
            try
            {
                SetApplication();
                Setconnection();

                DBName = SBO_Application.Company.DatabaseName; //Database Name            
                ServerName = SBO_Application.Company.ServerName;//Server Name
                SetFilters();

                //Event handlers 
                SBO_Application.ItemEvent += new SAPbouiCOM._IApplicationEvents_ItemEventEventHandler(SBO_Application_ItemEvent);
                SBO_Application.MenuEvent += new SAPbouiCOM._IApplicationEvents_MenuEventEventHandler(SBO_Application_MenuEvent);
                SBO_Application.AppEvent += new SAPbouiCOM._IApplicationEvents_AppEventEventHandler(SBO_Application_AppEvent);
                SBO_Application.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(SBO_Application_FormDataEvent);
                SBO_Application.LayoutKeyEvent += new SAPbouiCOM._IApplicationEvents_LayoutKeyEventEventHandler(SBO_Application_LayoutKeyEvent);
                //SBO_Application.LayoutKeyEvent += new SAPbouiCOM._IApplicationEvents_LayoutKeyEventEventHandler(LayoutKeyEvent);

                try
                {
                    AddMenuItems();
                }
                catch
                { }
                //SBO_Application.MessageBox("SubContracting Add-On Connected...!", 1, "ok", "", "");
                SBO_Application.StatusBar.SetText("SubContracting Add-On Connected.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);


            }
            catch (Exception ex)
            {
                //SBO_Application.StatusBar.SetText(ex.Message.ToString(), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }
        #endregion

        #region connection

        public void Setconnection()
        {
            try
            {
                string sCookie;
                string sConnectionContext;

                // First initialize the Company object
                oCompany = new SAPbobsCOM.Company();
                if (oCompany.Connected == true)
                    return;

                sCookie = oCompany.GetContextCookie();
                sConnectionContext = SBO_Application.Company.GetConnectionContext(sCookie);
                oCompany.SetSboLoginContext(sConnectionContext);
                int i = oCompany.Connect();
                if (i != 0)
                {
                    SBO_Application.MessageBox("Setconnection(): " + oCompany.GetLastErrorCode() + " : " + oCompany.GetLastErrorDescription());
                    SBO_Application.StatusBar.SetText("Setconnection(): " + oCompany.GetLastErrorCode() + " : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                }
            }
            catch (Exception ex)
            {
                SBO_Application.StatusBar.SetText("Setconnection(): " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void SetFilters()
        {
            //oFilters = new SAPbouiCOM.EventFilters();

            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_LOAD);

            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_MENU_CLICK);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_CLICK);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_COMBO_SELECT);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_KEY_DOWN);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_VALIDATE);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_CLOSE);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_LOST_FOCUS);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_GOT_FOCUS);
            //oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED);
            ////oFilter.AddEx("frmJobN");


            //SBO_Application.SetFilter(oFilters);
        }

        private void SetApplication()
        {
            SAPbouiCOM.SboGuiApi SboGuiApi = null;
            string sConnectionString = null;
            SboGuiApi = new SAPbouiCOM.SboGuiApi();
            sConnectionString = System.Convert.ToString(Environment.GetCommandLineArgs().GetValue(1));
            //sConnectionString = "0030002C0030002C00530041005000420044005F00440061007400650076002C0050004C006F006D0056004900490056";
            try
            {
                // If there's no active application the connection will fail
                SboGuiApi.Connect(sConnectionString);
            }
            catch
            { //  Connection failed
                System.Windows.Forms.MessageBox.Show("No SAP Business One Application was found");
                System.Environment.Exit(0);
            }
            // get an initialized application object
            SBO_Application = SboGuiApi.GetApplication(-1);
        }

        #endregion

        #region AddMenuItems
        private void AddMenuItems()
        {
            string sPath = null;
            SAPbouiCOM.Menus oMenus = null;
            SAPbouiCOM.MenuItem oMenuItem = null;
            SAPbouiCOM.MenuCreationParams oCreationPackage = null;

            oMenus = SBO_Application.Menus;
            oCreationPackage = ((SAPbouiCOM.MenuCreationParams)(SBO_Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_MenuCreationParams)));



            oMenuItem = SBO_Application.Menus.Item("43525");
            oMenus = oMenuItem.SubMenus;
            ////Create s sub menu 
            oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
            oCreationPackage.UniqueID = "Initialize";
            oCreationPackage.String = "Initialize Database";
            oCreationPackage.Position = 0;
            if (!oMenus.Exists("Initialize"))
            {
                oMenus.AddEx(oCreationPackage);
            }

            oMenuItem = SBO_Application.Menus.Item("43520");
            oMenus = oMenuItem.SubMenus;
            ////Create s sub menu 
            oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_POPUP;
            oCreationPackage.UniqueID = "Sub";
            oCreationPackage.String = "Sub Contracting";
            oCreationPackage.Image = Application.StartupPath + "\\sub.bmp";
            oCreationPackage.Position = 14;
            if (!oMenus.Exists("Sub"))
            {
                oMenus.AddEx(oCreationPackage);
            }

            if (!oMenus.Exists("Sub"))
            {
                oMenus.AddEx(oCreationPackage);
            }

            //oMenuItem = SBO_Application.Menus.Item("Sub");
            //oMenus = oMenuItem.SubMenus;
            //////Create s sub menu 
            //oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
            //oCreationPackage.UniqueID = "PackingCredit";
            //oCreationPackage.String = "Packing Credit";
            //oCreationPackage.Position = 1;
            //if (!oMenus.Exists("PackingCredit"))
            //{
            //    oMenus.AddEx(oCreationPackage);
            //}

            oMenuItem = SBO_Application.Menus.Item("Sub");
            oMenus = oMenuItem.SubMenus;
            ////Create s sub menu 
            oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
            oCreationPackage.UniqueID = "OPST";
            oCreationPackage.String = "Program Sheet";
            oCreationPackage.Position = 1;
            if (!oMenus.Exists("OPST"))
            {
                oMenus.AddEx(oCreationPackage);
            }
            ////Create s sub menu 
            oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
            oCreationPackage.UniqueID = "Checking";
            oCreationPackage.String = "Checking";
            oCreationPackage.Position = 2;
            if (!oMenus.Exists("Checking"))
            {
                oMenus.AddEx(oCreationPackage);
            }

            oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
            oCreationPackage.UniqueID = "Cutting";
            oCreationPackage.String = "Cutting";
            oCreationPackage.Position = 3;
            if (!oMenus.Exists("Cutting"))
            {
                oMenus.AddEx(oCreationPackage);
            }

            oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
            oCreationPackage.UniqueID = "StdPack";
            oCreationPackage.String = "Standard Packing";
            oCreationPackage.Position = 4;
            if (!oMenus.Exists("StdPack"))
            {
                oMenus.AddEx(oCreationPackage);
            }

            oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
            oCreationPackage.UniqueID = "ExtPack";
            oCreationPackage.String = "Extra Packing";
            oCreationPackage.Position = 5;
            if (!oMenus.Exists("ExtPack"))
            {
                oMenus.AddEx(oCreationPackage);
            }
        }
        #endregion

        #region Events

        #region ItemEvents
        private void SBO_Application_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Create CFL via CFL Table Before action true
                if ((pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.BeforeAction == true) || (pVal.EventType == SAPbouiCOM.BoEventTypes.et_GOT_FOCUS && pVal.BeforeAction == false))
                {
                    oForm = SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                    string fieldonmatrix = "H";
                    string cflid = "";

                    if (pVal.ColUID != "")
                    {
                        fieldonmatrix = "M";
                        cflid = oDAL.ExSelect("select Code from [@CFL] where U_FormId='" + pVal.FormTypeEx + "' and U_FieldId='" + pVal.ItemUID + "' and U_ColUID='" + pVal.ColUID + "'", "");
                    }
                    else
                    {
                        cflid = oDAL.ExSelect("select Code from [@CFL] where U_FormId='" + pVal.FormTypeEx + "' and U_FieldId='" + pVal.ItemUID + "'", "");
                    }

                    if (cflid != "")
                    {
                        SAPbobsCOM.Recordset oRS_CFL = null;
                        oRS_CFL = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        string strSQL = null;
                        strSQL = "select * from [@CFL] where Code='" + cflid + "'";
                        oRS_CFL.DoQuery(strSQL);
                        if (oRS_CFL.RecordCount > 0)
                        {
                            try
                            {
                                #region add cfl
                                SAPbouiCOM.ChooseFromListCollection oCFLs;
                                oCFLs = oForm.ChooseFromLists;

                                SAPbouiCOM.ChooseFromList oCFL;
                                SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams;
                                oCFLCreationParams = (SAPbouiCOM.ChooseFromListCreationParams)Packing.SBO_Application.CreateObject

                                (SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams);

                                oCFLCreationParams.MultiSelection = false;
                                oCFLCreationParams.ObjectType = oRS_CFL.Fields.Item("U_ObjectCode").Value.ToString(); //my user-defined object code
                                oCFLCreationParams.UniqueID = cflid;

                                oCFL = oCFLs.Add(oCFLCreationParams);
                                string ItemUID = oRS_CFL.Fields.Item("U_FieldId").Value.ToString();
                                string ObjectFieldCode = oRS_CFL.Fields.Item("U_ObjectField").Value.ToString();
                                if (fieldonmatrix == "M")
                                {
                                    string ColUID = oRS_CFL.Fields.Item("U_ColUID").Value.ToString();
                                    oMatrix = oForm.Items.Item(ItemUID).Specific;
                                    oColumns = oMatrix.Columns;
                                    oColumn = oColumns.Item(ColUID);
                                    oColumn.ChooseFromListUID = cflid;
                                    oColumn.ChooseFromListAlias = ObjectFieldCode;
                                }
                                else
                                {
                                    oEdit = oForm.Items.Item(ItemUID).Specific;
                                    oEdit.ChooseFromListUID = cflid;
                                    oEdit.ChooseFromListAlias = ObjectFieldCode;
                                }
                                #endregion
                            }
                            catch { }
                        }
                    }

                }
                #endregion

                #region Xhoose from list Before ction False for CFL Table
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.BeforeAction == false)
                {
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    string sCFL_ID = null;
                    sCFL_ID = oCFLEvento.ChooseFromListUID;

                    string CFL_ID = oDAL.ExSelect("Select Code From [@CFL] where Code='" + sCFL_ID + "'", "");
                    if (CFL_ID != "")
                    {
                        oForm = SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                        SAPbobsCOM.Recordset oRS_CFL = null;
                        oRS_CFL = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        string strSQL = null;
                        strSQL = "select * from [@CFL] where Code='" + CFL_ID + "'";
                        oRS_CFL.DoQuery(strSQL);
                        if (oRS_CFL.RecordCount > 0)
                        {
                            try
                            {
                                string val1 = null;
                                string val2 = null;

                                string Field1 = oRS_CFL.Fields.Item("U_FieldId").Value.ToString();
                                string Field2 = oRS_CFL.Fields.Item("U_FieldId2").Value.ToString();
                                string OField1 = oRS_CFL.Fields.Item("U_ObjectField").Value.ToString();
                                string OField2 = oRS_CFL.Fields.Item("U_ObjectField2").Value.ToString();


                                SAPbouiCOM.ChooseFromList oCFL = null;
                                oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                                SAPbouiCOM.DataTable oDataTable = null;
                                oDataTable = oCFLEvento.SelectedObjects;


                                val1 = oDataTable.GetValue(OField1, 0).ToString();
                                if (OField2 != "")
                                    val2 = oDataTable.GetValue(OField2, 0).ToString();

                                SAPbouiCOM.EditText oEdit1 = null;
                                if (pVal.ColUID != "")
                                {
                                    oMatrix = oForm.Items.Item(pVal.ItemUID).Specific;
                                    oEdit = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row));
                                    if (OField2 != "")
                                        oEdit1 = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(Field2, pVal.Row));
                                }
                                else
                                {
                                    oEdit = ((SAPbouiCOM.EditText)oForm.Items.Item(pVal.ItemUID).Specific);
                                    if (OField2 != "")
                                        oEdit1 = ((SAPbouiCOM.EditText)oForm.Items.Item(Field2).Specific);
                                }

                                try
                                {
                                    oEdit.Value = val1;

                                }
                                catch { }

                                try
                                {
                                    oEdit1.Value = val2;

                                }
                                catch { }
                            }
                            catch
                            {

                            }

                        }
                    }
                }
                #endregion

                if (pVal.FormTypeEx == "UDO_FT_TDSLIMIT" && pVal.BeforeAction == true && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
                {

                }

                #region Customized forms
                switch (FormUID)
                {

                    case "PackingCredit":
                        Transactions.PackingCredit pc = new Transactions.PackingCredit();
                        pc.itemevent(ref pVal);

                        break;

                    case "OPST":
                        Transactions.ProgramSheet psh = new Transactions.ProgramSheet();
                        BubbleEvent = psh.itemevent(ref pVal);

                        break;

                    case "CFPO":
                        Transactions.CFPO Cfp = new Transactions.CFPO();
                        BubbleEvent = Cfp.itemevent(ref pVal);

                        break;

                    case "OFT":
                        Transactions.OFD fd = new Transactions.OFD();
                        BubbleEvent = fd.itemevent(ref pVal);

                        break;

                    case "PPS":
                        Transactions.PPS ps = new Transactions.PPS();
                        ps.itemevent(ref pVal,out BubbleEvent);

                        break;

                    case "PendingDebitNote":
                        Transactions.PendingDebitNote pdn = new Transactions.PendingDebitNote();
                        BubbleEvent = pdn.itemevent(ref pVal);
                        break;

                    case "PST1D":
                        Transactions.OtherDetail od = new Transactions.OtherDetail();
                        BubbleEvent = od.itemevent(ref pVal);
                        break;

                    case "OPCKDT":
                        Transactions.PackingDetails PackD = new Transactions.PackingDetails();
                        BubbleEvent = PackD.itemevent(ref pVal);
                        break;

                    case "ServiceItem":
                        Transactions.ServiceBill SB = new Transactions.ServiceBill();
                        BubbleEvent = SB.itemevent(ref pVal);
                        break;

                    case "IT_Transfer":
                        Transactions.IT_Copy ITC = new Transactions.IT_Copy();
                        BubbleEvent = ITC.itemevent(ref pVal);
                        break;

                    case "Ready":
                        Transactions.Ready rd = new Transactions.Ready();
                        BubbleEvent = rd.itemevent(ref pVal);
                        break;

                    case "Checking":
                        objChecking.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "Cutting":
                        objCutting.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "StdPack":
                        objStdPack.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "ExtPack":
                        objExtPack.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;
                }
                #endregion

                #region Business partner Create warehouse
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.FormTypeEx == "134" && pVal.ItemUID == "1" && pVal.BeforeAction == true)
                {
                    oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    xForm = Packing.SBO_Application.Forms.GetForm("-134", pVal.FormTypeCount);
                    string existwhsname = ((SAPbouiCOM.EditText)xForm.Items.Item("U_Whse").Specific).Value.ToString();
                    string whsYesNo = ((SAPbouiCOM.ComboBox)xForm.Items.Item("U_JobWork").Specific).Value.ToString();

                    if ((oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) && existwhsname == "" && whsYesNo.Trim() == "Yes")
                    {
                        string whsname = ((SAPbouiCOM.EditText)oForm.Items.Item("7").Specific).Value.ToString();
                        string whscode = oDAL.ExSelect("select count(*)+1 from OWHS", "");

                        SAPbobsCOM.Warehouses wharehouse = (SAPbobsCOM.Warehouses)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oWarehouses);
                        //fill the fields that you need
                        wharehouse.WarehouseCode = whscode; //this field is mandatory
                        wharehouse.WarehouseName = whsname;
                        wharehouse.Location = 2;
                        wharehouse.EnableBinLocations = SAPbobsCOM.BoYesNoEnum.tYES;

                        string errorMsg = string.Empty;
                        if (wharehouse.Add() != 0)
                            errorMsg = oCompany.GetLastErrorDescription();
                        else
                        {

                            ((SAPbouiCOM.EditText)xForm.Items.Item("U_Whse").Specific).Value = whscode;
                        }

                        SAPbobsCOM.Recordset oRS_Process = null;
                        oRS_Process = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        string strSQL = null;
                        strSQL = "select WhsCode from OWHS where BinActivat='N'";
                        oRS_Process.DoQuery(strSQL);
                        //strSeries = "";
                        if (oRS_Process.RecordCount > 0)
                        {
                            for (int i = 0; i < oRS_Process.RecordCount; i++)
                            {
                                string whseCode = oRS_Process.Fields.Item("WhsCode").Value.ToString();
                                wharehouse = null;
                                wharehouse = (SAPbobsCOM.Warehouses)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oWarehouses);
                                //fill the fields that you need
                                wharehouse.GetByKey(whseCode);
                                //wharehouse.Location = 2;
                                wharehouse.EnableBinLocations = SAPbobsCOM.BoYesNoEnum.tYES;

                                errorMsg = string.Empty;
                                if (wharehouse.Update() != 0)
                                    errorMsg = oCompany.GetLastErrorDescription();


                                oRS_Process.MoveNext();
                            }
                        }

                    }
                }
                #endregion

                #region quantity validation
                //if (pVal.BeforeAction == true && pVal.EventType==SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
                //{ }
                //if (FormUID=="CFPO" && pVal.ItemUID == "2" && (pVal.ColUID == "V_9" || pVal.ColUID == "V_11" || pVal.ColUID == "V_13" || pVal.ColUID == "V_15") && pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE && pVal.BeforeAction == true)
                //{
                //    oMatrix = oForm.Items.Item("2").Specific;
                //    string openmeter = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value.ToString();
                //    string openBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", pVal.Row)).Value.ToString();
                //    string openPcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", pVal.Row)).Value.ToString();
                //    string openYard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", pVal.Row)).Value.ToString();

                //    string Actmeter = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).Value.ToString();
                //    string ActBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", pVal.Row)).Value.ToString();
                //    string ActPcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", pVal.Row)).Value.ToString();
                //    string ActYard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", pVal.Row)).Value.ToString();

                //    if (pVal.ColUID == "V_9" && (Convert.ToDouble(openmeter) > Convert.ToDouble(Actmeter)))
                //    {
                //        int res = Packing.SBO_Application.MessageBox("Access Qty Found. Do you want to Continue?", 2, "Yes", "No", "");
                //        if (res == 2)
                //        {
                //            BubbleEvent= false;
                //        }
                //    }



                //}

                #endregion

                #region PO Quantity validation
                if (pVal.FormTypeEx == "142" && pVal.ItemUID == "1" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.BeforeAction == true)
                {
                    oForm = SBO_Application.Forms.GetForm("142", pVal.FormTypeCount);
                    oMatrix = oForm.Items.Item("38").Specific;
                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                    {
                        for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                        {
                            string icode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).Value.ToString();
                            string SUOM = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_SUOM", i)).Selected.Value.ToString();
                            if (icode != "" && SUOM != "" && SUOM != "-" && SUOM != "Mtr")
                            {
                                string qty = "";
                                string col = "";
                                if (SUOM == "Pcs")
                                {
                                    qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", i)).Value.ToString();
                                    col = "U_Pcs";
                                }
                                else if (SUOM == "Bale")
                                {
                                    qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", i)).Value.ToString();
                                    col = "U_Bale";
                                }
                                else if (SUOM == "Yard")
                                {
                                    qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", i)).Value.ToString();
                                    col = "U_Yard";

                                }
                                if (Convert.ToDouble((qty == "") ? "0" : qty) <= 0)
                                {
                                    oMatrix.Columns.Item(col).Cells.Item(i).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    SBO_Application.StatusBar.SetText("Please enter " + col.Replace("U_", "") + " Qty ", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }
                            }
                        }
                    }
                }


                #endregion

                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.FormTypeEx == "139" && pVal.BeforeAction == true && pVal.ItemUID == "10000329")
                {
                    oForm = Packing.SBO_Application.Forms.GetForm("139", pVal.FormTypeCount);
                    oCombo = oForm.Items.Item("10000329").Specific;
                    oCombo.ValidValues.Add("Program Sheet", "Program Sheet");
                }

                if (pVal.FormTypeEx == "940")
                {
                    Transactions.SockTransfer ST = new Transactions.SockTransfer();
                    BubbleEvent = ST.itemevent(ref pVal);
                }

                if (pVal.FormTypeEx == "134")
                {
                    Transactions.BPMaster BP = new Transactions.BPMaster();
                    BubbleEvent = BP.itemevent(ref pVal);
                }

                if (pVal.FormTypeEx == "60504")
                {
                    Transactions.WtaxCalculation wtax = new Transactions.WtaxCalculation();
                    BubbleEvent = wtax.itemevent(ref pVal);
                }

                if (pVal.FormTypeEx == "UDO_FT_TDSLIMIT")
                {
                    Transactions.TDSLIMIT TDS = new Transactions.TDSLIMIT();
                    BubbleEvent = TDS.itemevent(ref pVal);
                }

                else if (pVal.FormTypeEx == "42")
                {
                    Transactions.BatchSelection BS = new Transactions.BatchSelection();
                    BubbleEvent = BS.itemevent(ref pVal);
                }
                else if (pVal.FormTypeEx == "41")
                {
                    Transactions.BatchCreation BC = new Transactions.BatchCreation();
                    BubbleEvent = BC.itemevent(ref pVal);
                }
                else if (pVal.FormTypeEx == "141")
                {
                    Transactions.APInvoice API = new Transactions.APInvoice();
                    BubbleEvent = API.itemevent(ref pVal);
                }
                else if (pVal.FormTypeEx == "143")
                {
                    Transactions.GRN GRN = new Transactions.GRN();
                    BubbleEvent = GRN.itemevent(ref pVal);
                }

                #region Load form data
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD && pVal.BeforeAction == false && (pVal.FormTypeEx == "1250000940" || pVal.FormTypeEx == "721" || pVal.FormTypeEx == "720" || pVal.FormTypeEx == "142"))
                {
                    try
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        string Tablename = oForm.DataSources.DBDataSources.Item(0).TableName;

                        if (pVal.FormTypeEx == "142")
                        {
                            #region create Program sheet fields on Header
                            oItem = oForm.Items.Item("4");
                            SAPbouiCOM.Item oNewItem = oForm.Items.Add("lblPgrM", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left + oItem.Width + 5;
                            oNewItem.Width = oItem.Width - 40;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblPgrM").Specific)).Caption = "Program Sheet Number";

                            oItem = oForm.Items.Item("lblPgrM");
                            oNewItem = oForm.Items.Add("txtPrgDN", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + 120;
                            oNewItem.Width = oItem.Width + 40;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgShtDN");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtPrgDE", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + oItem.Width + 5;
                            oNewItem.Width = 0;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgShtDE");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtPrgSer", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + oItem.Width + 7;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgSer");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("lblPgrM");
                            oNewItem = oForm.Items.Add("lblJobWrkr", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblJobWrkr").Specific)).Caption = "Job Worker";
                            //oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtJobWrkr", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            int width = oNewItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_JobWrkr");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDE");
                            oNewItem = oForm.Items.Add("txtJobNm", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_JobWrkrNm");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("lblJobWrkr");
                            oNewItem = oForm.Items.Add("lblLabel", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblLabel").Specific)).Caption = "Label";
                            //oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtJobWrkr");
                            oNewItem = oForm.Items.Add("txtLabel", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_Label");
                            oNewItem.Enabled = false;


                            #endregion

                            #region add cfl on row program sheet
                            //SAPbouiCOM.ChooseFromListCollection oCFLs;
                            //oCFLs = oForm.ChooseFromLists;

                            //SAPbouiCOM.ChooseFromList oCFL;
                            //SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams;
                            //oCFLCreationParams = (SAPbouiCOM.ChooseFromListCreationParams)Packing.SBO_Application.CreateObject

                            //(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams);

                            //oCFLCreationParams.MultiSelection = false;
                            //oCFLCreationParams.ObjectType = "OPST"; //my user-defined object code
                            //oCFLCreationParams.UniqueID = "CFL1";

                            //oCFL = oCFLs.Add(oCFLCreationParams);

                            //oMatrix = oForm.Items.Item("38").Specific;
                            //oColumns = oMatrix.Columns;
                            //oColumn = oColumns.Item("U_PrgShtDE");
                            //oColumn.ChooseFromListUID = "CFL1";
                            //oColumn.ChooseFromListAlias = "DocEntry";

                            #endregion

                            #region add form matrix setting


                            oItem = oForm.Items.Item("lblLabel");
                            oNewItem = oForm.Items.Add("lblFSett", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblFSett").Specific)).Caption = "Form Setting";

                            oItem = oForm.Items.Item("txtLabel");
                            oNewItem = oForm.Items.Add("cmbFSett", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblFSett";
                            ((SAPbouiCOM.ComboBox)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_FormSet");
                            oNewItem.Enabled = true;

                            oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                            oCombo = oForm.Items.Item("cmbFSett").Specific;
                            SAPbobsCOM.Recordset oRS_Process = null;
                            oRS_Process = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            string strSQL = null;
                            strSQL = "select Name from [@FormSet] where U_Type='142'";
                            oRS_Process.DoQuery(strSQL);
                            //strSeries = "";
                            if (oRS_Process.RecordCount > 0)
                            {
                                for (int i = 0; i < oRS_Process.RecordCount; i++)
                                {
                                    oCombo.ValidValues.Add(oRS_Process.Fields.Item("Name").Value.ToString(), oRS_Process.Fields.Item("Name").Value.ToString());
                                    oRS_Process.MoveNext();
                                }

                                if (oRS_Process.RecordCount == 1)
                                {
                                    try
                                    {
                                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);

                                    }
                                    catch { }
                                }
                            }
                            #endregion
                        }

                        else if (pVal.FormTypeEx == "720" || pVal.FormTypeEx == "721")
                        {
                            #region create Program sheet fields on Header
                            #region Program sheet details

                            oItem = oForm.Items.Item("30");
                            SAPbouiCOM.Item oNewItem = oForm.Items.Add("lblPgrM", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left + oItem.Width + 5;
                            oNewItem.Width = oItem.Width + 20;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "30";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblPgrM").Specific)).Caption = "Program Sheet Number";

                            oItem = oForm.Items.Item("lblPgrM");
                            oNewItem = oForm.Items.Add("txtPrgDN", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + 120;
                            oNewItem.Width = oItem.Width + 20;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgShtDN");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtPrgDE", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + oItem.Width + 5;
                            oNewItem.Width = 0;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgShtDE");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtPrgSer", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + oItem.Width + 7;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgSer");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("lblPgrM");
                            oNewItem = oForm.Items.Add("lblJobWrkr", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblJobWrkr").Specific)).Caption = "Job Worker";
                            //oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtJobWrkr", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            int width = oNewItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_JobWrkr");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDE");
                            oNewItem = oForm.Items.Add("txtJobNm", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_JobWrkrNm");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("lblJobWrkr");
                            oNewItem = oForm.Items.Add("lblLabel", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblLabel").Specific)).Caption = "Label";
                            //oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtJobWrkr");
                            oNewItem = oForm.Items.Add("txtLabel", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_Label");
                            oNewItem.Enabled = false;

                            #endregion

                            #region Goods Receipt
                            if (pVal.FormTypeEx == "721")
                            {
                                oItem = oForm.Items.Item("22");
                                oNewItem = oForm.Items.Add("lblProcess", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 30;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "22";
                                ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblProcess").Specific)).Caption = "Process";
                                //oNewItem.Enabled = false;

                                oItem = oForm.Items.Item("21");
                                oNewItem = oForm.Items.Add("txtProc", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 30;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lblProcess";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_Proc");
                                oNewItem.Enabled = true;

                                oItem = oForm.Items.Item("lblProcess");
                                oNewItem = oForm.Items.Add("lblBatch", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "22";
                                ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblBatch").Specific)).Caption = "Batch";
                                //oNewItem.Enabled = false;

                                oItem = oForm.Items.Item("txtProc");
                                oNewItem = oForm.Items.Add("txtLot", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lblBatch";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_LOTNO");
                                oNewItem.Enabled = true;

                                oItem = oForm.Items.Item("txtProc");
                                oNewItem = oForm.Items.Add("txtBatch", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = 0;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lblBatch";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_Batch");
                                oNewItem.Enabled = true;


                                #region Issue Docnum 
                                oItem = oForm.Items.Item("20");
                                oNewItem = oForm.Items.Add("lblIssue", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "20";
                                ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblIssue").Specific)).Caption = "Allocation No.";
                                //oNewItem.Enabled = false;

                                oItem = oForm.Items.Item("3");
                                oNewItem = oForm.Items.Add("txtIssue", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lblIssue";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_RecDN");
                                oNewItem.Enabled = true;

                                oItem = oForm.Items.Item("txtIssue");
                                oNewItem = oForm.Items.Add("txtIssueDE", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = 0;
                                oNewItem.Top = oItem.Top + oItem.Height;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lblIssue";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_RecNum");
                                oNewItem.Enabled = true;

                                oItem = oForm.Items.Item("txtIssueDE");
                                oNewItem = oForm.Items.Add("linkiss", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON);
                                oNewItem.Left = oItem.Left - 20;
                                oNewItem.Width = 19;
                                oNewItem.Top = oForm.Items.Item("lblIssue").Top;
                                oNewItem.Height = 14;
                                oNewItem.LinkTo = "txtIssueDE";
                                ((SAPbouiCOM.LinkedButton)oNewItem.Specific).LinkedObject = SAPbouiCOM.BoLinkedObject.lf_GoodsIssue;
                                //((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_RecNum");
                                oNewItem.Enabled = true;

                                #endregion

                                #region add CFL for Batch
                                //SAPbouiCOM.ChooseFromListCollection oCFLs;
                                //oCFLs = oForm.ChooseFromLists;

                                //SAPbouiCOM.ChooseFromList oCFL;
                                //SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams;
                                //oCFLCreationParams = (SAPbouiCOM.ChooseFromListCreationParams)Packing.SBO_Application.CreateObject

                                //(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams);

                                //oCFLCreationParams.MultiSelection = false;
                                //oCFLCreationParams.ObjectType = "10000044"; //my user-defined object code
                                //oCFLCreationParams.UniqueID = "CFLBatch";

                                //oCFL = oCFLs.Add(oCFLCreationParams);

                                //oEdit = ((SAPbouiCOM.EditText)oForm.Items.Item("txtLot").Specific);
                                //oEdit.ChooseFromListUID = "CFLBatch";
                                //oEdit.ChooseFromListAlias = "MnfSerial";

                                ////oMatrix = oForm.Items.Item("38").Specific;
                                ////oColumns = oMatrix.Columns;
                                ////oColumn = oColumns.Item("U_PrgShtDE");
                                ////oColumn.ChooseFromListUID = "CFL1";
                                ////oColumn.ChooseFromListAlias = "DocEntry";

                                #endregion

                                #region btnCopy- Copy To Stock Transfer
                                oItem = oForm.Items.Item("2");
                                oNewItem = oForm.Items.Add("btnCopy", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                                oNewItem.Left = oItem.Left + oItem.Width + 20;
                                oNewItem.Width = oItem.Width + 40;
                                oNewItem.Top = oItem.Top;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "2";
                                ((SAPbouiCOM.Button)(oForm.Items.Item("btnCopy").Specific)).Caption = "Issue To Jobworker";
                                #endregion

                                #region Stock transfer Docentry

                                oItem = oForm.Items.Item("lblLabel");
                                oNewItem = oForm.Items.Add("lblST", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblST").Specific)).Caption = "Stock Transfer No";
                                oNewItem.LinkTo = "lblLabel";

                                oItem = oForm.Items.Item("txtLabel");
                                oNewItem = oForm.Items.Add("txtST", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lblST";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_STDOCE");
                                oNewItem.Enabled = false;


                                #endregion

                                #region Packing Details

                                oItem = oForm.Items.Item("lblST");
                                oNewItem = oForm.Items.Add("lbPackD", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                ((SAPbouiCOM.StaticText)(oForm.Items.Item("lbPackD").Specific)).Caption = "Packing List";
                                oNewItem.LinkTo = "lblST";

                                oItem = oForm.Items.Item("txtST");
                                oNewItem = oForm.Items.Add("txtPackD", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 5;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lbPackD";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PackList");
                                oNewItem.Enabled = false;


                                #endregion
                            }
                            #endregion

                            #region Goods Issue
                            else if (pVal.FormTypeEx == "720")
                            {
                                oItem = oForm.Items.Item("22");
                                oNewItem = oForm.Items.Add("lblProcess", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 30;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "22";
                                ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblProcess").Specific)).Caption = "Receipt Number";
                                //oNewItem.Enabled = false;

                                oItem = oForm.Items.Item("21");
                                oNewItem = oForm.Items.Add("txtRec", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Top = oItem.Top + oItem.Height + 30;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lblProcess";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_RecDN");
                                oNewItem.Enabled = true;

                                oItem = oForm.Items.Item("txtRec");
                                oNewItem = oForm.Items.Add("txtRecDE", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = 0;
                                oNewItem.Top = oItem.Top + oItem.Height + 30;
                                oNewItem.Height = oItem.Height;
                                oNewItem.LinkTo = "lblProcess";
                                ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_RecNum");
                                oNewItem.Enabled = true;

                                oItem = oForm.Items.Item("txtRecDE");
                                oNewItem = oForm.Items.Add("linkrec", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON);
                                oNewItem.Left = oItem.Left - 20;
                                oNewItem.Width = 19;
                                oNewItem.Top = oForm.Items.Item("lblProcess").Top;
                                oNewItem.Height = 14;
                                oNewItem.LinkTo = "txtRecDE";
                                ((SAPbouiCOM.LinkedButton)oNewItem.Specific).LinkedObject = SAPbouiCOM.BoLinkedObject.lf_GoodsReceipt;
                                //((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_RecNum");
                                oNewItem.Enabled = true;


                                #region add CFL for Recipt
                                SAPbouiCOM.ChooseFromListCollection oCFLs;
                                oCFLs = oForm.ChooseFromLists;

                                SAPbouiCOM.ChooseFromList oCFL;
                                SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams;
                                oCFLCreationParams = (SAPbouiCOM.ChooseFromListCreationParams)Packing.SBO_Application.CreateObject

                                (SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams);

                                oCFLCreationParams.MultiSelection = false;
                                oCFLCreationParams.ObjectType = "59"; //my user-defined object code
                                oCFLCreationParams.UniqueID = "CFLRec";

                                oCFL = oCFLs.Add(oCFLCreationParams);

                                oEdit = ((SAPbouiCOM.EditText)oForm.Items.Item("txtRec").Specific);
                                oEdit.ChooseFromListUID = "CFLRec";
                                oEdit.ChooseFromListAlias = "DocNum";

                                //oMatrix = oForm.Items.Item("38").Specific;
                                //oColumns = oMatrix.Columns;
                                //oColumn = oColumns.Item("U_PrgShtDE");
                                //oColumn.ChooseFromListUID = "CFL1";
                                //oColumn.ChooseFromListAlias = "DocEntry";

                                #endregion
                            }
                            #endregion

                            #endregion
                        }

                        else if (pVal.FormTypeEx == "1250000940")
                        {
                            #region create Program sheet fields on Header
                            oItem = oForm.Items.Item("3");
                            SAPbouiCOM.Item oNewItem = oForm.Items.Add("lblPgrM", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left + oItem.Width + 5;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "3";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblPgrM").Specific)).Caption = "Program Sheet Number";

                            oItem = oForm.Items.Item("lblPgrM");
                            oNewItem = oForm.Items.Add("txtPrgDN", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + 120;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgShtDN");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtPrgDE", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + oItem.Width + 5;
                            oNewItem.Width = 0;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgShtDE");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtPrgSer", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + oItem.Width + 7;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PrgSer");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("lblPgrM");
                            oNewItem = oForm.Items.Add("lblJobWrkr", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblJobWrkr").Specific)).Caption = "Job Worker";
                            //oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDN");
                            oNewItem = oForm.Items.Add("txtJobWrkr", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            int width = oNewItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_JobWrkr");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtPrgDE");
                            oNewItem = oForm.Items.Add("txtJobNm", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_JobWrkrNm");
                            oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("lblJobWrkr");
                            oNewItem = oForm.Items.Add("lblLabel", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPgrM";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblLabel").Specific)).Caption = "Label";
                            //oNewItem.Enabled = false;

                            oItem = oForm.Items.Item("txtJobWrkr");
                            oNewItem = oForm.Items.Add("txtLabel", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblJobWrkr";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_Label");
                            oNewItem.Enabled = false;


                            #endregion
                        }
                    }
                    catch (Exception ex)
                    {
                        SBO_Application.StatusBar.SetText("F_et_FORM_LOAD : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Select Choose from list Purchase Order
                //else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.FormTypeEx == "142" && pVal.BeforeAction == false && pVal.ItemUID == "38" && pVal.ColUID == "U_PrgShtDE")
                //{
                //    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                //    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                //    string sCFL_ID = null;
                //    sCFL_ID = oCFLEvento.ChooseFromListUID;
                //    string val1 = null;
                //    string val2 = null;
                //    string val3 = null;


                //    SAPbouiCOM.ChooseFromList oCFL = null;
                //    oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                //    SAPbouiCOM.DataTable oDataTable = null;
                //    oDataTable = oCFLEvento.SelectedObjects;


                //    val1 = oDataTable.GetValue("DocEntry", 0).ToString();
                //    val2 = oDataTable.GetValue("DocNum", 0).ToString();
                //    val2 = oDataTable.GetValue("", 0).ToString();
                //    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_1").Specific;
                //    oEdit1 = (SAPbouiCOM.EditText)oForm.Items.Item("Item_4").Specific;
                //    try
                //    {
                //        oEdit.Value = val2;

                //    }
                //    catch { }

                //    try
                //    {
                //        oEdit1.Value = Value;

                //    }
                //    catch { }
                //}
                #endregion

                #region choose from list on Goods Issue for Goods Receipt Beore action true
                if (pVal.FormTypeEx == "720" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "txtRec" && pVal.BeforeAction == true)
                {
                    oForm = SBO_Application.Forms.ActiveForm;
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    String CardCode = "";
                    //CardCode = oForm.Items.Item("Item_4").Specific.value;
                    string sCFL_ID = null;
                    sCFL_ID = oCFLEvento.ChooseFromListUID;
                    oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL
                    //oCFL1 = oForm.ChooseFromLists.Item(sCFL_ID);

                    oCFL.SetConditions(null);
                    oCons = oCFL.GetConditions();



                    oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    string qry = "select DocEntry from OIGN where DocEntry not in (select distinct U_RecNum from OIGE)";

                    oRs.DoQuery(qry);

                    if (oRs.RecordCount > 0)
                    {
                        oCon = oCons.Add();
                        for (int i = 0; i < oRs.RecordCount; i++)
                        {
                            if (i > 0)
                            {
                                oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                                oCon = oCons.Add();
                            }

                            oCon.Alias = "DocEntry";
                            oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                            oCon.CondVal = oRs.Fields.Item("DocEntry").Value.ToString();
                            oRs.MoveNext();
                        }

                        oCFL.SetConditions(oCons);
                    }

                    //oCon.Alias = "DocStatus";
                    //oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    //oCon.CondVal = "O";
                    //oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND;


                    //oCon = oCons.Add();
                    //oCon.Alias = "CardCode";
                    //oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    //oCon.CondVal = CardCode;


                }
                #endregion

                #region choose from list on Goods Issue for Goods Receipt Beore action False
                if (pVal.FormTypeEx == "720" && pVal.ItemUID == "txtRec" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.BeforeAction == false)
                {
                    oForm = SBO_Application.Forms.GetForm("720", pVal.FormTypeCount);
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    string sCFL_ID = null;
                    sCFL_ID = oCFLEvento.ChooseFromListUID;
                    string val1 = null;
                    string val2 = null;
                    string val3 = null;

                    SAPbouiCOM.ChooseFromList oCFL = null;
                    oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                    SAPbouiCOM.DataTable oDataTable = null;
                    oDataTable = oCFLEvento.SelectedObjects;

                    val1 = oDataTable.GetValue("DocNum", 0).ToString();
                    //val2 = oDataTable.GetValue("DocDate", 0).ToString("yyyyMMdd");
                    val3 = oDataTable.GetValue("DocEntry", 0).ToString();
                    //U_DocDate.Value = ToDate.ToString("yyyyMMdd")
                    oForm = SBO_Application.Forms.GetForm("720", pVal.FormTypeCount);
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("txtRec").Specific;
                    try
                    {
                        oEdit.Value = val1;
                    }
                    catch { }
                    oForm = SBO_Application.Forms.GetForm("720", pVal.FormTypeCount);
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("txtRecDE").Specific;
                    try
                    {
                        oEdit.Value = val3;
                    }
                    catch { }

                }
                #endregion


                #region choose from list on Goods Receipt for Batch Before action true
                if (pVal.FormTypeEx == "721" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "txtLot" && pVal.BeforeAction == true)
                {
                    oForm = SBO_Application.Forms.ActiveForm;
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    string item = "";
                    string whse = "";

                    oMatrix = oForm.Items.Item("13").Specific;
                    item = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", 1)).Value.ToString();
                    whse = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", 1)).Value.ToString();


                    string sCFL_ID = null;
                    sCFL_ID = oCFLEvento.ChooseFromListUID;
                    oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL
                                                                //oCFL1 = oForm.ChooseFromLists.Item(sCFL_ID);

                    oCFL.SetConditions(null);
                    oCons = oCFL.GetConditions();



                    oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    string qry = "select BatchNum [DistNumber] from OIBT where ItemCode='" + item + "' and isnull(U_FRptRdDt,'20170101')>'20170101' and isnull(U_StpLot,'N')= 'N'  and WhsCode='" + whse + "'";

                    oRs.DoQuery(qry);

                    if (oRs.RecordCount > 0)
                    {
                        oCon = oCons.Add();
                        for (int i = 0; i < oRs.RecordCount; i++)
                        {
                            if (i > 0)
                            {
                                oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                                oCon = oCons.Add();
                            }

                            oCon.Alias = "DistNumber";
                            oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                            oCon.CondVal = oRs.Fields.Item("DistNumber").Value.ToString();
                            oRs.MoveNext();
                        }

                        oCFL.SetConditions(oCons);
                    }
                    else
                    {
                        oCon = oCons.Add();
                        oCon.Alias = "DistNumber";
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = "";
                    }



                }
                #endregion

                #region choose from list on Goods Receipt for Batch Beore action False
                if (pVal.FormTypeEx == "721" && pVal.ItemUID == "txtLot" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.BeforeAction == false)
                {
                    oForm = SBO_Application.Forms.GetForm("721", pVal.FormTypeCount);
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    string sCFL_ID = null;
                    sCFL_ID = oCFLEvento.ChooseFromListUID;
                    string val1 = null;
                    string val2 = null;
                    string val3 = null;

                    SAPbouiCOM.ChooseFromList oCFL = null;
                    oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                    SAPbouiCOM.DataTable oDataTable = null;
                    oDataTable = oCFLEvento.SelectedObjects;

                    val1 = oDataTable.GetValue("MnfSerial", 0).ToString();
                    //val2 = oDataTable.GetValue("DocDate", 0).ToString("yyyyMMdd");
                    val3 = oDataTable.GetValue("DistNumber", 0).ToString();
                    //U_DocDate.Value = ToDate.ToString("yyyyMMdd")
                    oForm = SBO_Application.Forms.GetForm("721", pVal.FormTypeCount);
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("txtLot").Specific;
                    try
                    {
                        oEdit.Value = val1;
                    }
                    catch { }
                    oForm = SBO_Application.Forms.GetForm("721", pVal.FormTypeCount);
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("txtBatch").Specific;
                    try
                    {
                        oEdit.Value = val3;
                    }
                    catch { }

                }
                #endregion

                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD && pVal.BeforeAction == true)
                {
                    //oForm = SBO_Application.Forms.ActiveForm;
                    //if (oForm.Title == "Program Sheet selection")
                    //{
                    //    oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    ParentForm = Packing.SBO_Application.Forms.ActiveForm.TypeEx;
                    parentformcnt = Packing.SBO_Application.Forms.ActiveForm.TypeCount;
                    //}

                }

                oForm = Packing.SBO_Application.Forms.ActiveForm;

                #region select Program Sheet on Purchase
                if (oForm.Title == "Program Sheet selection")  //(pVal.EventType==SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK || (pVal.EventType==SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID=="1"))
                {
                    if (pVal.BeforeAction == true & pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                    {
                        oMatrix = oForm.Items.Item("4").Specific;
                        int selrow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                        Docentry = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("COL1", selrow)).Value.ToString();
                        DocNum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("COL2", selrow)).Value.ToString();
                        VendCd = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("COL3", selrow)).Value.ToString();
                        VendNm = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("COL4", selrow)).Value.ToString();
                        Label = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("COL5", selrow)).Value.ToString();
                        ProgramSerial = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("COL6", selrow)).Value.ToString();

                        //string Docentry = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("COL1", selrow)).Value.ToString();
                    }

                    else if (pVal.BeforeAction == false & pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        if ((ParentForm == "142" || ParentForm == "141") && oForm.Title == "Program Sheet selection")
                        {
                            oForm = Packing.SBO_Application.Forms.GetForm(ParentForm, parentformcnt);

                            oMatrix = oForm.Items.Item("38").Specific;
                            SAPbouiCOM.CellPosition oCell;
                            oCell = oMatrix.GetCellFocus();


                            int selrow = oCell.rowIndex;//oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);

                            try
                            {
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgShtDN", selrow)).Value = DocNum;
                            }
                            catch { }
                            try
                            {
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", selrow)).Value = VendCd;
                            }
                            catch { }
                            try
                            {
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkrNm", selrow)).Value = VendNm;
                            }
                            catch { }
                            try
                            {
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Label", selrow)).Value = Label;
                            }
                            catch { }
                            try
                            {
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgSer", selrow)).Value = ProgramSerial;
                            }
                            catch { }
                            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", selrow)).Value = oDAL.ExSelect("select U_Whse from [@PST1] where DocEntry='" + Docentry + "' and U_Vendor='" + VendCd + "' and U_Lable='" + Label + "'", "");
                        }

                    }
                }
                #endregion

                #region Item Lost focus Get Values of Program sheet
                if (((pVal.FormTypeEx == "142" && pVal.ItemUID == "38" && pVal.ColUID == "1") || ((pVal.FormTypeEx == "720" || pVal.FormTypeEx == "721") && pVal.ItemUID == "13" && pVal.ColUID == "1") || (pVal.FormTypeEx == "1250000940" && pVal.ItemUID == "23" && pVal.ColUID == "1")) && pVal.BeforeAction == false && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
                {
                    oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    if (pVal.FormTypeEx == "142")
                    {
                        oMatrix = oForm.Items.Item("38").Specific;
                    }
                    else if (pVal.FormTypeEx == "720" || pVal.FormTypeEx == "721")
                    {
                        oMatrix = oForm.Items.Item("13").Specific;
                    }
                    else if (pVal.FormTypeEx == "1250000940")
                    {
                        oMatrix = oForm.Items.Item("23").Specific;
                    }

                    Docentry = ((SAPbouiCOM.EditText)oForm.Items.Item("txtPrgDE").Specific).Value.ToString();
                    DocNum = ((SAPbouiCOM.EditText)oForm.Items.Item("txtPrgDN").Specific).Value.ToString();
                    VendCd = ((SAPbouiCOM.EditText)oForm.Items.Item("txtJobWrkr").Specific).Value.ToString();
                    VendNm = ((SAPbouiCOM.EditText)oForm.Items.Item("txtJobNm").Specific).Value.ToString();
                    Label = ((SAPbouiCOM.EditText)oForm.Items.Item("txtLabel").Specific).Value.ToString();
                    ProgramSerial = ((SAPbouiCOM.EditText)oForm.Items.Item("txtPrgSer").Specific).Value.ToString();

                    if (Docentry != "" && VendCd != "")
                    {
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgShtDE", pVal.Row)).Value = Docentry;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgShtDN", pVal.Row)).Value = DocNum;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", pVal.Row)).Value = VendCd;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkrNm", pVal.Row)).Value = VendNm;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Label", pVal.Row)).Value = Label;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgSer", pVal.Row)).Value = ProgramSerial;

                        if (pVal.FormTypeEx == "142")
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", pVal.Row)).Value = oDAL.ExSelect("select U_Whse from [@PST1] where DocEntry='" + Docentry + "' and U_Vendor='" + VendCd + "' and U_Lable='" + Label + "'", "");
                        }
                        else if (pVal.FormTypeEx == "720" || pVal.FormTypeEx == "721")
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", pVal.Row)).Value = oDAL.ExSelect("select U_Whse from [@PST1] where DocEntry='" + Docentry + "' and U_Vendor='" + VendCd + "' and U_Lable='" + Label + "'", "");
                        }
                        //else if (pVal.FormTypeEx == "1250000940")
                        //{
                        //    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", pVal.Row)).Value = oDAL.ExSelect("select U_Whse from [@PST1] where DocEntry='" + Docentry + "' and U_Vendor='" + VendCd + "' and U_Lable='" + Label + "'", "");
                        //}



                    }
                }

                #endregion

                #region Purchase Order yard to meter calculation
                if ((pVal.FormTypeEx == "142") && pVal.ItemUID == "38" && (pVal.ColUID == "U_Yard" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS) || (pVal.ColUID == "U_YardTMtr" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS) && pVal.BeforeAction == false)
                {
                    oForm = Packing.SBO_Application.Forms.ActiveForm;
                    oMatrix = oForm.Items.Item("38").Specific;
                    string SUOM = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_SUOM", pVal.Row)).Selected.Value.ToString();
                    if (SUOM == "Yard")
                    {
                        oForm.Freeze(true);
                        string yard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", pVal.Row)).Value.ToString();
                        string yardtmtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_YardTMtr", pVal.Row)).Value.ToString();
                        string qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", pVal.Row)).Value.ToString();

                        if (Convert.ToDouble(qty) != Convert.ToDouble(yard) * Convert.ToDouble(yardtmtr))
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", pVal.Row)).Value = (Convert.ToDouble(yard) * Convert.ToDouble(yardtmtr)).ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", pVal.Row)).Value = (Convert.ToDouble(yard) * Convert.ToDouble(yardtmtr)).ToString();
                        }
                        oForm.Freeze(false);
                    }
                }
                #endregion

                #region Calculate Rate on PO & PI
                if ((pVal.FormTypeEx == "142") && (pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS || pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS) && pVal.BeforeAction == false)
                {
                    if (pVal.ItemUID == "38" && (((pVal.ColUID == "U_Pcs" || pVal.ColUID == "U_Bale" || pVal.ColUID == "U_Yard" || pVal.ColUID == "U_SRate" || pVal.ColUID == "11" || pVal.ColUID == "U_RateBaseOn") && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS))) //|| (pVal.ColUID == "U_RateBaseOn" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)   && pVal.ItemChanged==true
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        oMatrix = oForm.Items.Item("38").Specific;
                        oCombo = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_RateBaseOn", pVal.Row));
                        string Piece = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", pVal.Row)).Value.ToString();
                        string Bale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", pVal.Row)).Value.ToString();
                        string Yard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", pVal.Row)).Value.ToString();
                        string SRate = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRate", pVal.Row)).Value.ToString();
                        string Qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", pVal.Row)).Value.ToString();
                        string Rate;
                        string linetotal = "0";
                        string RateBaseOn = oCombo.Selected.Value.ToString();
                        if ((RateBaseOn == "Mtr" || RateBaseOn == "Kgs") && Convert.ToDouble(SRate) > 0)
                        {
                            string rt = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).Value.ToString();
                            if (rt.Contains("INR "))
                                rt = rt.Replace("INR ", "");
                            else if (rt == "")
                                rt = "0";
                            if (Convert.ToDouble(rt) != Convert.ToDouble(SRate))
                            {

                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).Value = SRate;
                            }
                        }
                        else
                        {
                            if (RateBaseOn == "Bale")
                            {
                                linetotal = (Convert.ToDouble(Bale) * Convert.ToDouble(SRate)).ToString();
                            }
                            else if (RateBaseOn == "Pcs")
                            {
                                linetotal = (Convert.ToDouble(Piece) * Convert.ToDouble(SRate)).ToString();
                            }
                            else if (RateBaseOn == "Yard")
                            {
                                linetotal = (Convert.ToDouble(Yard) * Convert.ToDouble(SRate)).ToString();
                            }

                            if (Convert.ToDouble(Qty) > 0)
                            {
                                oForm.Freeze(true);
                                Rate = (Convert.ToDouble(linetotal) / Convert.ToDouble(Qty)).ToString();
                                string z = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).Value.ToString();
                                if (z.Contains("INR "))
                                    z = z.Replace("INR ", "");
                                else if (z == "")
                                    z = "0";

                                if (Convert.ToDouble(z) != Convert.ToDouble(Rate))
                                {

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).Value = Rate;
                                }

                                string line = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("21", pVal.Row)).Value.ToString();
                                if (line != linetotal && line != "")
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("21", pVal.Row)).Value = linetotal;

                                oForm.Freeze(false);
                            }
                        }
                    }
                }
                #endregion

                #region Create Batch after AP Invoice
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED && pVal.ItemUID == "1" && pVal.FormTypeEx == "141" && pVal.ActionSuccess == true)
                {

                    //oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    //if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                    //{
                    //    string doce = oDAL.ExSelect("select max(docentry) from OPCH", "");
                    //    string docn = oDAL.ExSelect("select docnum from OPCH where docentry='" + doce + "'", "");
                    //    string Sql = "select T0.WhsCode,T0.Quantity,T0.ItemCode,T0.LineNum,U_TRANSPRT,U_LRDT,U_LRNO,U_PTYCHALL,(select replace(convert(varchar(20), OPCH.DocDate,102),'.','')  from OPCH where DocEntry=T0.Docentry) DocDate,T0.U_Pcs from PCH1 [T0] inner join OITM [T1] on T0.ItemCode=T1.ItemCode where T0.DocEntry=" + doce + " and T1.ManBtchNum='Y' and T1.MngMethod='R'";
                    //    SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    //    oRset.DoQuery(Sql);

                    //    if (oRset.RecordCount > 0)
                    //    {
                    //        for (int item = 0; item < oRset.RecordCount; item++)
                    //        {
                    //            SBO_Application.ActivateMenuItem("12289");
                    //            oForm = Packing.SBO_Application.Forms.ActiveForm;
                    //            oCombo = oForm.Items.Item("15").Specific;
                    //            oCombo.Select("1", SAPbouiCOM.BoSearchKey.psk_ByValue);
                    //            string itemcode = oRset.Fields.Item("ItemCode").Value.ToString();
                    //            string transporter = oRset.Fields.Item("U_TRANSPRT").Value.ToString();
                    //            string LRDT = oRset.Fields.Item("U_LRDT").Value.ToString();
                    //            string LRNO = oRset.Fields.Item("U_LRNO").Value.ToString();
                    //            string PTYCHALL = oRset.Fields.Item("U_PTYCHALL").Value.ToString();
                    //            string linenum = oRset.Fields.Item("LineNum").Value.ToString();
                    //            string docdate = oRset.Fields.Item("DocDate").Value.ToString();
                    //            string Pieces = oRset.Fields.Item("U_Pcs").Value.ToString();
                    //            string Warehouse = oRset.Fields.Item("WhsCode").Value.ToString();
                    //            string PCHQTY = oRset.Fields.Item("Quantity").Value.ToString();

                    //            ((SAPbouiCOM.EditText)oForm.Items.Item("3").Specific).Value = itemcode;
                    //            ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value = itemcode;
                    //            oForm.Items.Item("7").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    //            oMatrix = oForm.Items.Item("31").Specific;
                    //            oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("1", 3));
                    //            oCheckBox.Checked = true;
                    //            ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value = docdate;//DateTime.Now.ToString("yyyyMMdd");
                    //            ((SAPbouiCOM.EditText)oForm.Items.Item("11").Specific).Value = docdate;//DateTime.Now.ToString("yyyyMMdd");
                    //            oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);


                    //            xForm = Packing.SBO_Application.Forms.ActiveForm;
                    //            oMatrix = xForm.Items.Item("35").Specific;
                    //            int cnt = oMatrix.VisualRowCount;
                    //            for (int i = 1; i <= cnt; i++)
                    //            {
                    //                string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("5", i)).Value.ToString();
                    //                string whse = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("40", i)).Value.ToString();
                    //                string qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("39", i)).Value.ToString();
                    //                string APINVOICE = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", i)).Value.ToString();



                    //                if (APINVOICE == "PU " + docn && ItemCode == itemcode && whse == Warehouse && Convert.ToDouble(PCHQTY) == Convert.ToDouble(qty))
                    //                {
                    //                    oMatrix.Columns.Item("0").Cells.Item(i).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    //                }
                    //            }

                    //            oMatrix = xForm.Items.Item("3").Specific;
                    //            string batchnum = itemcode + "-" + "PU-" + docn + "-" + linenum;
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", 1)).Value = batchnum;
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TRANSPRT", 1)).Value = transporter;
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRDT", 1)).String = LRDT.Replace(" 00:00:00", "");
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRNO", 1)).Value = LRNO;
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", 1)).Value = Pieces;
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PTYCHALL", 1)).Value = PTYCHALL;


                    //            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    //            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                    //            oDAL.ExSelect("update OIBT set U_pcs=" + Pieces + " where BatchNum='" + batchnum + "'", "");

                    //            oRset.MoveNext();
                    //        }

                    //    }



                    //}
                }
                #endregion

                #region Create Batch after Receipt
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED && pVal.ItemUID == "1" && pVal.FormTypeEx == "721" && pVal.ActionSuccess == true)
                {

                    oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                    {
                        string doce = oDAL.ExSelect("select max(docentry) from OIGN", "");
                        string docn = oDAL.ExSelect("select docnum from OIGN where docentry='" + doce + "'", "");
                        string Sql = "select T0.ItemCode,U_STBALE,U_ENBALE,T0.LineNum,U_Pcs,U_TRANSPRT,U_LRDT,U_LRNO,U_PTYCHALL,(select U_EType from OIGN where OIGN.DocEntry=T0.Docentry) Etype,T0.U_BatchNo [Batch],(select replace(convert(varchar(20), OIGN.DocDate,102),'.','')  from OIGN where DocEntry=T0.Docentry) DocDate from IGN1 [T0] inner join OITM [T1] on T0.ItemCode=T1.ItemCode where T0.DocEntry=" + doce + " and T1.ManBtchNum='Y' and T1.MngMethod='R'";
                        //(select OIGN.U_LOTNO from OIGN where OIGN.DocEntry=T0.Docentry)
                        SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        oRset.DoQuery(Sql);

                        if (oRset.RecordCount > 0)
                        {
                            for (int item = 0; item < oRset.RecordCount; item++)
                            {
                                SBO_Application.ActivateMenuItem("12289");
                                oForm = Packing.SBO_Application.Forms.ActiveForm;
                                oCombo = oForm.Items.Item("15").Specific;
                                oCombo.Select("1", SAPbouiCOM.BoSearchKey.psk_ByValue);
                                string itemcode = oRset.Fields.Item("ItemCode").Value.ToString();
                                string transporter = oRset.Fields.Item("U_TRANSPRT").Value.ToString();
                                string LRDT = oRset.Fields.Item("U_LRDT").Value.ToString();
                                string LRNO = oRset.Fields.Item("U_LRNO").Value.ToString();
                                string PTYCHALL = oRset.Fields.Item("U_PTYCHALL").Value.ToString();
                                string linenum = oRset.Fields.Item("LineNum").Value.ToString();
                                string docdate = oRset.Fields.Item("DocDate").Value.ToString();
                                string EType = oRset.Fields.Item("Etype").Value.ToString();
                                string Batch = oRset.Fields.Item("Batch").Value.ToString();
                                string Pcs = oRset.Fields.Item("U_Pcs").Value.ToString();
                                string STBALE = oRset.Fields.Item("U_STBALE").Value.ToString();
                                string ENBALE = oRset.Fields.Item("U_ENBALE").Value.ToString();

                                ((SAPbouiCOM.EditText)oForm.Items.Item("3").Specific).Value = itemcode;
                                ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value = itemcode;
                                oForm.Items.Item("9").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                oMatrix = oForm.Items.Item("33").Specific;
                                oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("1", 2));
                                oCheckBox.Checked = true;
                                ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value = docdate;//DateTime.Now.ToString("yyyyMMdd");
                                ((SAPbouiCOM.EditText)oForm.Items.Item("11").Specific).Value = docdate;//DateTime.Now.ToString("yyyyMMdd");
                                oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);


                                xForm = Packing.SBO_Application.Forms.ActiveForm;
                                oMatrix = xForm.Items.Item("35").Specific;
                                int cnt = oMatrix.VisualRowCount;
                                for (int i = 1; i <= cnt; i++)
                                {
                                    if (((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", i)).Value.ToString() == "SI " + docn)
                                    {
                                        oMatrix.Columns.Item("0").Cells.Item(i).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    }
                                }

                                oMatrix = xForm.Items.Item("3").Specific;
                                if (EType == "Excess")
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", 1)).Value = Batch;
                                    string Pcse = oDAL.ExSelect("select U_Pcs from OIBT where batchnum='" + Batch + "'", "");
                                    //int pcse1 = Convert.ToInt32(Convert.ToDouble(Pcse)) + Convert.ToInt32(Pcs);
                                    //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", 1)).Value = pcse1.ToString();

                                    oMatrix.Columns.Item("U_TRANSPRT").Cells.Item(1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                                else
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", 1)).Value = itemcode + "-" + "SI-" + docn + "-" + linenum;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TRANSPRT", 1)).Value = transporter;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRDT", 1)).String = LRDT.Replace(" 00:00:00", "");
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRNO", 1)).Value = LRNO;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PTYCHALL", 1)).Value = PTYCHALL;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_STBALE", 1)).Value = STBALE;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ENBALE", 1)).Value = ENBALE;
                                }
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);


                                if (EType == "Excess")
                                {
                                    string Update_batch = "update OIBT set U_Pcs =isnull(T1.U_Pcs,0)+ isnull(T0.U_Pcs,0)  "
                                                        + " from OIBT [T1] inner join IBT1 on T1.BatchNum=IBT1.batchnum "
                                                        + " inner join IGN1 [T0] on T0.LineNum=IBT1.baselinNum and T0.DocEntry=IBT1.BaseEntry and T0.ObjType=IBT1.BaseType"
                                                        + " where T0.DocEntry='" + doce + "' and T0.LineNum='" + item + "'";
                                    oDAL.ExSelect(Update_batch, "");
                                }
                            }

                        }



                    }
                }
                #endregion

                #region Process Open on Goods Receipt
                if (pVal.FormTypeEx == "721" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "txtProc" && pVal.BeforeAction == false)
                {
                    //string proctype = ((SAPbouiCOM.ComboBox)oForm.Items.Item("U_EType").Specific).Selected.Value.ToString();

                    string proctype = oForm.DataSources.DBDataSources.Item("OIGN").GetValue("U_EType", 0).Trim();
                    if (proctype != "Yarn" && proctype != "-")
                    {

                        string Proc = ((SAPbouiCOM.EditText)oForm.Items.Item("txtProc").Specific).Value.ToString();
                        GlobalVariables.BaseFormUID = oForm.UniqueID;

                        LoadFromXML("PPS");

                        xForm = Packing.SBO_Application.Forms.Item("PPS");

                        //oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        //string SeriesQuery = "SELECT * from NNM1 WHERE ObjectCode='OFT'";

                        //oRs.DoQuery(SeriesQuery);

                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        oMatrix = oForm.Items.Item("13").Specific;
                        string ICode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", 1)).Value.ToString();
                        string IName = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", 1)).Value.ToString();
                        string Whse = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", 1)).Value.ToString();

                        if (Proc != "")
                        {
                            xForm = Packing.SBO_Application.Forms.Item("PPS");
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            ((SAPbouiCOM.EditText)xForm.Items.Item("3").Specific).Value = Proc;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            //foreach (SAPbouiCOM.Item it in xForm.Items)
                            //{
                            //    if (it.UniqueID == "Item_71" || it.UniqueID == "1" || it.UniqueID == "2" || it.UniqueID == "40")
                            //    { }
                            //    else
                            //    {
                            //        it.Enabled = false;
                            //    }
                            //}
                        }
                        else
                        {
                            xForm = Packing.SBO_Application.Forms.Item("PPS");
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                            //getfields_taka();
                            oMatrix = xForm.Items.Item("7").Specific;
                            oMatrix.AddRow(1, 0);
                            ((SAPbouiCOM.EditText)xForm.Items.Item("5").Specific).Value = ICode;
                            ((SAPbouiCOM.EditText)xForm.Items.Item("6").Specific).Value = IName;
                            ((SAPbouiCOM.EditText)xForm.Items.Item("9").Specific).Value = Whse;
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_-1", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                        }
                    }
                    else
                    {
                        SBO_Application.StatusBar.SetText("Process Packing List can't open for selected Entry Type!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                    }
                }
                #endregion

                #region Copy Sales Order data to Program Sheet
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT && pVal.ItemUID == "10000329" && pVal.FormTypeEx == "139" && pVal.BeforeAction == false)
                {
                    oForm = SBO_Application.Forms.GetForm("139", pVal.FormTypeCount);

                    oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    string ST = "";//((SAPbouiCOM.EditText)oForm.Items.Item("txtST").Specific).Value.ToString();
                    if (ST != "")
                    {
                        SBO_Application.StatusBar.SetText("Issue To Jobworker already done!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    else
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("10000329").Specific;
                        oMatrix = oForm.Items.Item("38").Specific;
                        int selrow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                        bool selection_required = false;

                        if (oCombo.Selected.Value == "Program Sheet")
                        {
                            string ser = ((SAPbouiCOM.ComboBox)oForm.Items.Item("88").Specific).Selected.Value.ToString();
                            string docnum = ((SAPbouiCOM.EditText)oForm.Items.Item("8").Specific).Value.ToString();
                            string docentry = oDAL.ExSelect("select DocEntry From ORDR where Series='" + ser + "' and DocNum='" + docnum + "'", "");

                            string qry = "Select * from ORDR [T0]  "
                                            + " where T0.DocEntry='" + docentry + "' ";

                            oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            oRs.DoQuery(qry);
                            if (oRs.RecordCount > 0)
                            {
                                SBO_Application.ActivateMenuItem("OPST");
                                xForm = SBO_Application.Forms.ActiveForm;//GetForm("940", 1);
                                try
                                {
                                    ((SAPbouiCOM.EditText)xForm.Items.Item("Item_4").Specific).Value = oRs.Fields.Item("CardCode").Value.ToString();
                                }
                                catch { }

                                ((SAPbouiCOM.EditText)xForm.Items.Item("Item_1").Specific).Value = oRs.Fields.Item("CardName").Value.ToString();
                                ((SAPbouiCOM.EditText)xForm.Items.Item("Item_2").Specific).Value = oRs.Fields.Item("DocNum").Value.ToString();
                                ((SAPbouiCOM.EditText)xForm.Items.Item("Item_21").Specific).Value = oRs.Fields.Item("DocEntry").Value.ToString();
                                //((SAPbouiCOM.EditText)xForm.Items.Item("txtPCNO").Specific).Value = oRs.Fields.Item("U_PTYCHALL").Value.ToString();





                            }

                        }
                    }
                }

                #endregion

                #region Credit Note Before action true
                if (pVal.FormTypeEx == "181" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD && pVal.BeforeAction == true)
                {
                    xForm = SBO_Application.Forms.ActiveForm;
                    if (xForm.TypeEx == "141")
                    {
                        OPCH_Series = ((SAPbouiCOM.ComboBox)oForm.Items.Item("88").Specific).Selected.Value.ToString();
                        OPCH_DocNum = ((SAPbouiCOM.EditText)oForm.Items.Item("8").Specific).Value.ToString();

                        //string 


                    }
                }

                #endregion

                #region Copy from Pending Debit Note
                #region Add Button On AP Credit Note
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD && pVal.BeforeAction == false && (pVal.FormTypeEx == "181"))
                {
                    oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    string Tablename = oForm.DataSources.DBDataSources.Item(0).TableName;

                    if (pVal.FormTypeEx == "181")
                    {


                        oItem = oForm.Items.Item("4");
                        SAPbouiCOM.Item oNewItem = oForm.Items.Add("btnCopy", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                        oNewItem.Left = oItem.Left + oItem.Width + 20;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "4";
                        ((SAPbouiCOM.Button)(oForm.Items.Item("btnCopy").Specific)).Caption = "Copy From Pending";



                    }
                }

                #region Open Copy From PO
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.FormTypeEx == "181" && pVal.ItemUID == "btnCopy" && pVal.BeforeAction == false)
                {
                    oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value.ToString();
                    string dt = ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value.ToString();

                    if (cardcode != "")
                    {
                        LoadFromXML("PendingDebitNote");
                        xForm = Packing.SBO_Application.Forms.ActiveForm;
                        //((SAPbouiCOM.EditText)xForm.Items.Item("10").Specific).Value = dt;

                        ParentCount_CFPO = pVal.FormTypeCount;

                        oMatrix = xForm.Items.Item("Item_0").Specific;

                        string Sql = "select 'N' chk,T0.DocNum [STDN],T0.DocEntry [STDE],replace( convert(varchar(20),T0.DocDate,104),'.','') [STDD],T1.ItemCode,T1.Dscription,T1.Quantity,T1.U_Pcs,T1.U_Bale,T1.U_Yard,T2.BatchNum,T3.SuppSerial, "
                                    + " T4.CardName,T4.DocDate,T4.DocEntry [PONUM],T1.FromWhsCod,(select OCRD.Cardname from OCRD where isnull( OCRD.U_whse,'')=T1.FromWhsCod) [JobworkerNm], "
                                    + " (select OCRD.CardCode from OCRD where isnull( OCRD.U_whse,'')=T1.FromWhsCod) [JobworkerCd],T1.U_itype "
                                    + "  from "
                                    + " OWTR [T0] inner join WTR1 [T1] on T0.DocEntry=T1.DocEntry "
                                    + " inner join IBT1 [T2] on T1.DocEntry=T2.BaseEntry and T1.LineNum=T2.BaseLinNum and T1.ObjType=T2.BaseType and T1.WhsCode=T2.WhsCode "
                                    + " inner join OIBT [T3] on T2.BatchNum=T3.BatchNum and T2.WhsCode=T3.WhsCode "
                                    + " left join OPCH [T4] on T3.BaseType=T4.Objtype and T3.BaseEntry=T4.DocEntry "
                                    + " where T1.WhsCode='01' and T3.Quantity>0 and T0.DocDate<='" + dt + "'"; //and T2.GroupCode='103'
                        SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        oRset.DoQuery(Sql);
                        oMatrix.Clear();


                        xForm.DataSources.DataTables.Add("RET");
                        xForm.DataSources.DataTables.Item("RET").Clear();

                        xForm.DataSources.DataTables.Item("RET").ExecuteQuery(Sql);

                        oMatrix.Columns.Item("Col_0").DataBind.Bind("RET", "chk");
                        oMatrix.Columns.Item("V_0").DataBind.Bind("RET", "U_itype");
                        oMatrix.Columns.Item("Col_1").DataBind.Bind("RET", "JobworkerCd");
                        oMatrix.Columns.Item("Col_2").DataBind.Bind("RET", "JobworkerNm");
                        oMatrix.Columns.Item("Col_3").DataBind.Bind("RET", "BatchNum");
                        oMatrix.Columns.Item("Col_4").DataBind.Bind("RET", "SuppSerial");
                        oMatrix.Columns.Item("Col_5").DataBind.Bind("RET", "ItemCode");
                        oMatrix.Columns.Item("Col_6").DataBind.Bind("RET", "Dscription");
                        oMatrix.Columns.Item("Col_7").DataBind.Bind("RET", "Quantity");
                        oMatrix.Columns.Item("Col_8").DataBind.Bind("RET", "U_Pcs");
                        oMatrix.Columns.Item("Col_9").DataBind.Bind("RET", "U_Bale");
                        oMatrix.Columns.Item("Col_10").DataBind.Bind("RET", "U_Yard");
                        oMatrix.Columns.Item("Col_11").DataBind.Bind("RET", "STDE");
                        oMatrix.Columns.Item("Col_12").DataBind.Bind("RET", "STDN");
                        oMatrix.Columns.Item("Col_13").DataBind.Bind("RET", "STDD");
                        oMatrix.Columns.Item("Col_14").DataBind.Bind("RET", "CardName");
                        oMatrix.Columns.Item("Col_15").DataBind.Bind("RET", "PONUM");
                        //oMatrix.Columns.Item("").DataBind.Bind("RET", "");
                        //oMatrix.Columns.Item("").DataBind.Bind("RET", "");


                        oMatrix.LoadFromDataSource();

                        //xForm.Items.Item("4").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                        //if (oRset.RecordCount > 0)
                        //{
                        //    try
                        //    {
                        //        oForm.Freeze(true);
                        //        for (int i = 1; i <= oRset.RecordCount; i++)
                        //        {
                        //            oMatrix.AddRow(1, (i - 1));
                        //            ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("Col_0", i)).Checked = false;
                        //            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).Value = oRset.Fields.Item("CardCode").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_1", i)).Value = oRset.Fields.Item("JobworkerCd").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_2", i)).Value = oRset.Fields.Item("JobworkerNm").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_3", i)).Value = oRset.Fields.Item("BatchNum").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_4", i)).Value = oRset.Fields.Item("SuppSerial").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_5", i)).Value = oRset.Fields.Item("ItemCode").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_6", i)).Value = oRset.Fields.Item("Dscription").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_7", i)).Value = oRset.Fields.Item("Quantity").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_8", i)).Value = oRset.Fields.Item("U_Pcs").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_9", i)).Value = oRset.Fields.Item("U_Bale").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_10", i)).Value = oRset.Fields.Item("U_Yard").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_11", i)).Value = oRset.Fields.Item("STDE").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_12", i)).Value = oRset.Fields.Item("STDN").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_13", i)).String = oRset.Fields.Item("STDD").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_14", i)).Value = oRset.Fields.Item("CardName").Value.ToString();
                        //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_15", i)).Value = oRset.Fields.Item("PONUM").Value.ToString();

                        //            oRset.MoveNext();
                        //        }
                        //        oForm.Freeze(false);
                        //    }
                        //    catch { oForm.Freeze(false); }
                        //}

                    }
                    else
                    {
                        SBO_Application.StatusBar.SetText("Please select vendor First", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }

                }
                #endregion


                #endregion

                #endregion

                #region Copy AP Invoice data to Stock Transfer
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "btnCopy" && pVal.FormTypeEx == "721" && pVal.BeforeAction == false)
                {
                    oForm = SBO_Application.Forms.GetForm("721", pVal.FormTypeCount);

                    //oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    string ST = ((SAPbouiCOM.EditText)oForm.Items.Item("txtST").Specific).Value.ToString();
                    if (ST != "")
                    {
                        SBO_Application.StatusBar.SetText("Issue To Jobworker already done!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    else
                    {

                        oMatrix = oForm.Items.Item("13").Specific;
                        int selrow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                        bool selection_required = false;

                        if (oMatrix.VisualRowCount > 1 && selrow < 0)
                        {
                            SBO_Application.StatusBar.SetText("Please select Row to Transfer !!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                        else if (oMatrix.VisualRowCount == 1)
                        {
                            selrow = 1;
                            selection_required = true;
                        }
                        else if (oMatrix.VisualRowCount > 1 && selrow >= 0)
                        {
                            selection_required = true;
                        }

                        if (selection_required)
                        {
                            string ser = ((SAPbouiCOM.ComboBox)oForm.Items.Item("30").Specific).Selected.Value.ToString();
                            string docnum = ((SAPbouiCOM.EditText)oForm.Items.Item("7").Specific).Value.ToString();
                            string docentry = oDAL.ExSelect("select DocEntry From OIGN where Series='" + ser + "' and DocNum='" + docnum + "'", "");

                            string qry = "select T0.Docentry,T1.U_JobWrkr,T1.U_LRNO,REPLACE( convert(varchar(20), T1.U_LRDT,104),'.','') U_LRDT,T1.U_PTYCHALL,T1.U_TRANSPRT,(select OCRD.U_whse from OCRD where OCRD.Cardcode=T1.U_JobWrkr) [Whse],T1.WhsCode "
                                            + " from OIGN [T0] inner join IGN1 [T1] on T0.DocEntry=T1.DocEntry "
                                            //+ " inner join PCH1 [T1] on T0.Docentry=T1.Docentry "
                                            + " inner join OIBT [T2] on T0.DocEntry=T2.BaseEntry and T0.ObjType=T2.BaseType and T2.BaseLinNum=T1.LineNum  "
                                            + " where T0.DocEntry='" + docentry + "' and T1.LineNum=" + (selrow - 1).ToString() + "";

                            oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            oRs.DoQuery(qry);
                            if (oRs.RecordCount > 0)
                            {
                                SBO_Application.ActivateMenuItem("3080");
                                xForm = SBO_Application.Forms.ActiveForm;//GetForm("940", 1);

                                string Whse = oRs.Fields.Item("Whse").Value.ToString();
                                if (Whse != "")
                                    ((SAPbouiCOM.EditText)xForm.Items.Item("1470000101").Specific).Value = Whse;

                                ((SAPbouiCOM.EditText)xForm.Items.Item("txtAPI").Specific).Value = oRs.Fields.Item("Docentry").Value.ToString();
                                ((SAPbouiCOM.EditText)xForm.Items.Item("txtTrans").Specific).Value = oRs.Fields.Item("U_TRANSPRT").Value.ToString();
                                ((SAPbouiCOM.EditText)xForm.Items.Item("txtLR").Specific).Value = oRs.Fields.Item("U_LRNO").Value.ToString();
                                ((SAPbouiCOM.EditText)xForm.Items.Item("txtLRDt").Specific).String = oRs.Fields.Item("U_LRDT").Value.ToString();
                                ((SAPbouiCOM.EditText)xForm.Items.Item("txtPCNO").Specific).Value = oRs.Fields.Item("U_PTYCHALL").Value.ToString();

                            }

                        }
                    }
                }

                #endregion

                #region Open Stock Transfer from Goods Receipt
                if (pVal.FormTypeEx == "721" && pVal.ItemUID == "txtST" && pVal.BeforeAction == false && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                {
                    oForm = Packing.SBO_Application.Forms.GetForm("721", pVal.FormTypeCount);
                    string ST = ((SAPbouiCOM.EditText)oForm.Items.Item("txtST").Specific).Value.ToString();
                    if (ST != "")
                    {
                        SBO_Application.ActivateMenuItem("3080");
                        xForm = SBO_Application.Forms.ActiveForm;//GetForm("940", 1)
                        xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                        ((SAPbouiCOM.ComboBox)xForm.Items.Item("40").Specific).Select(oDAL.ExSelect("Select Series from OWTR where Docentry='" + ST + "'", ""), SAPbouiCOM.BoSearchKey.psk_ByValue);
                        ((SAPbouiCOM.EditText)xForm.Items.Item("11").Specific).Value = oDAL.ExSelect("Select DocNum from OWTR where Docentry='" + ST + "'", "");
                        xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    }
                }
                #endregion

                #region Open Packing List From Goods Receipt

                if (pVal.FormTypeEx == "721" && pVal.ItemUID == "txtPackD" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.BeforeAction == false)
                {
                    oForm = SBO_Application.Forms.GetForm("721", pVal.FormTypeCount);
                    ParentCount_PackDet = pVal.FormTypeCount;

                    string PackList = ((SAPbouiCOM.EditText)oForm.Items.Item("txtPackD").Specific).Value.ToString();
                    Packing.PrgSheet_CurrentRow = pVal.Row;
                    Packing.ParentForm_PackDet = "721";

                    LoadFromXML("packingdetails");

                    xForm = Packing.SBO_Application.Forms.Item("OPCKDT");

                    oForm = SBO_Application.Forms.GetForm("721", pVal.FormTypeCount);


                    if (PackList != "")
                    {
                        xForm = Packing.SBO_Application.Forms.Item("OPCKDT");
                        xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                        ((SAPbouiCOM.EditText)xForm.Items.Item("3").Specific).Value = PackList;
                        xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                    }
                    else
                    {
                        xForm = Packing.SBO_Application.Forms.Item("OPCKDT");
                        xForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                        oMatrix = xForm.Items.Item("Item_13").Specific;
                        oMatrix.AddRow(1, 0);
                    }



                }
                #endregion

                #region Form Setting Combo select
                if (pVal.BeforeAction == false && pVal.ItemUID == "cmbFSett" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                {
                    oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                    oCombo = oForm.Items.Item("cmbFSett").Specific;
                    string type = oCombo.Selected.Value.ToString();
                    string form = pVal.FormTypeEx;
                    string mat = oDAL.ExSelect("Select U_matrix from [@FormSet] where U_Type='" + form + "' and Name='" + type + "'", "");
                    oMatrix = oForm.Items.Item(mat).Specific;
                    string Series = "";
                    string SeriesBOS = "";
                    string serCombo = "";
                    if (type != "")
                    {
                        SAPbobsCOM.Recordset oRs = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                        oRs.DoQuery("select T1.U_FieldName,U_FieldID,U_Enable,isnull(T0.U_Series,'') [Ser],isnull(T0.U_Account,'') [SerBOS],isnull(T0.U_SerCmb,'') U_SerCmb from [@FormSet] [T0] inner join [@FormSet2] [T1] on T0.code=T1.code where T0.U_Type='" + form + "' and T0.Name='" + type + "'");
                        if (oRs.RecordCount > 0)
                        {
                            oForm.Freeze(true);

                            for (int i = 1; i <= oRs.RecordCount; i++)
                            {
                                try
                                {
                                    string col = oRs.Fields.Item("U_FieldID").Value.ToString();
                                    string enbale = oRs.Fields.Item("U_Enable").Value.ToString();
                                    Series = oRs.Fields.Item("Ser").Value.ToString();
                                    SeriesBOS = oRs.Fields.Item("SerBOS").Value.ToString();
                                    serCombo = oRs.Fields.Item("U_SerCmb").Value.ToString();
                                    oColumn = oMatrix.Columns.Item(col);
                                    if (enbale == "Y")
                                        oColumn.Visible = true;
                                    else
                                        oColumn.Visible = false;
                                }
                                catch { }

                                oRs.MoveNext();

                            }

                            try
                            {
                                oCombo = oForm.Items.Item("254000013").Specific;
                                string type_of_invoice = oCombo.Selected.Value.ToString();
                                if (type_of_invoice == "--")
                                    Series = SeriesBOS;
                            }
                            catch { }

                            try
                            {

                                if (serCombo != "" && Series != "")
                                {
                                    oCombo = oForm.Items.Item(serCombo).Specific;
                                    oCombo.Select(Series, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }

                            }
                            catch { }
                            oForm.Freeze(false);
                        }




                    }

                }


                #endregion

                #region Transaction Type Combo select
                if (pVal.BeforeAction == false && pVal.ItemUID == "254000013" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                {
                    try
                    {
                        oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                        oCombo = oForm.Items.Item("cmbFSett").Specific;
                        string type = oCombo.Selected.Value.ToString();
                        string form = pVal.FormTypeEx;
                        string mat = oDAL.ExSelect("Select U_matrix from [@FormSet] where U_Type='" + form + "' and Name='" + type + "'", "");
                        oMatrix = oForm.Items.Item(mat).Specific;
                        string Series = "";
                        string SeriesBOS = "";
                        string serCombo = "";
                        if (type != "")
                        {
                            SAPbobsCOM.Recordset oRs = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                            oRs.DoQuery("select isnull(T0.U_Series,'') [Ser],isnull(T0.U_Account,'') [SerBOS],isnull(T0.U_SerCmb,'') U_SerCmb from [@FormSet] [T0]  where T0.U_Type='" + form + "' and T0.Name='" + type + "'");
                            if (oRs.RecordCount > 0)
                            {
                                oForm.Freeze(true);

                                Series = oRs.Fields.Item("Ser").Value.ToString();
                                SeriesBOS = oRs.Fields.Item("SerBOS").Value.ToString();
                                serCombo = oRs.Fields.Item("U_SerCmb").Value.ToString();

                                try
                                {
                                    oCombo = oForm.Items.Item("254000013").Specific;
                                    string type_of_invoice = oCombo.Selected.Value.ToString();
                                    if (type_of_invoice == "--")
                                        Series = SeriesBOS;
                                }
                                catch { }

                                try
                                {

                                    if (serCombo != "" && Series != "")
                                    {
                                        oCombo = oForm.Items.Item(serCombo).Specific;
                                        oCombo.Select(Series, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    }

                                }
                                catch { }
                                oForm.Freeze(false);
                            }




                        }
                    }
                    catch { }

                }


                #endregion
            }

            catch { }
        }
        #endregion

        #region MenuEvent
        public void SBO_Application_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            CRMEntry = false;
            string Query = "";
            string FDt = null, Doc = null;
            try
            {
                if (pVal.BeforeAction == false)
                {
                    #region initialize
                    if (pVal.MenuUID == "Initialize")
                    {
                        Create_DB cd = new Create_DB();
                        cd.CreateDataBase();
                    }
                    #endregion

                    #region PackingCredit
                    if (pVal.MenuUID == "PackingCredit")
                    {
                        oForm = SBO_Application.Forms.ActiveForm;
                        for (int i = 1; i < SBO_Application.Forms.Count; i++)
                        {
                            if (SBO_Application.Forms.Item(i).UniqueID == "PackingCredit")
                            {
                                SBO_Application.Forms.Item(i).Select();
                                return;
                            }
                        }

                        LoadFromXML("PackingCredit");
                    }
                    #endregion

                    #region Program Sheet
                    if (pVal.MenuUID == "OPST")
                    {
                        oForm = SBO_Application.Forms.ActiveForm;
                        for (int i = 1; i < SBO_Application.Forms.Count; i++)
                        {
                            if (SBO_Application.Forms.Item(i).UniqueID == "OPST")
                            {
                                SBO_Application.Forms.Item(i).Select();
                                return;
                            }
                        }

                        LoadFromXML("ProgramSheet");

                        oForm = Packing.SBO_Application.Forms.Item("OPST");
                        //if(oForm.ActiveItem=="")
                        oMatrix = oForm.Items.Item("Item_23").Specific;
                        //oMatrix.AddRow(1, oMatrix.VisualRowCount);

                        //oMatrix = oForm.Items.Item("Item_26").Specific;
                        //oMatrix.AddRow(1, oMatrix.VisualRowCount);

                        oMatrix = oForm.Items.Item("Item_28").Specific;
                        //oMatrix.AddRow(1, oMatrix.VisualRowCount);

                    }
                    #endregion


                    if (pVal.MenuUID == "TDSLIMIT_Remove_Line")
                    {
                        BubbleEvent = false;
                    }

                    if (pVal.MenuUID == "1292" && (oForm.UniqueID.ToString() == "OPST"))
                    {
                        oForm = Packing.SBO_Application.Forms.Item("OPST");
                        //if(oForm.ActiveItem=="")

                        SAPbouiCOM.Folder ofolder;
                        ofolder = oForm.Items.Item("Item_19").Specific;
                        if (ofolder.Selected == true)
                        {

                            oMatrix = oForm.Items.Item("Item_23").Specific;
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                oMatrix.AddRow(1, oMatrix.VisualRowCount);
                            }
                            else if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                            {
                                int a = oMatrix.VisualRowCount;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PST1");
                                oDbDataSource.InsertRecord(a);
                                oMatrix.LoadFromDataSource();
                            }
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                            oMatrix = oForm.Items.Item("Item_23").Specific;

                            oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_23", oMatrix.VisualRowCount));
                            oCheckBox.Checked = true;

                            //oForm.Items.Item("Item_4").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }

                        ofolder = oForm.Items.Item("Item_22").Specific;
                        if (ofolder.Selected == true)
                        {

                            oMatrix = oForm.Items.Item("Item_26").Specific;
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                oMatrix.AddRow(1, oMatrix.VisualRowCount);
                            }
                            else if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                            {
                                int a = oMatrix.VisualRowCount;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PST2");
                                oDbDataSource.InsertRecord(a);
                                oMatrix.LoadFromDataSource();
                            }
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                        }

                        ofolder = oForm.Items.Item("Item_27").Specific;
                        if (ofolder.Selected == true)
                        {

                            oMatrix = oForm.Items.Item("Item_28").Specific;
                            //oMatrix.AddRow(1, oMatrix.VisualRowCount);
                            SBO_Application.StatusBar.SetText("Add Row disbled on Related Document Details", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }



                    }

                    if (pVal.MenuUID == "1282" && (oForm.UniqueID.ToString() == "OPST"))
                    {
                        oForm = Packing.SBO_Application.Forms.Item("OPST");
                        oCombo = oForm.Items.Item("Item_0").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        oCombo = oForm.Items.Item("Item_5").Specific;
                        oCombo.Select("O", SAPbouiCOM.BoSearchKey.psk_ByValue);

                        string NowDate = Packing.oCompany.GetCompanyDate().ToString("yyyyMMdd").Replace("/", "-");

                        ((SAPbouiCOM.EditText)oForm.Items.Item("Item_6").Specific).Value = NowDate;
                        oForm.Items.Item("Item_4").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                        oMatrix = oForm.Items.Item("Item_23").Specific;
                        oMatrix.AddRow(1, oMatrix.VisualRowCount);
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                        oMatrix = oForm.Items.Item("Item_26").Specific;
                        oMatrix.AddRow(1, oMatrix.VisualRowCount);
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                        oMatrix = oForm.Items.Item("Item_28").Specific;
                        oMatrix.AddRow(1, oMatrix.VisualRowCount);
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();

                        oMatrix = oForm.Items.Item("Item_23").Specific;

                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_23", 1));
                        oCheckBox.Checked = true;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", 1)).Value = "0.9144";
                        oForm.Items.Item("Item_4").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    }

                    if (pVal.MenuUID == "1293" && (oForm.UniqueID.ToString() == "OPST"))
                    {
                        oForm = Packing.SBO_Application.Forms.Item("OPST");
                        //if(oForm.ActiveItem=="")
                        int data = 0;
                        SAPbouiCOM.Folder ofolder;
                        ofolder = oForm.Items.Item("Item_19").Specific;
                        if (ofolder.Selected == true)
                        {
                            oMatrix = oForm.Items.Item("Item_23").Specific;
                            data = 1;
                        }

                        ofolder = oForm.Items.Item("Item_22").Specific;
                        if (ofolder.Selected == true)
                        {

                            oMatrix = oForm.Items.Item("Item_26").Specific;
                            data = 2;
                        }

                        ofolder = oForm.Items.Item("Item_27").Specific;
                        if (ofolder.Selected == true)
                        {

                            oMatrix = oForm.Items.Item("Item_28").Specific;
                            data = 3;
                        }


                        oDbDataSource = oForm.DataSources.DBDataSources.Item(data);

                        //int selrow=oMatrix.GetNextSelectedRow(0,SAPbouiCOM.BoOrderType.ot_RowOrder);
                        //oDbDataSource.RemoveRecord(selrow);
                        oMatrix.FlushToDataSource();


                        oMatrix.LoadFromDataSource();
                    }

                    #region addrow commented
                    //if (pVal.MenuUID == "1282" && (oForm.UniqueID.ToString() == "frmJobSheet"))
                    //{

                    //    oForm = SBO_Application.Forms.Item("frmJobSheet");
                    //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("10").Specific;
                    //    oMatrix.AddRow(1, 0);

                    //    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_-1", oMatrix.VisualRowCount);
                    //    oEdit.Value = oMatrix.VisualRowCount.ToString();

                    //    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("17").Specific;
                    //    oEdit.String = "A";

                    //    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("loc").Specific;
                    //    string loccnt = oDAL.ExSelect("select isnull(count(T0.Name),0) from [@NCM_ULAH] [T0] inner join [@NCM_ULAR] [T1] on T0.Code=T1.Code where T1.U_UCode='" + oCompany.UserName + "'", "SAP");
                    //    int lcnt = Convert.ToInt32(loccnt);
                    //    if (lcnt == 1)
                    //    {
                    //        string userloc = oDAL.ExSelect("select T0.Name from [@NCM_ULAH] [T0] inner join [@NCM_ULAR] [T1] on T0.Code=T1.Code where T1.U_UCode='" + oCompany.UserName + "'", "SAP");
                    //        oEdit.Value = userloc;
                    //        //oForm.Items.Item("loc").Enabled = false;

                    //        string locCode = oDAL.ExSelect("select Code from olct where Location = '" + userloc + "'", "SAP");
                    //        string countWhs = oDAL.ExSelect("select COUNT(WhsCode) from OWHS T0 WHERE T0.Location = '" + locCode + "'", "SAP");

                    //        int Whscnt = Convert.ToInt32(countWhs);
                    //        if (Whscnt == 1)
                    //        {
                    //            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("63").Specific;
                    //            string WareHouse = oDAL.ExSelect("select WhsCode from OWHS T0 WHERE T0.Location = '" + locCode + "'", "SAP");
                    //            oEdit.Value = WareHouse;
                    //            //oForm.Items.Item("130").Enabled = false;
                    //        }
                    //        else
                    //        {
                    //            oForm.Items.Item("63").Enabled = true;
                    //            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("22").Specific;
                    //            oEdit.Value = oCompany.UserName;
                    //        }
                    //    }
                    //    else
                    //    {
                    //        oForm.Items.Item("loc").Enabled = true;
                    //    }
                    //    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("user").Specific;
                    //    oEdit.Value = oCompany.UserName;
                    //    //oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                    //    string Location = oDAL.ExSelect("select T0.Name from [@NCM_ULAH] [T0] inner join [@NCM_ULAR] [T1] on T0.Code=T1.Code where T1.U_UCode='" + oCompany.UserName + "'", "SAP");

                    //}
                    #endregion

                }

                if (pVal.MenuUID == "Checking" || oForm.TypeEx == "Checking")
                {
                    objChecking.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "Cutting" || oForm.TypeEx == "Cutting")
                {
                    objCutting.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "StdPack" || oForm.TypeEx == "StdPack")
                {
                    objStdPack.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "ExtPack" || oForm.TypeEx == "ExtPack")
                {
                    objExtPack.MenuEvent(ref pVal, out BubbleEvent);
                }
            }
            catch { }
        }
        #endregion

        #region FormDataEvent

        public void SBO_Application_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Inventory Transfer

                if (BusinessObjectInfo.FormTypeEx == "940" && (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE))
                {
                    oForm = Packing.SBO_Application.Forms.Item(BusinessObjectInfo.FormUID);
                    oForm.Items.Item("txtTrans").Enabled = false;
                    oForm.Items.Item("txtLR").Enabled = false;
                    oForm.Items.Item("txtLRDt").Enabled = false;
                    oForm.Items.Item("txtPCNO").Enabled = false;
                    oForm.Items.Item("txtFive").Enabled = false;
                    oForm.Items.Item("txtAPI").Enabled = false;
                }

                #endregion

                #region Inventory Revaluation After Goods Issue
                if (BusinessObjectInfo.FormTypeEx == "720" && BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD && BusinessObjectInfo.BeforeAction == false && BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = Packing.SBO_Application.Forms.Item(BusinessObjectInfo.FormUID);

                    string lastIssue = oDAL.ExSelect("select Max(Docentry) from OIGE", "");
                    string ReceiptDE = oDAL.ExSelect("select  isnull(U_RecNum,'') from OIGE where DocEntry='" + lastIssue + "'", "");

                    string IssueBatchNum = oDAL.ExSelect("select T2.BatchNum from OIGE [T0] inner join IGE1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + lastIssue + "'", "");
                    string IssueQty = oDAL.ExSelect("select T1.quantity from OIGE [T0] inner join IGE1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + lastIssue + "'", "");
                    string IssueWHSE = oDAL.ExSelect("select T1.WHSCODE from OIGE [T0] inner join IGE1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + lastIssue + "'", "");
                    //string IssueItem = oDAL.ExSelect("select T1.WHSCODE from OIGE [T0] inner join IGE1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + lastIssue + "'", "");
                    string IssueBatchCost = oDAL.ExSelect("select convert(numeric(19,4),CostTotal/Quantity) from OBTN where DistNumber='" + IssueBatchNum + "'", "");

                    double cost = Convert.ToDouble(IssueBatchCost);//Convert.ToDouble(IssueBatchCost) / Convert.ToDouble(IssueQty);


                    string ReceiptBatchnum = oDAL.ExSelect("select T2.BatchNum from OIGN [T0] inner join IGN1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + ReceiptDE + "'", "");
                    string ReceiptQTY = oDAL.ExSelect("select T1.Quantity from OIGN [T0] inner join IGN1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + ReceiptDE + "'", "");
                    string ReceiptBatchAbsEntry = oDAL.ExSelect("select SysNumber from OBTN where DistNumber='" + ReceiptBatchnum + "'", "");
                    string ReceiptItem = oDAL.ExSelect("select T1.ItemCode from OIGN [T0] inner join IGN1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + ReceiptDE + "'", "");
                    string ReceiptWHSE = oDAL.ExSelect("select T1.WHSCODE from OIGN [T0] inner join IGN1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + ReceiptDE + "'", "");

                    string ServiceInvoiceCost = oDAL.ExSelect("select Doctotal-VatSum from OPCH where U_recnum='" + ReceiptDE + "'", "");


                    if (cost > 1)
                    {

                        cost = cost + (Convert.ToDouble(ServiceInvoiceCost) / Convert.ToDouble(ReceiptQTY));
                        //cost = cost / Convert.ToDouble(ReceiptQTY);
                        bool Crete_revaluation = true;



                        while (Crete_revaluation)
                        {
                            Inventory_Revaluation(lastIssue, ReceiptItem, ReceiptWHSE, ReceiptBatchAbsEntry, cost);


                            string Next_IssueDocentry = oDAL.ExSelect("select Baseentry from IBT1 where BatchNum='" + ReceiptBatchnum + "' and BaseType='60' and ItemCode='" + ReceiptItem + "'", "");
                            if (Next_IssueDocentry == "")
                                Crete_revaluation = false;
                            else
                            {
                                lastIssue = Next_IssueDocentry;
                                ReceiptDE = oDAL.ExSelect("select  isnull(U_RecNum,'') from OIGE where DocEntry='" + lastIssue + "'", "");

                                IssueBatchNum = ReceiptBatchnum;
                                IssueQty = oDAL.ExSelect("select T1.quantity from OIGE [T0] inner join IGE1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + lastIssue + "'", "");
                                IssueWHSE = oDAL.ExSelect("select T1.WHSCODE from OIGE [T0] inner join IGE1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + lastIssue + "'", "");
                                //string IssueItem = oDAL.ExSelect("select T1.WHSCODE from OIGE [T0] inner join IGE1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + lastIssue + "'", "");
                                IssueBatchCost = oDAL.ExSelect("select convert(numeric(19,4),CostTotal/Quantity) from OBTN where DistNumber='" + IssueBatchNum + "'", "");

                                //cost = Convert.ToDouble(IssueBatchCost);//Convert.ToDouble(IssueBatchCost) / Convert.ToDouble(IssueQty);


                                ReceiptBatchnum = oDAL.ExSelect("select T2.BatchNum from OIGN [T0] inner join IGN1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + ReceiptDE + "'", "");
                                ReceiptQTY = oDAL.ExSelect("select T1.Quantity from OIGN [T0] inner join IGN1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + ReceiptDE + "'", "");
                                ReceiptBatchAbsEntry = oDAL.ExSelect("select SysNumber from OBTN where DistNumber='" + ReceiptBatchnum + "'", "");
                                ReceiptItem = oDAL.ExSelect("select T1.ItemCode from OIGN [T0] inner join IGN1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + ReceiptDE + "'", "");
                                ReceiptWHSE = oDAL.ExSelect("select T1.WHSCODE from OIGN [T0] inner join IGN1 [T1] on T0.Docentry=T1.Docentry inner join IBT1 [T2] on T1.LineNum=T2.BaseLinNum and T1.Docentry=T2.BaseEntry and T1.objType=T2.BaseType and T1.ItemCode=T2.ItemCode where T0.Docentry='" + ReceiptDE + "'", "");

                                ServiceInvoiceCost = oDAL.ExSelect("select Doctotal-VatSum from OPCH where U_recnum='" + ReceiptDE + "'", "");

                                cost = cost + (Convert.ToDouble(ServiceInvoiceCost) / Convert.ToDouble(ReceiptQTY));
                            }
                        }
                    }


                }
                #endregion

                #region Add Goods Issue after Goods Receipt
                if (BusinessObjectInfo.FormTypeEx == "721" && (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD) && BusinessObjectInfo.BeforeAction == false)
                {
                    oForm = Packing.SBO_Application.Forms.Item(BusinessObjectInfo.FormUID);

                    string lastreceipt = oDAL.ExSelect("select Max(Docentry) from OIGN", "");
                    string ProcId = oDAL.ExSelect("select  isnull(U_Proc,'') from OIGN where DocEntry='" + lastreceipt + "'", "");
                    string batch = oDAL.ExSelect("select case when U_EType='Process' then isnull(U_Batch,'') else '' end from OIGN where DocEntry='" + lastreceipt + "'", "");

                    if (ProcId != "")//|| batch!=""
                    {
                        string query = "";
                        if (ProcId != "")
                        {
                            query = "select T0.U_ICode,T0.DocEntry,T0.U_Iname,T0.U_Whse,T1.U_batchno,T0.U_TotPiece,sum(T1.U_FINMtr) [FinMtr]  ,sum(U_Pcs) [Pcs],(select sum([@PPS1].U_FINMtr) from [@PPS1] where [@PPS1].DocEntry=T0.DocEntry) [TotFin] "
                                            + " from [@PPS] [T0] inner join [@PPS1] [T1] on T0.DocEntry=T1.DocEntry "
                                            + " where T1.U_LotNo is not null and T0.Docentry='" + ProcId + "'"
                                            + " group by T0.U_ICode,T0.U_Iname,T0.U_Whse,T1.U_batchno,T0.DocEntry,T0.U_TotPiece";
                        }
                        //else if (batch != "")
                        //{
                        //    query = "Select T1.ItemCode [U_ICode],T0.DocEntry,T1.Dscription [U_Iname],T1.WhsCode [U_Whse],T0.U_Batch [U_batchno] " +
                        //            ",T1.Quantity [FinMtr],T1.Quantity [TotFin] from OIGN [T0] inner join IGN1 [T1] on T0.DocEntry=T1.DocEntry where T0.DocEntry='"+lastreceipt+"'";
                        //}

                        oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        oRs.DoQuery(query);
                        if (oRs.RecordCount > 0)
                        {
                            SAPbobsCOM.Documents issue = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit);
                            issue.UserFields.Fields.Item("U_RecNum").Value = lastreceipt;
                            issue.UserFields.Fields.Item("U_RecDN").Value = oDAL.ExSelect("select Docnum from OIGN where DocEntry=" + lastreceipt + "", "");
                            //issue.Lines.Add();
                            issue.Lines.ItemCode = oRs.Fields.Item("U_ICode").Value.ToString();
                            issue.Lines.WarehouseCode = oRs.Fields.Item("U_Whse").Value.ToString();
                            issue.Lines.Quantity = Convert.ToDouble(oRs.Fields.Item("TotFin").Value.ToString());
                            issue.Lines.UserFields.Fields.Item("U_Pcs").Value = oRs.Fields.Item("U_TotPiece").Value.ToString();
                            string[] qries = new string[1000];
                            int qries_cnt = 0;
                            for (int i = 0; i < oRs.RecordCount; i++)
                            {
                                if (i > 0)
                                {
                                    issue.Lines.BatchNumbers.Add();
                                }
                                issue.Lines.BatchNumbers.BatchNumber = oRs.Fields.Item("U_batchno").Value.ToString();
                                issue.Lines.BatchNumbers.Quantity = Convert.ToDouble(oRs.Fields.Item("FinMtr").Value.ToString());

                                string q = "update OIBT set U_Pcs=U_Pcs-" + oRs.Fields.Item("Pcs").Value.ToString() + " where BatchNum='" + oRs.Fields.Item("U_batchno").Value.ToString() + "' and WhsCode='" + oRs.Fields.Item("U_Whse").Value.ToString() + "'";
                                qries[qries_cnt] = q;
                                qries_cnt = qries_cnt + 1;

                                oRs.MoveNext();
                            }

                            string errorMsg;
                            int errorcode;
                            int res = issue.Add();
                            string issue_entry;
                            if (res != 0)
                            {
                                errorcode = oCompany.GetLastErrorCode();
                                errorMsg = oCompany.GetLastErrorDescription();
                                SBO_Application.StatusBar.SetText(errorcode.ToString() + " : " + errorMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                            else
                            {
                                issue_entry = oCompany.GetNewObjectKey();
                                string issuenum = oDAL.ExSelect("select DocNum from OIGE where DocEntry='" + issue_entry + "'", "");
                                oDAL.ExSelect("update OIGN set U_RecNum='" + issue_entry + "',U_RecDN='" + issuenum + "' where DocEntry=" + lastreceipt + " ", "");

                                for (int i = 0; i <= qries_cnt; i++)
                                {
                                    oDAL.ExSelect(qries[i].ToString(), "");
                                }
                            }

                        }
                    }


                }

                #endregion

                #region Checking

                if (BusinessObjectInfo.FormTypeEx == "Checking")
                {
                    objChecking.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }

                #endregion

                #region Cutting

                if (BusinessObjectInfo.FormTypeEx == "Cutting")
                {
                    objCutting.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }

                #endregion

                #region Standard Packing

                if (BusinessObjectInfo.FormTypeEx == "StdPack")
                {
                    objStdPack.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }

                #endregion

                #region Extra Packing

                if (BusinessObjectInfo.FormTypeEx == "ExtPack")
                {
                    objExtPack.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }

                #endregion
            }
            catch { }
        }

        #endregion

        #region App Event

        private void SBO_Application_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    {
                        System.Windows.Forms.Application.Exit();
                    }
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    {
                        System.Windows.Forms.Application.Exit();
                    }
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    {
                        System.Windows.Forms.Application.Exit();
                    }
                    break;
            }
        }

        #endregion

        #region Layout Event

        private void LayoutKeyEvent(ref SAPbouiCOM.LayoutKeyInfo eventInfo, out bool BubbleEvent)
        {

            BubbleEvent = true;
            if (eventInfo.FormUID.StartsWith("OPST"))
            {
                Transactions.ProgramSheet ps = new Transactions.ProgramSheet();
                ps.SBO_Application_LayoutKeyEvent(ref eventInfo, BubbleEvent);
            }
            //else if (eventInfo.FormUID.StartsWith("OMTC"))
            //{
            //    OMTC iqc = new OMTC();
            //    iqc.SBO_Application_LayoutKeyEvent(ref eventInfo, BubbleEvent);
            //}
            //else if (eventInfo.FormUID.StartsWith("OPCF"))
            //{
            //    Product_Complain iqc = new Product_Complain();
            //    iqc.SBO_Application_LayoutKeyEvent(ref eventInfo, BubbleEvent);
            //}
            //else if (eventInfo.FormUID.StartsWith("OOPI"))
            //{
            //    Transaction.OOPI iqc = new Transaction.OOPI();
            //    iqc.SBO_Application_LayoutKeyEvent(ref eventInfo, BubbleEvent);
            //}
        }

        private void SBO_Application_LayoutKeyEvent(ref SAPbouiCOM.LayoutKeyInfo eventInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (eventInfo.FormUID.StartsWith("OPST"))
            {
                Transactions.ProgramSheet ps = new Transactions.ProgramSheet();
                ps.SBO_Application_LayoutKeyEvent(ref eventInfo, BubbleEvent);
            }
        }

        #endregion

        #endregion

        #region Material Revaluation 

        public bool Inventory_Revaluation(string lastIssue, string ReceiptItem, string ReceiptWHSE, string ReceiptBatchAbsEntry, double cost)
        {
            try
            {

                SAPbobsCOM.MaterialRevaluation oMaterialRevaluation = default(SAPbobsCOM.MaterialRevaluation);
                SAPbobsCOM.SNBLines oMaterialRevaluationSNBLines = default(SAPbobsCOM.SNBLines);
                oMaterialRevaluation = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oMaterialRevaluation);
                oMaterialRevaluation.DocDate = System.DateTime.Now;
                oMaterialRevaluation.RevalType = "P";
                oMaterialRevaluation.Comments = "Issue Number " + oDAL.ExSelect("Select Docnum from OIGE where Docentry='" + lastIssue + "'", "");
                oMaterialRevaluation.Lines.ItemCode = ReceiptItem;
                oMaterialRevaluation.Lines.WarehouseCode = ReceiptWHSE;
                //oMaterialRevaluation.Lines.RevaluationDecrementAccount = "_SYS00000000134";
                //oMaterialRevaluation.Lines.RevaluationIncrementAccount = "_SYS00000000135";
                oMaterialRevaluationSNBLines = oMaterialRevaluation.Lines.SNBLines;
                oMaterialRevaluationSNBLines.SetCurrentLine(0);
                oMaterialRevaluationSNBLines.SnbAbsEntry = Convert.ToInt32(ReceiptBatchAbsEntry); //AbsEntry from OBTN Table
                oMaterialRevaluationSNBLines.NewCost = cost;
                oMaterialRevaluationSNBLines.Add();
                int RetVal = oMaterialRevaluation.Add();
                string ErrStr = "";
                if (RetVal != 0)
                {
                    Packing.oCompany.GetLastError(out RetVal, out ErrStr);
                    //MessageBox.Show(ErrStr.ToString().Trim());
                }
                else
                {
                    oMaterialRevaluation.SaveXML(@"C:\MYFOLDER\MaterialRevaluation.xml");
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion

        public static string setCrystalReport(string TypeName, string AddonName, string AddonFormType, string MenuID, string rptName, string rptPath, SAPbouiCOM.Form oForm)
        {
            SAPbobsCOM.Recordset oRs = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
            oRs.DoQuery("SELECT * FROM RDOC WHERE DocName='" + rptName + "'"); //Internal Quality Check
            if (oRs.EoF)
            {
                SAPbobsCOM.ReportTypesService rptTypeService = oCompany.GetCompanyService().GetBusinessService(SAPbobsCOM.ServiceTypes.ReportTypesService);
                SAPbobsCOM.ReportType newType = (SAPbobsCOM.ReportType)rptTypeService.GetDataInterface(SAPbobsCOM.ReportTypesServiceDataInterfaces.rtsReportType);
                newType.TypeName = TypeName; //"IQC"
                newType.AddonName = AddonName;//"IQC"
                newType.AddonFormType = AddonFormType;//"IQC"
                newType.MenuID = MenuID;// "IQC";
                SAPbobsCOM.ReportTypeParams newTypeParam = rptTypeService.AddReportType(newType);

                SAPbobsCOM.ReportLayoutsService rptService = (SAPbobsCOM.ReportLayoutsService)oCompany.GetCompanyService().GetBusinessService(SAPbobsCOM.ServiceTypes.ReportLayoutsService);
                SAPbobsCOM.ReportLayout newReport = (SAPbobsCOM.ReportLayout)rptService.GetDataInterface(SAPbobsCOM.ReportLayoutsServiceDataInterfaces.rlsdiReportLayout);
                newReport.Author = oCompany.UserName;
                newReport.Category = SAPbobsCOM.ReportLayoutCategoryEnum.rlcCrystal;
                newReport.Name = rptName;// "Internal Quality Check";
                newReport.TypeCode = newTypeParam.TypeCode;
                SAPbobsCOM.ReportLayoutParams newReportParam = rptService.AddReportLayout(newReport);

                newType = rptTypeService.GetReportType(newTypeParam);
                newType.DefaultReportLayout = newReportParam.LayoutCode;
                rptTypeService.UpdateReportType(newType);

                SAPbobsCOM.BlobParams oBlobParams = (SAPbobsCOM.BlobParams)oCompany.GetCompanyService().GetDataInterface(SAPbobsCOM.CompanyServiceDataInterfaces.csdiBlobParams);
                oBlobParams.Table = "RDOC";
                oBlobParams.Field = "Template";
                SAPbobsCOM.BlobTableKeySegment oKeySegment = oBlobParams.BlobTableKeySegments.Add();
                oKeySegment.Name = "DocCode";
                oKeySegment.Value = newReportParam.LayoutCode;


                FileStream oFile = new FileStream(Application.StartupPath.ToString() + "\\" + rptPath, System.IO.FileMode.Open);  //IQC.rpt
                int fileSize = (int)oFile.Length;
                byte[] buf = new byte[fileSize];
                oFile.Read(buf, 0, fileSize);
                oFile.Dispose();
                SAPbobsCOM.Blob oBlob = (SAPbobsCOM.Blob)oCompany.GetCompanyService().GetDataInterface(SAPbobsCOM.CompanyServiceDataInterfaces.csdiBlob);
                oBlob.Content = Convert.ToBase64String(buf, 0, fileSize);
                oCompany.GetCompanyService().SetBlob(oBlobParams, oBlob);

                oForm.ReportType = newReport.TypeCode;
            }
            else
            {
                oForm.ReportType = oRs.Fields.Item("TypeCode").Value.ToString();
            }


            return "";

        }


        #region LoadFromXML

        public void LoadFromXML(String FormName)
        {
            try
            {
                string sXmlFileName;
                sXmlFileName = Application.StartupPath.ToString();
                sXmlFileName = sXmlFileName + "\\" + FormName + ".srf";
                XmlDocument oXmlDoc = new XmlDocument();
                oXmlDoc.Load(sXmlFileName);
                string sXML = oXmlDoc.InnerXml.ToString();
                SBO_Application.LoadBatchActions(ref sXML);
                oForm = SBO_Application.Forms.ActiveForm;

                #region PackingCredit
                if (FormName == "PackingCredit")
                {
                    oForm = Packing.SBO_Application.Forms.Item("PackingCredit");
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;

                    oForm.EnableMenu("1288", true);
                    oForm.EnableMenu("1289", true);
                    oForm.EnableMenu("1290", true);
                    oForm.EnableMenu("1291", true);
                    //oForm.EnableMenu("1292", true);
                    //oForm.EnableMenu("1283", false);
                    //oForm.EnableMenu("1287", true);
                    //oForm.EnableMenu("1286", false);
                    //oForm.EnableMenu("1284", false);

                    oForm.DataBrowser.BrowseBy = "DocEntry";
                    //AddChooseFromList();

                    string NowDate = Packing.oCompany.GetCompanyDate().ToString("yyyyMMdd").Replace("/", "-");
                    oForm.Items.Item("Item_15").Specific.value = NowDate;
                    oForm.Items.Item("Item_15").Enabled = false;

                    string Sql = "SELECT (CASE WHEN (ISNULL(MAX(CONVERT(NUMERIC,DocEntry) ),0))=0 THEN 1 ELSE (MAX(CONVERT(NUMERIC,DocEntry)) + 1) END) AS CODE FROM [dbo].[@OPCF]";
                    SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    oRset.DoQuery(Sql);

                    if (oRset.RecordCount > 0)
                    {
                        oForm.Items.Item("DocEntry").Specific.value = Convert.ToString(oRset.Fields.Item("CODE").Value);
                        oForm.Items.Item("Item_13").Specific.value = Convert.ToString(oRset.Fields.Item("CODE").Value);
                    }
                    // oForm.Items.Item("Item_17").Specific.value = NowDate;
                    //oForm.Items.Item("Item_17").Enabled = false;
                }
                #endregion

                #region Program Sheet
                if (FormName == "ProgramSheet")
                {
                    oForm = Packing.SBO_Application.Forms.Item("OPST");
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;

                    oForm.EnableMenu("1288", true);
                    oForm.EnableMenu("1289", true);
                    oForm.EnableMenu("1290", true);
                    oForm.EnableMenu("1291", true);

                    oForm.EnableMenu("1287", true);

                    oForm.DataBrowser.BrowseBy = "DocEntry";
                    //AddChooseFromList();

                    oForm.EnableMenu("1292", true);
                    oForm.EnableMenu("1293", true);

                    ProgSheetformLoad();

                }
                #endregion

            }
            catch (Exception ex)
            {
                SBO_Application.StatusBar.SetText("LoadFromXML : " + ex.Message,SAPbouiCOM.BoMessageTime.bmt_Short,SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        private void ProgSheetformLoad()
        {
            SAPbouiCOM.Matrix MatGen = oForm.Items.Item("Item_23").Specific;
            SAPbouiCOM.Matrix MatDesgn = oForm.Items.Item("Item_26").Specific;
            MatGen.AutoResizeColumns();
            MatDesgn.AutoResizeColumns();
            oForm.Items.Item("Item_19").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

            string NowDate = Packing.oCompany.GetCompanyDate().ToString("yyyyMMdd").Replace("/", "-");
            oForm.Items.Item("Item_6").Specific.value = NowDate;
            oForm.Items.Item("Item_15").Enabled = false;

            //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_5").Specific;
            //try
            //{
            //    oEdit = "Open";
            //}
            //catch
            //{ }

            string Sql = "SELECT (CASE WHEN (ISNULL(MAX(CONVERT(NUMERIC,DocNum) ),0))=0 THEN 1 ELSE (MAX(CONVERT(NUMERIC,DocNum)) + 1) END) AS CODE FROM [dbo].[@OPST]";
            SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
            oRset.DoQuery(Sql);

            if (oRset.RecordCount > 0)
            {
                oForm.Items.Item("DocNum").Specific.value = Convert.ToString(oRset.Fields.Item("CODE").Value);
                //oForm.Items.Item("Item_13").Specific.value = Convert.ToString(oRset.Fields.Item("CODE").Value);
            }

            oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Item_0").Specific;
            oCombo.ValidValues.LoadSeries("OPST", SAPbouiCOM.BoSeriesMode.sf_Add);

            SAPbobsCOM.Recordset oRS = null;
            oRS = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
            string strSQL = null;
            strSQL = "Select T1.Series, T1.SeriesName, T1.NextNumber From ONNM T0 Inner Join NNM1 T1 On T0.ObjectCode=T1.ObjectCode Where T0.ObjectCode='OPST' And T1.Locked='N' And T0.DfltSeries=T1.Series";
            oRS.DoQuery(strSQL);
            string strSeries = "";
            if (oRS.RecordCount > 0)
            {
                strSeries = oRS.Fields.Item("Series").Value.ToString();
            }
            else
            {
                SBO_Application.MessageBox("Please define Document numbering series...", 1, "OK");
                return;
            }
            oRS = null;
            oCombo.Select(strSeries, SAPbouiCOM.BoSearchKey.psk_ByValue);

            //oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("40").Specific;
            //oCombo.ValidValues.Add("Mtr", "Meters");
            //oCombo.ValidValues.Add("Yard", "Yards");
            //oCombo.ValidValues.Add("Pcs", "Pieces");
            //oCombo.ValidValues.Add("Bale", "Bales");
            //oCombo.ValidValues.Add("KG", "Kilo Grams");

            //oCombo.Select("Mtr", SAPbouiCOM.BoSearchKey.psk_ByValue);

            oMatrix = oForm.Items.Item("Item_23").Specific;

            oMatrix.AddRow(1, 0);
            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();

            oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_23", 1));
            oCheckBox.Checked = true;

            oCombo = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("V_2").Cells.Item(1).Specific;

            oCombo.ValidValues.Add("Mtr", "Meters");
            oCombo.ValidValues.Add("Yard", "Yards");
            oCombo.ValidValues.Add("Pcs", "Pieces");
            oCombo.ValidValues.Add("Bale", "Bales");
            oCombo.ValidValues.Add("KG", "Kilo Grams");

            #region Country
            oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("1000001").Specific;

            SAPbobsCOM.Recordset oRS_Process = null;
            oRS_Process = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
            strSQL = null;
            strSQL = "select Code,Name from OCRY";
            oRS_Process.DoQuery(strSQL);
            strSeries = "";
            if (oRS_Process.RecordCount > 0)
            {
                for (int i = 0; i < oRS_Process.RecordCount; i++)
                {
                    oCombo.ValidValues.Add(oRS_Process.Fields.Item("Code").Value.ToString(), oRS_Process.Fields.Item("Name").Value.ToString());
                    oRS_Process.MoveNext();
                }

            }
            oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);

            #endregion
            oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Item_5").Specific;
            oCombo.ValidValues.Add("O", "Open");
            oCombo.ValidValues.Add("C", "Close");

            #region Row Stage

            oCombo = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("V_3").Cells.Item(1).Specific;

            SAPbobsCOM.Recordset oRS_Process_Row = null;
            oRS_Process_Row = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
            strSQL = null;
            strSQL = "select Code,Name from [@STAGE]";
            oRS_Process_Row.DoQuery(strSQL);
            strSeries = "";
            if (oRS_Process_Row.RecordCount > 0)
            {
                for (int i = 0; i < oRS_Process_Row.RecordCount; i++)
                {
                    oCombo.ValidValues.Add(oRS_Process_Row.Fields.Item("Code").Value.ToString(), oRS_Process_Row.Fields.Item("Name").Value.ToString());
                    oRS_Process_Row.MoveNext();
                }

            }
            oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
            #endregion

            #region Row Currency

            //oCombo = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("V_11").Cells.Item(1).Specific;

            //oRS_Process_Row = null;
            //oRS_Process_Row = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
            //strSQL = null;
            //strSQL = "select CurrCode,CurrName from OCRN";
            //oRS_Process_Row.DoQuery(strSQL);
            //strSeries = "";
            //if (oRS_Process_Row.RecordCount > 0)
            //{
            //    for (int i = 0; i < oRS_Process_Row.RecordCount; i++)
            //    {
            //        oCombo.ValidValues.Add(oRS_Process_Row.Fields.Item("CurrCode").Value.ToString(), oRS_Process_Row.Fields.Item("CurrName").Value.ToString());
            //        oRS_Process_Row.MoveNext();
            //    }

            //}
            //oCombo.Select("USD", SAPbouiCOM.BoSearchKey.psk_ByValue);
            #endregion

            SAPbouiCOM.ButtonCombo oComboButton = (SAPbouiCOM.ButtonCombo)oForm.Items.Item("43").Specific;
            oComboButton.ValidValues.Add("22", "Purchase Order");
            oComboButton.ValidValues.Add("67", "Issue To Job Worker");
            oComboButton.ValidValues.Add("1250000001", "Inventory Transfer Request");
            oComboButton.ValidValues.Add("60", "Goods Issue");
            oComboButton.ValidValues.Add("59", "Goods Receipt");
            oComboButton.ValidValues.Add("OPCK", "Packing List");
            //oComboButton.ValidValues.Add("OFT", "5 Taka Report");


            oMatrix = oForm.Items.Item("Item_28").Specific;

            oMatrix.AddRow(1, 0);
            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
            oCombo = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("Col_0").Cells.Item(1).Specific;

            oCombo.ValidValues.Add("22", "Purchase Order");
            oCombo.ValidValues.Add("1250000001", "Inventory Transfer Request");
            oCombo.ValidValues.Add("60", "Goods Issue");
            oCombo.ValidValues.Add("59", "Goods Receipt");
            oCombo.ValidValues.Add("OPCK", "Packing List");

            oCombo = ((SAPbouiCOM.ComboBox)oForm.Items.Item("Item_5").Specific);
            //oCombo.Select(""
            try
            {
                oCombo.ValidValues.Add("O", "Open");
                oCombo.ValidValues.Add("C", "Close");
            }
            catch { }
            oCombo.Select("O", SAPbouiCOM.BoSearchKey.psk_ByValue);



            oMatrix = oForm.Items.Item("Item_26").Specific;

            oMatrix.AddRow(1, 0);
            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();

            oCombo = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("Col_3").Cells.Item(1).Specific;

            oCombo.ValidValues.Add("Mtr", "Meters");
            oCombo.ValidValues.Add("Yard", "Yards");
            oCombo.ValidValues.Add("Pcs", "Pieces");
            oCombo.ValidValues.Add("Bale", "Bales");
            oCombo.ValidValues.Add("KG", "Kilo Grams");

            oForm.Items.Item("Item_4").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

        }

        public static object PackingCredit_Form { get; set; }

        # endregion
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using System.Xml;

namespace Packing.Transactions
{
    class ProgramSheet
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item("OPST");
                if (pVal.BeforeAction == true)
                {
                    #region choose from list customer
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_4")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();

                        oCon = oCons.Add();

                        oCon.Alias = "CardType";
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = "C";

                        oCFL.SetConditions(oCons);

                    }
                    #endregion

                    #region choose from list Sales Order
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_2")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        String CardCode = "";
                        CardCode = oForm.Items.Item("Item_4").Specific.value;
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL
                        //oCFL1 = oForm.ChooseFromLists.Item(sCFL_ID);

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();

                        oCon = oCons.Add();

                        oCon.Alias = "DocStatus";
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = "O";
                        oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND;                      
                        
                        
                        oCon = oCons.Add();
                        oCon.Alias = "CardCode";
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = CardCode;

                        oCFL.SetConditions(oCons);
                    }
                    #endregion


                    #region choose from list Jobworker Row
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_23" && pVal.ColUID=="Col_8")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        String CardCode = "";
                        //CardCode = oForm.Items.Item("Item_4").Specific.value;
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL
                        //oCFL1 = oForm.ChooseFromLists.Item(sCFL_ID);

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();

                        oCon = oCons.Add();

                        oCon.Alias = "U_Whse";
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_NOT_NULL;
                        //oCon.CondVal = "102";
                       // oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND;


                        oCFL.SetConditions(oCons);
                    }

                    #endregion

                    #region choose from list Port
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "41")
                    {
                        string country = ((SAPbouiCOM.ComboBox)oForm.Items.Item("1000001").Specific).Selected.Value.ToString();
                        if (country != "")
                        {
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                            oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                            string sCFL_ID = null;
                            sCFL_ID = oCFLEvento.ChooseFromListUID;
                            oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL

                            oCFL.SetConditions(null);
                            oCons = oCFL.GetConditions();

                            oCon = oCons.Add();

                            oCon.Alias = "U_Country";
                            oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                            oCon.CondVal = country;

                            oCFL.SetConditions(oCons);
                        }
                        else
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please Select Country First", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                        }

                    }
                    #endregion

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN && pVal.ItemUID == "Item_23" && (pVal.ColUID == "V_1" || pVal.ColUID == "Col_6" || pVal.ColUID == "V_10" || pVal.ColUID == "V_24"))
                    {
                        oMatrix = oForm.Items.Item("Item_23").Specific;
                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_23", pVal.Row));
                        if (oCheckBox.Checked && pVal.CharPressed!=9)
                        {
                            return false;
                        }
                    }

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "Item_28" && pVal.ColUID == "Col_0")
                    {
                        return false;
                    }

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN && pVal.ItemUID == "Item_23" && pVal.ColUID == "V_11")
                    {
                        int key = pVal.CharPressed;
                        if (key != 9 && key != 15)
                        {
                            return false;
                        }

                    }
                }

                else if (pVal.BeforeAction == false)
                {
                    #region Choose from List
                    #region choose from list customer
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_4")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;
                        
                      
                        Value = oDataTable.GetValue("CardCode", 0).ToString();
                        val2 = oDataTable.GetValue("CardName", 0).ToString();
                        string val3 = oDataTable.GetValue("U_SerialPre", 0).ToString();

                        if (val3 != null)
                        {
                            if (val3 != "")
                            {

                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_1").Specific;
                                oEdit1 = (SAPbouiCOM.EditText)oForm.Items.Item("Item_4").Specific;
                                try
                                {
                                    oEdit.Value = val2;

                                }
                                catch { }

                                try
                                {
                                    oEdit1.Value = Value;

                                }
                                catch { }

                                string max_serial = oDal.ExSelect("select top 1 U_Serial from [@OPST] where U_Serial like '" + val3 + "%' and U_BuyrCde='" + Value + "' order by Docentry Desc", "");
                                if (max_serial == "")
                                {
                                    max_serial = val3 + "1";
                                }
                                else
                                {
                                    max_serial = max_serial.Substring(val3.Length);
                                    max_serial=val3+(Convert.ToInt32(max_serial)+1).ToString();
                                }
                                ((SAPbouiCOM.EditText)oForm.Items.Item("45").Specific).Value = max_serial;
                            }
                            else
                            {
                                Packing.SBO_Application.StatusBar.SetText("Please Enter Customer Series in Customer Master!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                        else
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please Enter Customer Series in Customer Master!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }

                    }
                    #endregion

                    #region choose from list customer
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "41")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;


                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;


                        Value = oDataTable.GetValue("Code", 0).ToString();
                        val2 = oDataTable.GetValue("Name", 0).ToString();
                        //string val3 = oDataTable.GetValue("U_SerialPre", 0).ToString();

                     

                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("41").Specific;
                        oEdit1 = (SAPbouiCOM.EditText)oForm.Items.Item("50").Specific;
                        try
                        {
                            oEdit.Value = Value;

                        }
                        catch { }

                        try
                        {
                            oEdit1.Value = val2;

                        }
                        catch { }

                               

                    }
                    #endregion

                    #region choose from list Sales Order
                    else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_2")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("DocNum", 0).ToString();
                        val2 = oDataTable.GetValue("DocDate", 0).ToString("yyyyMMdd");
                        val3 = oDataTable.GetValue("DocEntry", 0).ToString();
                        //U_DocDate.Value = ToDate.ToString("yyyyMMdd")
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_2").Specific;
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_3").Specific;
                        try
                        {
                            oEdit.Value = val2;
                        }
                        catch { }
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_21").Specific;
                        try
                        {
                            oEdit.Value = val3;
                        }
                        catch { }
                    }
                    #endregion


                    #region choose from list JobWorker Row
                    else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_23" && pVal.ColUID == "Col_8")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("CardCode", 0).ToString();
                        val2 = oDataTable.GetValue("CardName", 0).ToString();
                        val3 = oDataTable.GetValue("U_Whse", 0).ToString();

                        oMatrix = oForm.Items.Item("Item_23").Specific;

                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_8",pVal.Row);
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row);
                        try
                        {
                            oEdit.Value = val2;
                        }
                        catch { }
                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_9", pVal.Row);
                        try
                        {
                            oEdit.Value = val3;
                        }
                        catch { }

                        if (oMatrix.VisualRowCount == pVal.Row)
                        {
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                oMatrix.AddRow(1, oMatrix.VisualRowCount);
                            }
                            else if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(1);
                                oMatrix.FlushToDataSource();
                                oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                
                                oMatrix.LoadFromDataSource();
                            }
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                            oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_23", oMatrix.VisualRowCount));
                            oCheckBox.Checked = true;
                            oMatrix.Columns.Item("V_4").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }
                    }
                    #endregion

                    #region choose from list Item Header
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "32")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;


                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;


                        Value = oDataTable.GetValue("ItemCode", 0).ToString();
                        val2 = oDataTable.GetValue("ItemName", 0).ToString();
                        //val2 = oDataTable.GetValue("Name", 0).ToString();
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("32").Specific;
                        oEdit1 = (SAPbouiCOM.EditText)oForm.Items.Item("35").Specific;
                        try
                        {
                            oEdit.Value = Value;
                            
                        }
                        catch { }

                        try
                        {
                            oEdit1.Value = val2;

                        }
                        catch { }
                        


                    }
                    #endregion

                    #region choose from list Item Row
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_23" && pVal.ColUID == "V_4")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;


                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;


                        val1 = oDataTable.GetValue("ItemCode", 0).ToString();
                        val2 = oDataTable.GetValue("ItemName", 0).ToString();
                        //val2 = oDataTable.GetValue("Name", 0).ToString();
                        oMatrix = oForm.Items.Item("Item_23").Specific;

                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row);
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row);
                        try
                        {
                            oEdit.Value = val2;
                        }
                        catch { }

                    }
                    #endregion

                    #endregion

                    #region Open SAP Forms using Program sheet row
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT && pVal.ItemUID == "43")//&& pVal.ColUID == "Col_0"
                    {
                        oMatrix = oForm.Items.Item("Item_23").Specific;
                        SAPbouiCOM.ButtonCombo oComboButton = (SAPbouiCOM.ButtonCombo)oForm.Items.Item("43").Specific;
                        string val = oComboButton.Selected.Value.ToString();
                        int Selrow= oMatrix.GetNextSelectedRow(0,SAPbouiCOM.BoOrderType.ot_RowOrder);

                        if (Selrow != -1)
                        {
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_EDIT_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                            {
                                string docnum = ((SAPbouiCOM.EditText)oForm.Items.Item("DocNum").Specific).Value.ToString();
                                string Series = ((SAPbouiCOM.ComboBox)oForm.Items.Item("Item_0").Specific).Selected.Value.ToString();
                                string docentry = ((SAPbouiCOM.EditText)oForm.Items.Item("DocEntry").Specific).Value.ToString();
                                string jobworker = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_8", Selrow)).Value.ToString();
                                string jobworkerNm = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", Selrow)).Value.ToString();
                                string Label = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_30", Selrow)).Value.ToString();
                                string fromwh = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_9", Selrow)).Value.ToString();
                                string prgSerial = ((SAPbouiCOM.EditText)oForm.Items.Item("45").Specific).Value.ToString();
                                string LineNum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", Selrow)).Value.ToString();

                                string towarehouse = "";
                                try
                                {
                                    towarehouse = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_9", (Selrow + 1))).Value.ToString();
                                }
                                catch
                                { }



                                switch (val)
                                {
                                    case "22":
                                        Packing.SBO_Application.ActivateMenuItem("2305");
                                        xForm = Packing.SBO_Application.Forms.GetForm("142", 1);
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgDN").Specific).Value = docnum;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgDE").Specific).Value = docentry;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtJobWrkr").Specific).Value = jobworker;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtJobNm").Specific).Value = jobworkerNm;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtLabel").Specific).Value = Label;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgSer").Specific).Value = prgSerial;
                                        break;

                                    case "1250000001":
                                        Packing.SBO_Application.ActivateMenuItem("3088");
                                        xForm = Packing.SBO_Application.Forms.GetForm("1250000940", 1);
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgDN").Specific).Value = docnum;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgDE").Specific).Value = docentry;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtJobWrkr").Specific).Value = jobworker;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtJobNm").Specific).Value = jobworkerNm;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtLabel").Specific).Value = Label;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("18").Specific).Value = fromwh;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("1470000101").Specific).Value = towarehouse;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgSer").Specific).Value = prgSerial;
                                        break;

                                    case "60":
                                        Packing.SBO_Application.ActivateMenuItem("3079");
                                        xForm = Packing.SBO_Application.Forms.GetForm("720", 1);
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgDN").Specific).Value = docnum;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgDE").Specific).Value = docentry;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtJobWrkr").Specific).Value = jobworker;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtJobNm").Specific).Value = jobworkerNm;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtLabel").Specific).Value = Label;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgSer").Specific).Value = prgSerial;
                                        break;

                                    case "59":
                                        Packing.SBO_Application.ActivateMenuItem("3078");
                                        xForm = Packing.SBO_Application.Forms.GetForm("721", 1);
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgDN").Specific).Value = docnum;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgDE").Specific).Value = docentry;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtJobWrkr").Specific).Value = jobworker;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtJobNm").Specific).Value = jobworkerNm;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtLabel").Specific).Value = Label;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgSer").Specific).Value = prgSerial;
                                        break;


                                    case "67":
                                        Packing.SBO_Application.ActivateMenuItem("3080");
                                        xForm = Packing.SBO_Application.Forms.GetForm("940", 1);
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("18").Specific).Value = "01";
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("1470000101").Specific).Value = fromwh;
                                        //oMatrix = xForm.Items.Item("35").Specific;
                                        //oMatrix.AddRow(1, 0);
                                        //((SAPbouiCOM.EditText)xForm.Items.Item("txtJobWrkr").Specific).Value = jobworker;
                                        //((SAPbouiCOM.EditText)xForm.Items.Item("txtJobNm").Specific).Value = jobworkerNm;
                                        //((SAPbouiCOM.EditText)xForm.Items.Item("txtLabel").Specific).Value = Label;
                                        //((SAPbouiCOM.EditText)xForm.Items.Item("txtPrgSer").Specific).Value = prgSerial;
                                        break;


                                }
                            }
                            else
                            {
                                Packing.SBO_Application.StatusBar.SetText("Please Add Document First!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                        else
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please Select Row!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                    }
                    #endregion

                    #region Open SAP form from Related Documents
                    if (pVal.ItemUID == "Item_28" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK && pVal.ColUID=="#")
                    {
                        oMatrix = oForm.Items.Item("Item_28").Specific;
                        string doctype = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_0", pVal.Row)).Value.ToString();
                        string docentry = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_1", pVal.Row)).Value.ToString();
                        //string doctype = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_0", pVal.Row)).Value.ToString();

                        if (doctype == "22")
                        {
                            Packing.SBO_Application.ActivateMenuItem("2305");
                            xForm = Packing.SBO_Application.Forms.GetForm("142", 1);
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            string docseries = oDal.ExSelect("select Series from OPOR where docentry='" + docentry + "'", "");
                            string docnum = oDal.ExSelect("select docnum from OPOR where docentry='" + docentry + "'", "");
                            ((SAPbouiCOM.ComboBox)xForm.Items.Item("88").Specific).Select(docseries, SAPbouiCOM.BoSearchKey.psk_ByValue);
                            ((SAPbouiCOM.EditText)xForm.Items.Item("8").Specific).Value = docnum;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }
                        else if (doctype == "59")
                        {
                            Packing.SBO_Application.ActivateMenuItem("3078");
                            xForm = Packing.SBO_Application.Forms.GetForm("721", 1);
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            string docseries = oDal.ExSelect("select Series from OIGN where docentry='" + docentry + "'", "");
                            string docnum = oDal.ExSelect("select docnum from OIGN where docentry='" + docentry + "'", "");
                            ((SAPbouiCOM.ComboBox)xForm.Items.Item("30").Specific).Select(docseries, SAPbouiCOM.BoSearchKey.psk_ByValue);
                            ((SAPbouiCOM.EditText)xForm.Items.Item("7").Specific).Value = docnum;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }
                        else if (doctype == "60")
                        {
                            Packing.SBO_Application.ActivateMenuItem("3079");
                            xForm = Packing.SBO_Application.Forms.GetForm("720", 1);
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            string docseries = oDal.ExSelect("select Series from OIGE where docentry='" + docentry + "'", "");
                            string docnum = oDal.ExSelect("select docnum from OIGE where docentry='" + docentry + "'", "");
                            ((SAPbouiCOM.ComboBox)xForm.Items.Item("30").Specific).Select(docseries, SAPbouiCOM.BoSearchKey.psk_ByValue);
                            ((SAPbouiCOM.EditText)xForm.Items.Item("7").Specific).Value = docnum;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }
                        else if (doctype == "1250000001")
                        {
                            Packing.SBO_Application.ActivateMenuItem("3088");
                            xForm = Packing.SBO_Application.Forms.GetForm("1250000940", 1);
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            string docseries = oDal.ExSelect("select Series from OWTQ where docentry='" + docentry + "'", "");
                            string docnum = oDal.ExSelect("select docnum from OWTQ where docentry='" + docentry + "'", "");
                            ((SAPbouiCOM.ComboBox)xForm.Items.Item("1250000068").Specific).Select(docseries, SAPbouiCOM.BoSearchKey.psk_ByValue);
                            ((SAPbouiCOM.EditText)xForm.Items.Item("11").Specific).Value = docnum;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }
                    }


                    #endregion

                    #region calculate qty in row
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "Item_23" && (pVal.ColUID == "V_6" || pVal.ColUID == "V_7" || pVal.ColUID == "V_8" ))
                    {
                        oMatrix = oForm.Items.Item("Item_23").Specific;
                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_23", pVal.Row));
                        if (oCheckBox.Checked )
                        {
                            try
                            {
                                string bale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", pVal.Row)).Value.ToString();
                                string Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", pVal.Row)).Value.ToString();
                                string Cut = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_8", pVal.Row)).Value.ToString();
                                string YardToMtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value.ToString();
                                oForm.Freeze(true);
                                //Meter
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", pVal.Row)).Value = (Convert.ToDouble(bale) * Convert.ToDouble(Pcs) * Convert.ToDouble(Cut) * Convert.ToDouble(YardToMtr)).ToString();
                                //Yards
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_6", pVal.Row)).Value = (Convert.ToDouble(bale) * Convert.ToDouble(Pcs) * Convert.ToDouble(Cut)).ToString();
                                //Pcs
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", pVal.Row)).Value = (Convert.ToDouble(bale) * Convert.ToDouble(Pcs)).ToString();
                                //Bale
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_24", pVal.Row)).Value = (Convert.ToDouble(bale)).ToString();

                                oForm.Freeze(false);
                            }
                            catch { oForm.Freeze(false); }
                        }
                    }
                    #endregion

                    #region Series Select fill  nex number
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT && pVal.ItemUID == "Item_0" && oForm.Mode==SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                    {
                       
                        oCombo = oForm.Items.Item("Item_0").Specific;
                        string series = oCombo.Selected.Value.ToString();
                        string nextnum = oDal.ExSelect("select NextNumber from NNM1 where Series='"+series+"' and ObjectCode='OPST'", "");
                        ((SAPbouiCOM.EditText)oForm.Items.Item("DocNum").Specific).Value = nextnum;
                    }
                    #endregion

                    #region DueDays
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "Item_8")
                    {
                        string dt = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_6").Specific).Value.ToString();
                        string days = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_8").Specific).Value.ToString();
                        if (days == "")
                            days = "0";

                        string dt1 = oDal.ExSelect("select REPLACE( convert(varchar(20), DATEADD(dd," + days + ",'" + dt + "'),104),'.','')", "");

                        ((SAPbouiCOM.EditText)oForm.Items.Item("Item_7").Specific).String = dt1;
                    }
                    #endregion

                    #region key pressed
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN && pVal.ItemUID == "Item_2")
                    {
                        int key = pVal.CharPressed;
                        if (key == 15)
                            oForm.Items.Item("46").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    }


                    #endregion

                    #region add row in Design matrix
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "Item_26" && pVal.ColUID == "Col_0")
                    {
                        try
                        {
                            oForm.Freeze(true);

                            oMatrix = oForm.Items.Item("Item_26").Specific;
                            string val = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_0", oMatrix.VisualRowCount)).Value.ToString();
                            if (oMatrix.VisualRowCount == pVal.Row && val != "")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    oMatrix.AddRow(1, oMatrix.VisualRowCount);
                                }
                                else if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                                {
                                    //oMatrix = oForm.Items.Item("6").Specific;
                                    int a = oMatrix.VisualRowCount;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@PST2");
                                    //oMatrix.FlushToDataSource();
                                    oDbDataSource.InsertRecord(a);
                                    oMatrix.LoadFromDataSource();
                                }
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_1", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_2", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_4", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_5", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_6", oMatrix.VisualRowCount)).Value = "";

                                oMatrix1 = oForm.Items.Item("Item_23").Specific;
                                string UOM = "";//.Value.ToString();
                                if (((SAPbouiCOM.ComboBox)oMatrix1.GetCellSpecific("V_2", 1)).Selected != null)
                                {
                                    UOM = ((SAPbouiCOM.ComboBox)oMatrix1.GetCellSpecific("V_2", 1)).Selected.Value.ToString();
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", oMatrix.VisualRowCount)).Select(UOM, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }
                            }

                            oCombo = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", pVal.Row));

                            if (oCombo.Selected == null)
                            {
                                oMatrix1 = oForm.Items.Item("Item_23").Specific;
                                string UOM = "";//.Value.ToString();
                                if (((SAPbouiCOM.ComboBox)oMatrix1.GetCellSpecific("V_2", 1)).Selected != null && pVal.Row == 1)
                                {
                                    UOM = ((SAPbouiCOM.ComboBox)oMatrix1.GetCellSpecific("V_2", 1)).Selected.Value.ToString();
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", pVal.Row)).Select(UOM, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }
                                else if (((SAPbouiCOM.ComboBox)oMatrix1.GetCellSpecific("V_2", 1)).Selected != null && pVal.Row > 1)
                                {
                                    UOM = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", (pVal.Row - 1))).Selected.Value.ToString();
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", pVal.Row)).Select(UOM, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }

                            }
                            else
                            {
                                oMatrix1 = oForm.Items.Item("Item_23").Specific;
                                string UOM = "";//.Value.ToString();
                                string ogUOM="";
                                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", pVal.Row);
                                if(oCombo.Selected!=null)
                                {
                                    UOM=oCombo.Selected.Value.ToString();
                                }

                                if ( pVal.Row == 1)
                                {
                                    ogUOM = ((SAPbouiCOM.ComboBox)oMatrix1.GetCellSpecific("V_2", 1)).Selected.Value.ToString();
                                    
                                }
                                else if (((SAPbouiCOM.ComboBox)oMatrix1.GetCellSpecific("V_2", 1)).Selected != null && pVal.Row > 1)
                                {
                                    ogUOM = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", (pVal.Row - 1))).Selected.Value.ToString();
                                    //((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", pVal.Row)).Select(UOM, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }

                                if (UOM != ogUOM)
                                {
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("Col_3", pVal.Row)).Select(ogUOM, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }
                            }
                            oForm.Freeze(false);
                        }
                        catch
                        { oForm.Freeze(false); }
                    }

                    #endregion

                    #region open other details
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN && pVal.ItemUID == "Item_23" && pVal.ColUID=="V_11")
                    {
                        int key = pVal.CharPressed;
                        if (key == 15)
                        {
                            oMatrix = oForm.Items.Item("Item_23").Specific;
                            string OthDet = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID,pVal.Row)).Value.ToString();
                            Packing.PrgSheet_CurrentRow = pVal.Row;

                            LoadFromXML("OtherDetail");

                            xForm = Packing.SBO_Application.Forms.Item("PST1D");

                            oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                            
                            
                            if (OthDet != "")
                            {
                                xForm = Packing.SBO_Application.Forms.Item("PST1D");
                                xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                ((SAPbouiCOM.EditText)xForm.Items.Item("3").Specific).Value = OthDet;
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            }
                            else
                            {
                                xForm = Packing.SBO_Application.Forms.Item("PST1D");
                                xForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;

                                oCombo = (SAPbouiCOM.ComboBox)xForm.Items.Item("75").Specific;

                                oCombo.Select("USD", SAPbouiCOM.BoSearchKey.psk_ByValue);
                            }
                        }
                        

                    }


                    #endregion

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED && pVal.ItemUID == "1" && pVal.ActionSuccess == true)
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            form_load_default();
                        }
                    }


                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        Packing.setCrystalReport("OPST", "OPST", "OPST", "OPST", "Program Sheet", "SO_VOU_NW.rpt", oForm);
                    }

                    


                }
                return true;
            }
            catch
            { return false; }
        }



        public void LoadFromXML(String FormName)
        {
            string sXmlFileName;
            string QStr = null;
            string DocEnt = null;
            int Docentry = 0;

            //SAPbobsCOM.Recordset InsertRec = null;
            //InsertRec = (SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset));

            sXmlFileName = Application.StartupPath.ToString();
            sXmlFileName = sXmlFileName + "\\" + FormName + ".srf";
            XmlDocument oXmlDoc = new XmlDocument();
            oXmlDoc.Load(sXmlFileName);
            string sXML = oXmlDoc.InnerXml.ToString();
            Packing.SBO_Application.LoadBatchActions(ref sXML);
            oForm = Packing.SBO_Application.Forms.ActiveForm;

            if (FormName == "OtherDetail")
            {
                ProgSheet_details_formLoad();
            }

        }

        public void SBO_Application_LayoutKeyEvent(ref SAPbouiCOM.LayoutKeyInfo pVal, bool BubbleEvent)
        {
            BubbleEvent = true;
            SAPbouiCOM.Form oForm = Packing.SBO_Application.Forms.ActiveForm;
            SAPbouiCOM.EditText oEdit = oForm.Items.Item("DocEntry").Specific;
            pVal.LayoutKey = oEdit.Value.ToString().Trim();

        }

       
        private void ProgSheet_details_formLoad()
        {
            oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("75").Specific;

            SAPbobsCOM.Recordset oRS_Process_Row = null;
            oRS_Process_Row = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
            string strSQL = null;
            strSQL = "select CurrCode,CurrName from OCRN";
            oRS_Process_Row.DoQuery(strSQL);
            
            if (oRS_Process_Row.RecordCount > 0)
            {
                for (int i = 0; i < oRS_Process_Row.RecordCount; i++)
                {
                    oCombo.ValidValues.Add(oRS_Process_Row.Fields.Item("CurrCode").Value.ToString(), oRS_Process_Row.Fields.Item("CurrName").Value.ToString());
                    oRS_Process_Row.MoveNext();
                }

            }
            oCombo.Select("USD", SAPbouiCOM.BoSearchKey.psk_ByValue);
            


        }

        public void form_load_default()
        {
            string NowDate = Packing.oCompany.GetCompanyDate().ToString("yyyyMMdd").Replace("/", "-");
            oForm.Items.Item("Item_6").Specific.value = NowDate;
            oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Item_0").Specific;
            try
            {
                oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
            }
            catch { }
            SAPbouiCOM.Matrix MatGen = oForm.Items.Item("Item_23").Specific;
            SAPbouiCOM.Matrix MatDesgn = oForm.Items.Item("Item_26").Specific;
            MatGen.AddRow(1, 0);
            oCheckBox = ((SAPbouiCOM.CheckBox)MatGen.GetCellSpecific("V_23", 1));
            oCheckBox.Checked = true;
            ((SAPbouiCOM.EditText)MatGen.GetCellSpecific("V_9", 1)).Value = "0.9144";


            MatDesgn.AddRow(1, 0);

            oCombo = ((SAPbouiCOM.ComboBox)oForm.Items.Item("Item_5").Specific);
            
            oCombo.Select("O", SAPbouiCOM.BoSearchKey.psk_ByValue);

            oMatrix = oForm.Items.Item("Item_26").Specific;
            oMatrix.AddRow(1, 0);

            oForm.Items.Item("Item_4").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

        }
        
    }
}

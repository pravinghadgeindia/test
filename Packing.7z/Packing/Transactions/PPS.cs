﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using System.Xml;


namespace Packing.Transactions
{
    class PPS
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;
        private string headerTable = "@PPS";
        private string childTable = "@PPS1";
        private string matrixUID = "7";

        #endregion

        public void itemevent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item("PPS");

                #region pVal.BeforeAction == true
                if (pVal.BeforeAction == true)
                {
                    #region Choose from list
                    if (pVal.ItemUID == "7" && pVal.ColUID == "V_2" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();

                        string icode = ((SAPbouiCOM.EditText)oForm.Items.Item("5").Specific).Value.ToString();
                        string whse = ((SAPbouiCOM.EditText)oForm.Items.Item("9").Specific).Value.ToString();

                        //string query = "select DistNumber from OBTN where ItemCode='"+icode+"' and isnull(U_FRptRdDt,'20170101')>'20170101' and isnull(U_StpLot,'N')= 'N'";
                        string query = "select BatchNum [DistNumber] from OIBT where ItemCode='" + icode + "' and isnull(U_FRptRdDt,'20170101')>'20170101' and isnull(U_StpLot,'N')= 'N'  and WhsCode='" + whse + "' and Quantity >0";
                        SAPbobsCOM.Recordset oRs_batch = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        oRs_batch.DoQuery(query);

                        if (oRs_batch.RecordCount > 0)
                        {
                            oCon = oCons.Add();
                            for (int i = 0; i < oRs_batch.RecordCount; i++)
                            {
                                if (i > 0)
                                {
                                    oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                                    oCon = oCons.Add();
                                }

                                oCon.Alias = "DistNumber";
                                oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                                oCon.CondVal = oRs_batch.Fields.Item("DistNumber").Value.ToString();


                                oRs_batch.MoveNext();
                            }
                        }
                        else
                        {
                            oCon = oCons.Add();
                            oCon.Alias = "DistNumber";
                            oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                            oCon.CondVal = "";
                        }
                        oCFL.SetConditions(oCons);
                    }

                    #endregion

                    #region check qty
                    if (pVal.ItemUID == "1" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE))
                    {
                        oForm.Items.Item("btnRef").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        oMatrix = oForm.Items.Item("7").Specific;
                        for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                        {
                            string avlqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value.ToString();
                            string avlpcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value.ToString();

                            string entqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value.ToString();
                            string entpcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value.ToString();

                            if (Convert.ToDouble(avlqty) < Convert.ToDouble(entqty) || Convert.ToDouble(avlpcs) < Convert.ToDouble(entpcs))
                            {
                                Packing.SBO_Application.StatusBar.SetText("Excess Qty found in line num " + i.ToString() + " . Please add excess QTY", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }

                        }
                    }

                    #endregion

                }

                #endregion

                #region pVal.BeforeAction == false

                else
                {
                    #region F_et_ITEM_PRESSED

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                    {
                        #region pVal.ItemUID == "1" 
                        if (pVal.ItemUID == "1" && pVal.ActionSuccess == true && oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            oForm.Close();
                            try
                            {
                                xForm = Packing.SBO_Application.Forms.GetForm("721", 1);
                                // Packing.SBO_Application.ActivateMenuItem("1304");
                                string docentry = oDal.ExSelect("select max(DocEntry) from [@PPS]", "");
                                string totfin = oDal.ExSelect("select U_TotFin from [@PPS] where Docentry=" + docentry + "", "");
                                string totpcs = oDal.ExSelect("select U_TotPiece from [@PPS] where Docentry=" + docentry + "", "");

                                ((SAPbouiCOM.EditText)xForm.Items.Item("txtProc").Specific).Value = docentry;
                                oMatrix = xForm.Items.Item("13").Specific;
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", 1)).Value = totfin;
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", 1)).Value = totpcs;
                                //xForm.Refresh();
                            }
                            catch
                            {

                            }
                        }
                        #endregion

                        #region pVal.ItemUID=="btnCopy"
                        if (pVal.ItemUID == "btnCopy")
                        {
                            if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {
                                Packing.SBO_Application.StatusBar.SetText("Form should be in Ok mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                return;
                            }
                            CopyToGoodsReceipt(oForm.UniqueID);
                        }
                        #endregion  

                    }

                    #endregion

                    #region F_et_CHOOSE_FROM_LIST
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        //SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        //oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        //string sCFL_ID = null;
                        //sCFL_ID = oCFLEvento.ChooseFromListUID;
                        //string val1 = null;
                        //string val2 = null;


                        //SAPbouiCOM.ChooseFromList oCFL = null;
                        //oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        //SAPbouiCOM.DataTable oDataTable = null;
                        //oDataTable = oCFLEvento.SelectedObjects;


                        //val1 = oDataTable.GetValue("MnfSerial", 0).ToString();
                        //val2 = oDataTable.GetValue("DistNumber", 0).ToString();
                        ////val2 = oDataTable.GetValue("Name", 0).ToString();
                        //oMatrix = oForm.Items.Item("7").Specific;

                        //oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2",pVal.Row);
                        //oEdit1 = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", pVal.Row);
                        //try
                        //{
                        //    oEdit.Value = val1;

                        //}
                        //catch { }

                        //try
                        //{
                        //    oEdit1.Value = val2;

                        //}
                        //catch { }
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        SAPbouiCOM.Form oForm = null;
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        if (oCFLEvento.BeforeAction == false)
                        {
                            SAPbouiCOM.IChooseFromListEvent oCFLEvent = null;
                            oCFLEvent = (SAPbouiCOM.IChooseFromListEvent)(pVal);

                            SAPbouiCOM.DataTable oDataTable = null;
                            oDataTable = oCFLEvento.SelectedObjects;
                            if (oDataTable == null) return;

                            string sCFLUId = null;
                            sCFLUId = oCFLEvent.ChooseFromListUID;
                            if (oDataTable != null)
                            {
                                try
                                {
                                    if (sCFLUId == "batch")
                                    {
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("7").Specific;

                                        if (oMatrix.VisualRowCount == 0)
                                            oMatrix.AddRow(1, oMatrix.RowCount);

                                        oMatrix.FlushToDataSource();
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item(childTable);
                                        oDbDataSource.SetValue("U_LotNo", pVal.Row - 1, oDataTable.GetValue("MnfSerial", 0).ToString());
                                        oDbDataSource.SetValue("U_batchno", pVal.Row - 1, oDataTable.GetValue("DistNumber", 0).ToString());

                                        if (oMatrix.VisualRowCount == pVal.Row)
                                        {
                                            oDbDataSource.InsertRecord(pVal.Row);
                                        }

                                        GlobalVariables.boolCFLSelected = true;
                                        SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                        GlobalVariables.ColNo = oPos.ColumnIndex;
                                        GlobalVariables.RowNo = oPos.rowIndex;
                                        oMatrix.LoadFromDataSource();
                                        oMatrix.Columns.Item("V_4").Cells.Item(oMatrix.VisualRowCount - 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                        refresh_avl_qty(pVal.Row);
                                        //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("",oMatrix.VisualRowCount)).Active
                                    }
                                    else if (sCFLUId == "CFL_Item")
                                    {
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                        oDbDataSource.SetValue("U_ICode", 0, oDataTable.GetValue("ItemCode", 0).ToString());
                                        oDbDataSource.SetValue("U_IName", 0, oDataTable.GetValue("ItemName", 0).ToString());

                                    }
                                }
                                catch (Exception ex)
                                {
                                    Packing.SBO_Application.StatusBar.SetText("F_F_et_CHOOSE_FROM_LIST: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                }
                            }


                        }
                    }
                    #endregion

                    #region F_pVal.ItemChanged == true

                    if (pVal.ItemChanged == true)
                    {
                        if (pVal.ColUID == "V_1" || pVal.ColUID == "V_0" || pVal.ColUID == "V_4")
                        {
                            double FINMeter = 0;
                            double GreyMeter = 0;
                            double totPcs = 0;

                            try
                            {
                                oMatrix = oForm.Items.Item("7").Specific;

                                int cnt = oMatrix.VisualRowCount;

                                for (int i = 1; i <= cnt; i++)
                                {
                                    string Fmtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value.ToString();
                                    string Gmt = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).Value.ToString();
                                    string Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value.ToString();

                                    FINMeter = FINMeter + Convert.ToDouble(Fmtr);

                                    if (Convert.ToDouble(Fmtr) > 0)
                                    {
                                        totPcs = totPcs + Convert.ToDouble(Pcs);
                                    }

                                    GreyMeter = GreyMeter + Convert.ToDouble(Gmt);
                                }


                                ((SAPbouiCOM.EditText)oForm.Items.Item("13").Specific).Value = FINMeter.ToString();
                                ((SAPbouiCOM.EditText)oForm.Items.Item("11").Specific).Value = totPcs.ToString();
                                ((SAPbouiCOM.EditText)oForm.Items.Item("TotGrey").Specific).Value = GreyMeter.ToString();
                                ((SAPbouiCOM.EditText)oForm.Items.Item("TotBal").Specific).Value = (GreyMeter - FINMeter).ToString();


                                string FinMtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", pVal.Row)).Value.ToString();
                                string GMtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row)).Value.ToString();

                                if (Convert.ToDouble(FinMtr) > 0 && Convert.ToDouble(GMtr) > 0 && pVal.Row == cnt)
                                {
                                    oMatrix.AddRow(1, cnt);
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_-1", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                                    //int colNo =   oDal.GetColumnIndex(oMatrix, "V_2");
                                    //oMatrix.SetCellFocus(oMatrix.VisualRowCount-1, colNo);
                                    //oMatrix.Columns.Item("V_2").Cells.Item(oMatrix.VisualRowCount).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                            }
                            catch
                            {

                            }
                        }
                    }

                    #endregion

                    #region F_et_CLICK

                    if (pVal.ItemUID == "btnRef" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        refresh_avl_qty(0);
                    }

                    #endregion

                    #region Excess Qty 
                    if (pVal.ItemUID == "15" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        Add_ExcessQty();
                        //oMatrix = oForm.Items.Item("7").Specific;
                        //int selrow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                        //if (selrow > 0)
                        //{
                        //    string batchnum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", selrow)).Value.ToString();
                        //    string Itemcode = ((SAPbouiCOM.EditText)oForm.Items.Item("5").Specific).Value.ToString();
                        //    string whse = ((SAPbouiCOM.EditText)oForm.Items.Item("9").Specific).Value.ToString();
                        //    if (batchnum != "" && Itemcode != "")
                        //    {
                        //        Packing.SBO_Application.ActivateMenuItem("3078");
                        //        xForm = Packing.SBO_Application.Forms.ActiveForm;

                        //        ((SAPbouiCOM.ComboBox)xForm.Items.Item("U_EType").Specific).Select("Excess", SAPbouiCOM.BoSearchKey.psk_ByValue);
                        //        ((SAPbouiCOM.EditText)xForm.Items.Item("txtLot").Specific).Value = batchnum;
                        //        oMatrix = xForm.Items.Item("13").Specific;
                        //        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", 1)).Value = Itemcode;
                        //        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", 1)).Value = whse;
                        //        oMatrix.Columns.Item("9").Cells.Item(1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        //    }
                        //    else
                        //    {
                        //        Packing.SBO_Application.StatusBar.SetText("Excess QTY can not be added for selected Item and Batch!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                        //    }
                        //}
                        //else
                        //{
                        //    Packing.SBO_Application.StatusBar.SetText("Please Select Row!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                        //}

                    }
                    #endregion

                    #region F_et_FORM_ACTIVATE

                    else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                    {
                        if (GlobalVariables.boolCFLSelected)
                        {
                            GlobalVariables.boolCFLSelected = false;
                            oForm = (SAPbouiCOM.Form)Packing.SBO_Application.Forms.Item(pVal.FormUID);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.SetCellFocus(GlobalVariables.RowNo, GlobalVariables.ColNo);
                            GlobalVariables.RowNo = 0;
                            GlobalVariables.ColNo = 0;
                        }
                    }

                    #endregion


                }

                #endregion

            }
            catch
            {

            }
        }

        private void CopyToGoodsReceipt(string formUID)
        {
            try
            {
                oForm = Packing.SBO_Application.Forms.Item(formUID);
                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT T0.U_ICode, T0.U_Whse, T1.U_LRNO ,Convert(Varchar(10),T1.U_LRDT,112 ) U_LRDT");
                sbQuery.Append(" ,Cast( T1.U_FINMtr AS int) U_FINMtr,Cast( T1.U_Pcs AS int) U_Pcs  ");
                sbQuery.Append(" FROM [" + headerTable + "] T0 ");
                sbQuery.Append(" INNER JOIN [" + childTable + "] T1 ON T0.DocEntry = T1.DocEntry ");
                sbQuery.Append(" WHERE T0.DocEntry = '" + docEntry + "'");
                sbQuery.Append(" AND T1.U_LotNo IS NOT NULL ");

                oRs = oDal.returnRecord(sbQuery.ToString());
                oForm.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                if (GlobalVariables.BaseFormUID != string.Empty)
                {
                    SAPbouiCOM.Form oBaseForm = Packing.SBO_Application.Forms.Item(GlobalVariables.BaseFormUID);
                    GlobalVariables.BaseFormUID = string.Empty;
                    oMatrix = (SAPbouiCOM.Matrix)oBaseForm.Items.Item("13").Specific;
                    int iRow = 1;
                    while (!oRs.EoF)
                    {
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", iRow)).String = oRs.Fields.Item("U_ICode").Value;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRNO", iRow)).String = oRs.Fields.Item("U_LRNO").Value;
                        try
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRDT", iRow)).String = oRs.Fields.Item("U_LRDT").Value;
                        }
                        catch
                        {
                        }
                        int qty = int.Parse(oRs.Fields.Item("U_Pcs").Value.ToString());
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", iRow)).String = qty.ToString();
                        qty = int.Parse(oRs.Fields.Item("U_FINMtr").Value.ToString());
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", iRow)).Value = qty.ToString();
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", iRow)).String = oRs.Fields.Item("U_Whse").Value;

                        oRs.MoveNext();
                        iRow++;
                    }
                }
            }
            catch (Exception ex)
            {
                Packing.SBO_Application.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public bool refresh_avl_qty(int currrow)
        {
            try
            {
                oMatrix = oForm.Items.Item("7").Specific;
                string whse = ((SAPbouiCOM.EditText)oForm.Items.Item("9").Specific).Value.ToString();
                string[] exist_batch = new string[5000];
                int exist_batch_cnt = 0;


                int rowcnt = oMatrix.VisualRowCount;
                for (int i = 1; i <= rowcnt; i++)
                {
                    bool exist_flag = false;
                    string batchnum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).Value.ToString();

                    if (batchnum != "")
                    {
                        for (int fl = 0; fl < exist_batch_cnt; fl++)
                        {
                            if (exist_batch[fl] == batchnum)
                            {
                                exist_flag = true;
                            }
                        }

                        if (!exist_flag)
                        {
                            string batch_act_qty = oDal.ExSelect("select Quantity from OIBT where BatchNum='" + batchnum + "' and WhsCode='" + whse + "'", "");
                            string batch_act_Pcs = oDal.ExSelect("select U_Pcs from OIBT where BatchNum='" + batchnum + "' and WhsCode='" + whse + "'", "");
                            double batchqty = Convert.ToDouble(batch_act_qty);
                            double batchPcs = Convert.ToDouble(batch_act_Pcs);
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value = batch_act_qty;
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value = batch_act_Pcs;
                            string enterd_qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value.ToString();
                            string enterd_Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value.ToString();
                            for (int i2 = i + 1; i2 <= rowcnt; i2++)
                            {
                                oMatrix1 = oForm.Items.Item("7").Specific;
                                string batch2 = ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("V_3", i2)).Value.ToString();
                                if (batchnum == batch2)
                                {
                                    batchqty = batchqty - Convert.ToDouble(enterd_qty == "" ? "0" : enterd_qty);
                                    batchPcs = batchPcs - Convert.ToDouble(enterd_Pcs == "" ? "0" : enterd_Pcs);
                                    //if (batchqty <= 0)
                                    //{

                                    //    Packing.SBO_Application.StatusBar.SetText("Lot Qty fall in negative. Please add excess qty and Refresh Available Qty!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    //    return false;
                                    //}
                                    //else if (batchPcs <= 0)
                                    //{

                                    //    Packing.SBO_Application.StatusBar.SetText("Piece fall in negative. Please add excess Piece and Refresh Available Qty!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    //    return false;
                                    //}
                                    //else
                                    //{
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("V_5", i2)).Value = (batchqty).ToString();
                                    enterd_qty = ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("V_1", i2)).Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("V_6", i2)).Value = (batchPcs).ToString();
                                    enterd_Pcs = ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("V_4", i2)).Value.ToString();
                                    //oMatrix1.AutoResizeColumns();
                                    Packing.SBO_Application.ActivateMenuItem("1297");
                                    Packing.SBO_Application.ActivateMenuItem("1300");
                                    //}
                                }
                            }

                        }

                        if (exist_flag == false)
                        {
                            exist_batch[exist_batch_cnt] = batchnum;
                            exist_batch_cnt = exist_batch_cnt + 1;
                        }
                    }
                }



                return true;
            }
            catch { return false; }
        }

        public bool Add_ExcessQty()
        {
            try
            {
                oMatrix = oForm.Items.Item("7").Specific;
                string whse = ((SAPbouiCOM.EditText)oForm.Items.Item("9").Specific).Value.ToString();
                string Itemcode = ((SAPbouiCOM.EditText)oForm.Items.Item("5").Specific).Value.ToString();
                string[] exist_batch = new string[5000];
                string[] excess_batch = new string[5000];
                double[] excess_qty = new double[5000];
                double[] excess_Pcs = new double[5000];
                int exist_batch_cnt = 0;
                int excess_batch_cnt = 0;


                int rowcnt = oMatrix.VisualRowCount;
                for (int i = 1; i <= rowcnt; i++)
                {
                    bool exist_flag = false;
                    string batchnum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).Value.ToString();

                    if (batchnum != "")
                    {
                        for (int fl = 0; fl < exist_batch_cnt; fl++)
                        {
                            if (exist_batch[fl] == batchnum)
                            {
                                exist_flag = true;
                            }
                        }

                        if (!exist_flag)
                        {
                            string batch_act_qty = oDal.ExSelect("select Quantity from OIBT where BatchNum='" + batchnum + "' and WhsCode='" + whse + "'", "");
                            string batch_act_Pcs = oDal.ExSelect("select isnull(U_Pcs,0) from OIBT where BatchNum='" + batchnum + "' and WhsCode='" + whse + "'", "");
                            double batchqty = Convert.ToDouble(batch_act_qty);
                            double batchPcs = Convert.ToDouble(batch_act_Pcs);





                            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value = batch_act_qty;
                            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value = batch_act_Pcs;
                            string enterd_qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value.ToString();
                            string enterd_Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value.ToString();

                            double batch_ent_qty = Convert.ToDouble(enterd_qty);
                            double batch_ent_Pcs = Convert.ToDouble(enterd_Pcs);

                            for (int i2 = i + 1; i2 <= rowcnt; i2++)
                            {
                                oMatrix1 = oForm.Items.Item("7").Specific;
                                string batch2 = ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("V_3", i2)).Value.ToString();
                                if (batchnum == batch2)
                                {

                                    enterd_qty = ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("V_1", i2)).Value.ToString();
                                    enterd_Pcs = ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("V_4", i2)).Value.ToString();

                                    batch_ent_qty = batch_ent_qty + Convert.ToDouble(enterd_qty);
                                    batch_ent_Pcs = batch_ent_Pcs + Convert.ToDouble(enterd_Pcs);

                                }
                            }

                            if (batch_ent_qty > batchqty && batch_ent_Pcs > batchPcs)
                            {
                                excess_batch[excess_batch_cnt] = batchnum;
                                excess_qty[excess_batch_cnt] = (batch_ent_qty - batchqty);
                                excess_Pcs[excess_batch_cnt] = (batch_ent_Pcs - batchPcs);

                                excess_batch_cnt = excess_batch_cnt + 1;
                            }
                            else if (batch_ent_qty > batchqty && batch_ent_Pcs <= batchPcs)
                            {
                                excess_batch[excess_batch_cnt] = batchnum;
                                excess_qty[excess_batch_cnt] = (batch_ent_qty - batchqty);
                                excess_Pcs[excess_batch_cnt] = 0;

                                excess_batch_cnt = excess_batch_cnt + 1;
                            }
                            else if (batch_ent_qty <= batchqty && batch_ent_Pcs > batchPcs)
                            {
                                excess_batch[excess_batch_cnt] = batchnum;
                                excess_qty[excess_batch_cnt] = 0;
                                excess_Pcs[excess_batch_cnt] = (batch_ent_Pcs - batchPcs);

                                excess_batch_cnt = excess_batch_cnt + 1;
                            }

                        }

                        if (exist_flag == false)
                        {
                            exist_batch[exist_batch_cnt] = batchnum;
                            exist_batch_cnt = exist_batch_cnt + 1;
                        }
                    }
                }



                #region Open Goods Receipt and add information
                if (excess_batch_cnt > 0)
                {
                    Packing.SBO_Application.ActivateMenuItem("3078");
                    xForm = Packing.SBO_Application.Forms.ActiveForm;

                    ((SAPbouiCOM.ComboBox)xForm.Items.Item("U_EType").Specific).Select("Excess", SAPbouiCOM.BoSearchKey.psk_ByValue);
                    //((SAPbouiCOM.EditText)xForm.Items.Item("txtLot").Specific).Value = batchnum;
                    oMatrix = xForm.Items.Item("13").Specific;
                    for (int Rec_mat = 0; Rec_mat < excess_batch_cnt; Rec_mat++)
                    {
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", Rec_mat + 1)).Value = Itemcode;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", Rec_mat + 1)).Value = excess_qty[Rec_mat].ToString();
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", Rec_mat + 1)).Value = whse;
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", Rec_mat + 1)).Value = excess_Pcs[Rec_mat].ToString();
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", Rec_mat + 1)).Value = excess_batch[Rec_mat];
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", Rec_mat + 1)).Value = "0";
                        oMatrix.Columns.Item("9").Cells.Item(1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    }
                }


                #endregion

                return true;
            }
            catch { return false; }
        }
    }
}

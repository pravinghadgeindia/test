﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Packing.Transactions
{
    class WtaxCalculation
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Matrix oMatrix2;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                if (pVal.BeforeAction == true)
                {

                }
                else if (pVal.BeforeAction == false)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        if (Packing.ParentForm == "141")
                        {
                            xForm = Packing.SBO_Application.Forms.GetForm(Packing.ParentForm, Packing.parentformcnt);
                            if(xForm.Mode==SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                oMatrix = oForm.Items.Item("6").Specific;
                                string taxcode = "";//((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", 1)).Value.ToString();
                                if (taxcode == "")
                                {   
                                    string cardcode = ((SAPbouiCOM.EditText)xForm.Items.Item("4").Specific).Value.ToString();
                                    string doctotal = ((SAPbouiCOM.EditText)xForm.Items.Item("22").Specific).Value.ToString();
                                    string freight = ((SAPbouiCOM.EditText)xForm.Items.Item("89").Specific).Value.ToString();
                                    string date = ((SAPbouiCOM.EditText)xForm.Items.Item("10").Specific).Value.ToString();
                                    doctotal = doctotal.Replace("INR", "").Replace(",", "").Replace(" ", "");
                                    freight = freight.Replace("INR", "").Replace(",", "").Replace(" ", "");
                                    double totalamt = Convert.ToDouble(doctotal == "" ? "0" : doctotal) + Convert.ToDouble(freight == "" ? "0" : freight);

                                    oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                    string qry = "exec sp_get_wtax_details '" + cardcode + "','" + date + "'," + totalamt.ToString() + "";

                                    oRs.DoQuery(qry);

                                    if (oRs.RecordCount > 0)
                                    {
                                        string TDSTAXCd = oRs.Fields.Item("U_TDSCd").Value.ToString();

                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", 1)).Value=TDSTAXCd;
                                        oMatrix.Columns.Item("7").Cells.Item(1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                        string qry1 = "exec sp_get_wtax_Count '" + cardcode + "','" + date + "'";
                                        string rec_cnt = oDal.ExSelect(qry1, "");
                                        if (Convert.ToInt32(rec_cnt) == 1)
                                        {
                                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                                            {
                                                oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                                oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                            }
                                            else if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                            {
                                                oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                            }
                                        }
                                    }

                                    

                                }



                            }
                        }
                    }
                   
                }

                return true;
            }
            catch
            { return false; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Packing.Transactions
{
    class BPMaster
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Matrix oMatrix2;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                if (pVal.BeforeAction == true)
                {
                    #region GSTN validation
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN && pVal.ItemUID == "178" && pVal.ColUID == "254000025")
                    {
                    
                        oMatrix = ((SAPbouiCOM.Matrix)oForm.Items.Item("178").Specific);
                        string state = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("7", pVal.Row)).Value.ToString();
                        string statecode = oDal.ExSelect("SELECT eCode FROM OCST where code = '" + state + "'", "");
                        if (state == "")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please Select State", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            return false;



                        }
                        else
                        {
                            string GSTno = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value.ToString();
                            string gstval = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_GSTNUN", pVal.Row)).Value.ToString();

                            if ((!GSTno.StartsWith(statecode)) && gstval == "N")
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value = statecode;
                        }

                    }
                    #endregion
                }
                else if (pVal.BeforeAction == false)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "244")
                    {
                        oItem = oForm.Items.Item("259");
                        SAPbouiCOM.Item oNewItem = oForm.Items.Add("TDS", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                        oNewItem.Left = oItem.Left +oItem.Width+10;
                        oNewItem.Width = 60;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "259";
                        oNewItem.FromPane=oItem.FromPane;
                        oNewItem.ToPane=oItem.ToPane;
                        ((SAPbouiCOM.Button)oNewItem.Specific).Caption= "TDS Details";
                        //((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_RecNum");
                        oNewItem.Enabled = true;
                    }

                    #region GSTN validation
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT && pVal.ItemUID == "178" && pVal.ColUID == "7")
                    {
                        oMatrix = ((SAPbouiCOM.Matrix)oForm.Items.Item("178").Specific);
                        string state = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("7", pVal.Row)).Value.ToString();
                        string statecode = oDal.ExSelect("SELECT eCode FROM OCST where code = '" + state + "'", "");
                        if (statecode!="")
                        {
                            string GSTno = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000025", pVal.Row)).Value.ToString();
                            string gstval = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_GSTNUN", pVal.Row)).Value.ToString();

                            if ((!GSTno.StartsWith(statecode)) && gstval == "N")

//                            if (!GSTno.StartsWith(statecode))
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000025", pVal.Row)).Value = statecode;
                        }

                    }
                    #endregion

                    #region GSTN validation CHECK
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT && pVal.ItemUID == "178" && pVal.ColUID == "U_GSTNUN")
                    {
                        oMatrix = ((SAPbouiCOM.Matrix)oForm.Items.Item("178").Specific);
                        string state = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value.ToString();
                        //string statecode = oDal.ExSelect("SELECT eCode FROM OCST where code = '" + state + "'", "");
                        if (state == "Y")
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000025", pVal.Row)).Value = "";
                            //string GSTno = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000025", pVal.Row)).Value.ToString();
                            //string gstval = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_GSTNUN", pVal.Row)).Value.ToString();

                            //if ((!GSTno.StartsWith(statecode)) && gstval == "N")

                            //                            if (!GSTno.StartsWith(statecode))
                            //  ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000025", pVal.Row)).Value = statecode;
                        }
                        else
                        {
                            string statecode = oDal.ExSelect("SELECT eCode FROM OCST where code = '" + ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("7", pVal.Row)).Value.ToString() + "'", "");
                            string GSTno = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000025", pVal.Row)).Value.ToString();
                            string gstval = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_GSTNUN", pVal.Row)).Value.ToString();

                            if ((!GSTno.StartsWith(statecode)) && gstval == "N")
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000025", pVal.Row)).Value = statecode;
                                                                 
                        }

                    }
                    #endregion

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "TDS")
                    {
                        string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("5").Specific).Value.ToString();
                        string cardname = ((SAPbouiCOM.EditText)oForm.Items.Item("7").Specific).Value.ToString();
                        string cnt = oDal.ExSelect("select isnull(count(CRD4.WTCode),0) from CRD4 inner join OWHT on CRD4.WTCode=OWHT.WTCode where CRD4.CardCode='" + cardcode + "' and  OWHT.Concess ='Y'", "");
                        oCheckBox = oForm.Items.Item("262").Specific;

                        if (oCheckBox.Checked == false)
                        {
                            Packing.SBO_Application.StatusBar.SetText("Withholding Tax not enabled.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                        else if (Convert.ToInt32(cnt) == 0)
                        {
                            Packing.SBO_Application.StatusBar.SetText("Sorry Not allowed.....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                        else
                        {
                            string exist = oDal.ExSelect("Select Code from [@TDSLIMIT] where code='" + cardcode + "'", "");
                            SAPbouiCOM.MenuItem oMenuP = Packing.SBO_Application.Menus.Item("43535");
                            string MenuUID = "";
                            string id = "";
                            for (int j = 0; j < oMenuP.SubMenus.Count; j++)
                            {
                                id = oMenuP.SubMenus.Item(j).String;
                                if (oMenuP.SubMenus.Item(j).String == "TDS LIMIT")
                                    MenuUID = oMenuP.SubMenus.Item(j).UID;
                            }

                            if (!String.IsNullOrEmpty(MenuUID))
                            {
                                Packing.SBO_Application.ActivateMenuItem(MenuUID);
                            }
                            else
                            {
                                Packing.SBO_Application.StatusBar.SetText("TDS LIMIT menu not available", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }

                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            if (exist == "")
                            {
                                ((SAPbouiCOM.EditText)xForm.Items.Item("0_U_E").Specific).Value = cardcode;
                                ((SAPbouiCOM.EditText)xForm.Items.Item("1_U_E").Specific).Value = cardname;
                            }
                            else
                            {
                                xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                ((SAPbouiCOM.EditText)xForm.Items.Item("0_U_E").Specific).Value = cardcode;
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            }
                            oMatrix = xForm.Items.Item("0_U_G").Specific;
                            oMatrix.Columns.Item("C_0_6").Cells.Item(1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            oMatrix.Columns.Item("C_0_1").Cells.Item(1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            xForm.Items.Item("0_U_E").Enabled = false;
                            xForm.Items.Item("1_U_E").Enabled = false;

                        }
                    }
                }

                return true;
            }
            catch
            { return false; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Xml;
using System.Windows.Forms;


namespace Packing.Transactions
{
    class CFPO
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.Column oColumn;
        private SAPbouiCOM.Columns oColumns;
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item("CFPO");
                #region copy to Purchase Invoice From CFPO
                if (pVal.FormUID == "CFPO" && pVal.ItemUID == "btnCopy" && pVal.BeforeAction == false)
                {
                    
                    oMatrix = oForm.Items.Item("2").Specific;
                    string[] Docentry = new string[5000];
                    string[] DocNum = new string[5000];
                    string[] LineNum = new string[5000];
                    string[] meter = new string[5000];
                    string[] Bale = new string[5000];
                    string[] Pcs = new string[5000];
                    string[] Yard = new string[5000];
                    string[] Broker = new string[5000];
                    string[] Desc = new string[5000];
                    int cnt = 0;

                    for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                    {
                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", i));
                        if (oCheckBox.Checked)
                        {
                            Docentry[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).Value.ToString();
                            DocNum[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", i)).Value.ToString();
                            LineNum[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value.ToString();
                            Desc[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value.ToString();
                            if (Convert.ToDouble(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", i)).Value.ToString()) > 0)
                                meter[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", i)).Value.ToString();
                            else
                                meter[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value.ToString();

                            if (Convert.ToDouble(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", i)).Value.ToString()) > 0)
                                Bale[cnt] =((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", i)).Value.ToString();
                            else
                                Bale[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).Value.ToString();

                            if (Convert.ToDouble(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", i)).Value.ToString()) > 0)
                                Pcs[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", i)).Value.ToString();
                            else
                                Pcs[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", i)).Value.ToString();

                            if (Convert.ToDouble(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", i)).Value.ToString()) > 0)
                                Yard[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", i)).Value.ToString();
                            else
                                Yard[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", i)).Value.ToString();


                            Broker[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value.ToString();


                            if (Convert.ToDouble(meter[cnt]) < 0 || Convert.ToDouble(Yard[cnt]) < 0 || Convert.ToDouble(Pcs[cnt]) < 0 || Convert.ToDouble(Bale[cnt]) < 0)
                            {
                                Packing.SBO_Application.StatusBar.SetText("Negative quantity not allowed!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);

                                return false;
                            }
                            cnt = cnt + 1;
                        }
                    }

                    try
                    {
                        oForm.Close();

                        if (Packing.ParentForm_CFPO == "141")
                        {

                            #region Copy to Purchase Invoice
                            oForm = Packing.SBO_Application.Forms.GetForm(Packing.ParentForm_CFPO, Packing.ParentCount_CFPO);
                            oMatrix = oForm.Items.Item("38").Specific;

                            oMatrix.Columns.Item("1").Editable = true;

                            for (int i = 0; i < cnt; i++)
                            {
                                string Doce = Docentry[i].ToString();
                                string line = LineNum[i].ToString();
                                SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                oRset.DoQuery("Select * from POR1 where Docentry='" + Doce + "' and linenum='" + line + "'");
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i + 1)).Value = oRset.Fields.Item("ItemCode").Value.ToString();
                                //SAPbouiCOM.CommonSetting oRowCtrl =oMatrix.CommonSetting;
                                //oRowCtrl.SetCellEditable(i + 1, 1, false);



                                oForm.Freeze(true);

                                try
                                {
                                    oColumn = oMatrix.Columns.Item("U_SUOM");
                                    oColumn.Editable = true;
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_SUOM", i + 1)).Select(oRset.Fields.Item("U_SUOM").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i + 1)).Value = meter[i].ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("11").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i + 1)).Value = meter[i].ToString();
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", i + 1)).Value = meter[i].ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_GrsQty").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", i + 1)).Value = meter[i].ToString();
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", i + 1)).Value = oRset.Fields.Item("PriceBefDi").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("14").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", i + 1)).Value = oRset.Fields.Item("PriceBefDi").Value.ToString();
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i + 1)).Value = oRset.Fields.Item("DiscPrcnt").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("15").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i + 1)).Value = oRset.Fields.Item("DiscPrcnt").Value.ToString();
                                }

                                try
                                {

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", i + 1)).Value = Pcs[i].ToString();
                                    oColumn = oMatrix.Columns.Item("U_SUOM");
                                    oColumn.Editable = false;
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", i + 1)).Value = Bale[i].ToString();//oRset.Fields.Item("U_Bale").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_Bale").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", i + 1)).Value = Bale[i].ToString();//oRset.Fields.Item("U_Bale").Value.ToString();

                                }

                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", i + 1)).Value = Yard[i].ToString();//oRset.Fields.Item("U_Yard").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_Yard").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", i + 1)).Value = Yard[i].ToString();//oRset.Fields.Item("U_Yard").Value.ToString();
                                }

                                try
                                {
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_RateBaseOn", i + 1)).Select(oRset.Fields.Item("U_RateBaseOn").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_RateBaseOn").Visible = true;
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_RateBaseOn", i + 1)).Select(oRset.Fields.Item("U_RateBaseOn").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRate", i + 1)).Value = oRset.Fields.Item("U_SRate").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_SRate").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRate", i + 1)).Value = oRset.Fields.Item("U_SRate").Value.ToString();
                                }

                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_YardTMtr", i + 1)).Value = oRset.Fields.Item("U_YardTMtr").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_YardTMtr").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_YardTMtr", i + 1)).Value = oRset.Fields.Item("U_YardTMtr").Value.ToString();
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i + 1)).Value = oRset.Fields.Item("DiscPrcnt").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("15").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i + 1)).Value = oRset.Fields.Item("DiscPrcnt").Value.ToString();
                                }
                                //try
                                //{
                                //    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_U_Jobw", i + 1)).Value = oRset.Fields.Item("U_U_Jobw").Value.ToString();
                                //}
                                //catch 
                                //{
                                //    oMatrix.Columns.Item("U_U_Jobw").Visible = true;
                                //    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_U_Jobw", i + 1)).Value = oRset.Fields.Item("U_U_Jobw").Value.ToString();
                                //}

                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", i + 1)).Value = oRset.Fields.Item("U_JobWrkr").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_JobWrkr").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", i + 1)).Value = oRset.Fields.Item("U_JobWrkr").Value.ToString();
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkrNm", i + 1)).Value = oRset.Fields.Item("U_JobWrkrNm").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_JobWrkrNm").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkrNm", i + 1)).Value = oRset.Fields.Item("U_JobWrkrNm").Value.ToString();
                                }


                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", i + 1)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_POBSEntry").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", i + 1)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSLine", i + 1)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("U_POBSLine").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSLine", i + 1)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", i + 1)).Value = oRset.Fields.Item("TaxCode").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("160").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", i + 1)).Value = oRset.Fields.Item("TaxCode").Value.ToString();
                                }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", i + 1)).Value = oRset.Fields.Item("WhsCode").Value.ToString();
                                }
                                catch
                                {
                                    oMatrix.Columns.Item("24").Visible = true;
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", i + 1)).Value = oRset.Fields.Item("WhsCode").Value.ToString();
                                }

                                try
                                {
                                    //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", i + 1)).Value = oRset.Fields.Item("U_JobWrkr").Value.ToString();
                                    //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkrNm", i + 1)).Value = oRset.Fields.Item("U_JobWrkrNm").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgShtDE", i + 1)).Value = oRset.Fields.Item("U_PrgShtDE").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgShtDN", i + 1)).Value = oRset.Fields.Item("U_PrgShtDN").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Label", i + 1)).Value = oRset.Fields.Item("U_Label").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgSer", i + 1)).Value = oRset.Fields.Item("U_PrgSer").Value.ToString();
                                }
                                catch { }

                                try
                                {
                                    ((SAPbouiCOM.EditText)oForm.Items.Item("U_Broker").Specific).Value = Broker[i].ToString();
                                }
                                catch
                                { }
                                oForm.Freeze(false);

                                try
                                {
                                    oForm.Freeze(true);
                                    oForm.Items.Item("138").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    oForm.Items.Item("498").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                    xForm = Packing.SBO_Application.Forms.GetForm("540020007", 1);
                                    SAPbouiCOM.Matrix omatrix1 = xForm.Items.Item("5").Specific;
                                    int matrow = omatrix1.VisualRowCount;
                                    oCombo = ((SAPbouiCOM.ComboBox)omatrix1.GetCellSpecific("1", matrow));
                                    oCombo.Select("22", SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    ((SAPbouiCOM.EditText)omatrix1.GetCellSpecific("3", matrow)).Value = oDal.ExSelect("select Docnum from OPOR where Docentry='" + Doce + "'", "");
                                    xForm.Items.Item("540020001").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                    oForm.Items.Item("112").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    oForm.Items.Item("14").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                    oForm.Freeze(false);
                                }
                                catch
                                {
                                    oForm.Freeze(false);
                                }
                                oRset = null;
                            }

                            oMatrix.Columns.Item("1").Editable = false;

                            #endregion
                        }
                        else if (Packing.ParentForm_CFPO == "143")
                        {
                            #region Copy to Ready form 

                            LoadFromXML("Ready");

                            oForm = Packing.SBO_Application.Forms.Item("Ready");

                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("4").Specific;
                            oMatrix.AddRow(1, oMatrix.RowCount);
                            oCombo = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("V_9").Cells.Item(1).Specific;

                            oCombo.ValidValues.Add("Yes", "Yes");
                            oCombo.ValidValues.Add("No", "No");

                            for (int i = 0; i < cnt; i++)
                            {
                                
                                oForm.Freeze(true);
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_8", i + 1)).Value = Docentry[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i + 1)).Value = DocNum[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i + 1)).Value = Broker[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i + 1)).Value = Desc[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i + 1)).Value = meter[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i + 1)).Value = Bale[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", i + 1)).Value = Pcs[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i + 1)).Value = Yard[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i + 1)).Value = LineNum[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_-1", i + 1)).Value = (i+1).ToString();
                                ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("V_9", i + 1)).Select("No", SAPbouiCOM.BoSearchKey.psk_ByValue);

                                if (i != cnt - 1)
                                    oMatrix.AddRow(1, oMatrix.RowCount);
                                oForm.Freeze(false);
                                
                            }


                            #endregion

                        }
                    }
                    catch { oForm.Freeze(false); }


                }

                #endregion

                #region choose from list before action true
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "4" && pVal.BeforeAction == true)
                {
                    //SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    //oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    //string sCFL_ID = null;
                    //sCFL_ID = oCFLEvento.ChooseFromListUID;
                    //oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL

                    //oCFL.SetConditions(null);
                    //oCons = oCFL.GetConditions();

                    //oCon = oCons.Add();

                    //oCon.Alias = "GroupCode";
                    //oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    //oCon.CondVal = "103";

                    //oCFL.SetConditions(oCons);
                }

                #endregion

                 #region choose from list before action false
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "4" && pVal.BeforeAction == false)
                {
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    string sCFL_ID = null;
                    sCFL_ID = oCFLEvento.ChooseFromListUID;
                    string val1 = null;
                    string val2 = null;


                    SAPbouiCOM.ChooseFromList oCFL = null;
                    oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                    SAPbouiCOM.DataTable oDataTable = null;
                    oDataTable = oCFLEvento.SelectedObjects;


                    val1 = oDataTable.GetValue("CardCode", 0).ToString();
                    val2 = oDataTable.GetValue("CardName", 0).ToString();

                    oEdit = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific);
                    try
                    {
                        oEdit.Value = val1;
                    }
                    catch
                    { }

                    oEdit = ((SAPbouiCOM.EditText)oForm.Items.Item("5").Specific);
                    oEdit.Value = val2;
                }
                 #endregion

                #region Click Get PO Fill Matrix
                if (((pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "6")) && pVal.BeforeAction == false)  //|| (pVal.EventType==SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID=="8")
                {
                    oMatrix = oForm.Items.Item("2").Specific;
                    string broker = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value.ToString();
                    string PO = ((SAPbouiCOM.EditText)oForm.Items.Item("8").Specific).Value.ToString();
                    string Dt = ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value.ToString();

                    //SAPbouiCOM.DataTable dt = oForm.DataSources.DataTables.Item("PO");
                    //dt.Clear();


                    //string Sql = "select 'N' chk,T0.CardCode,T0.CardName,T0.DocEntry,T0.DocNum,T1.LineNum,T1.ItemCode,T1.Dscription,T1.Quantity [OpenQty],isnull(T1.U_Bale,0) U_Bale,isnull(T1.U_Pcs,0) U_Pcs,isnull(T1.U_Yard,0) U_Yard, " +
                    //               " isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed QTY], " +
                    //               " isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed Bale], " +
                    //               " isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed PCS], " +
                    //               " isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed Yard], " +
                    //               " (T1.Quantity -isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenMtr] " +
                    //               " ,(isnull(T1.U_Bale,0)-isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenBale] " +
                    //               " ,(isnull(T1.U_Pcs,0)-isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenPcs] " +
                    //               " ,(isnull(T1.U_Yard,0)-isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenYard] " +
                    //               " from OPOR [T0] inner join [POR1] [T1] on T0.DocEntry=T1.DocEntry " +
                    //               " inner join OCRD [T2] on T0.CardCode=T2.CardCode " +
                    //               " where T0.DocStatus='O' and T1.LineStatus='O' and (T0.CardCode='" + broker + "' or '" + broker + "'='') and (T0.DocNum='" + PO + "' or '" + PO + "'='') and T0.DocDate<='" + Dt + "'" +
                    //                    " and  " +
                    //                     " ((T1.Quantity -isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) >0 " +
                    //                     " or (isnull(T1.U_Bale,0)-isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0))>0  " +
                    //                     " or	(isnull(T1.U_Pcs,0)-isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) >0 " +
                    //                     "	 or (isnull(T1.U_Yard,0)-isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) >0) "; //and T2.GroupCode='103'


                    string Sql = "exec sp_GetBrokerPO '" + Dt + "','" + broker + "','" + PO + "'";

                    oForm.DataSources.DataTables.Item("PO").Clear();

                    //oForm.DataSources.DataTables.Item("PO").m

                    oForm.DataSources.DataTables.Item("PO").ExecuteQuery(Sql);

                    //oMatrix.Columns.Item("V_8").DataBind.Bind("PO", "chk");
                    //oMatrix.Columns.Item("V_6").DataBind.Bind("PO", "CardName");
                    //oMatrix.Columns.Item("V_5").DataBind.Bind("PO", "Dscription");
                    //oMatrix.Columns.Item("V_4").DataBind.Bind("PO", "OpenMtr");
                    //oMatrix.Columns.Item("V_10").DataBind.Bind("PO", "OpenBale");
                    //oMatrix.Columns.Item("V_12").DataBind.Bind("PO", "OpenPcs");
                    //oMatrix.Columns.Item("V_14").DataBind.Bind("PO", "OpenYard");
                    //oMatrix.Columns.Item("V_3").DataBind.Bind("PO", "DocEntry");
                    //oMatrix.Columns.Item("V_2").DataBind.Bind("PO", "DocNum");
                    //oMatrix.Columns.Item("V_1").DataBind.Bind("PO", "LineNum");
                    //oMatrix.Columns.Item("V_0").DataBind.Bind("PO", "DocEntry");

                    oMatrix.LoadFromDataSource();

                    //SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    //oRset.DoQuery(Sql);

                    //oMatrix.Clear();
                    //if (oRset.RecordCount > 0)
                    //{
                    //    try
                    //    {
                    //        oForm.Freeze(true);
                    //        for (int i = 1; i <= oRset.RecordCount; i++)
                    //        {
                    //            oMatrix.AddRow(1, (i - 1));
                    //            ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", i)).Checked = false;
                    //            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).Value = oRset.Fields.Item("CardCode").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value = oRset.Fields.Item("CardName").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value = oRset.Fields.Item("Dscription").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value = oRset.Fields.Item("OpenMtr").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).Value = oRset.Fields.Item("OpenBale").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", i)).Value = oRset.Fields.Item("OpenPcs").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", i)).Value = oRset.Fields.Item("OpenYard").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", i)).Value = oRset.Fields.Item("DocNum").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();


                    //            oRset.MoveNext();
                    //        }
                    //        oForm.Freeze(false);
                    //    }
                    //    catch { oForm.Freeze(false); }
                    //}
                }
                #endregion

                #region check tick
                if (pVal.ItemUID == "2" && (pVal.ColUID == "V_9" || pVal.ColUID == "V_11" || pVal.ColUID == "V_13" || pVal.ColUID == "V_15") && pVal.EventType==SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.BeforeAction==false)
                {
                    oMatrix = oForm.Items.Item("2").Specific;
                    string openmeter = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value.ToString();
                    string openBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", pVal.Row)).Value.ToString();
                    string openPcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", pVal.Row)).Value.ToString();
                    string openYard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", pVal.Row)).Value.ToString();
                    oCheckBox=((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8",pVal.Row));

                    if ((Convert.ToDouble(openmeter) > 0 || Convert.ToDouble(openBale) > 0 || Convert.ToDouble(openPcs) > 0 || Convert.ToDouble(openYard) > 0) && oCheckBox.Checked == false)
                    {
                        oCheckBox.Checked = true;
                    }

                    if ((Convert.ToDouble(openmeter) == 0 && Convert.ToDouble(openBale) == 0 && Convert.ToDouble(openPcs) == 0 && Convert.ToDouble(openYard) == 0 ) && oCheckBox.Checked == true)
                    {
                        oCheckBox.Checked = false;
                    }

                }
                #endregion

                #region quantity validation
                if (pVal.ItemUID == "2" && (pVal.ColUID == "V_9" || pVal.ColUID == "V_11" || pVal.ColUID == "V_13" || pVal.ColUID == "V_15") && pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE && pVal.BeforeAction == true)
                {
                    oMatrix = oForm.Items.Item("2").Specific;
                    string openmeter = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value.ToString();
                    string openBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", pVal.Row)).Value.ToString();
                    string openPcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", pVal.Row)).Value.ToString();
                    string openYard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", pVal.Row)).Value.ToString();

                    string Actmeter = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).Value.ToString();
                    string ActBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", pVal.Row)).Value.ToString();
                    string ActPcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", pVal.Row)).Value.ToString();
                    string ActYard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", pVal.Row)).Value.ToString();

                    if (pVal.ColUID == "V_9" )
                    {
                        if (Convert.ToDouble(Actmeter) > 0 && (Convert.ToDouble(openmeter) > Convert.ToDouble(Actmeter)))
                        {
                            Packing.SBO_Application.MessageBox("Excess Qty Found in Meters. Please Update PO or Quantity", 1, "Ok", "", "");
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value = Actmeter;
                            BubbleEvent = false;
                        }
                        else if ((Convert.ToDouble(openmeter) > Convert.ToDouble(Actmeter)))
                        {
                            int res = Packing.SBO_Application.MessageBox("Access Qty Found. Do you want to Continue?", 2, "Yes", "No", "");
                            if (res == 2)
                            {
                                return false;
                            }
                        }
                    }
                    else if (pVal.ColUID == "V_11")
                    {
                        if (Convert.ToDouble(ActBale) > 0 && (Convert.ToDouble(openBale) > Convert.ToDouble(ActBale)))
                        {
                            Packing.SBO_Application.MessageBox("Excess Qty Found in Bale. Please Update PO or Quantity", 1, "Ok", "", "");
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", pVal.Row)).Value = ActBale;
                            BubbleEvent = false;
                        }
                        else if ((Convert.ToDouble(openBale) > Convert.ToDouble(ActBale)))
                        {
                            int res = Packing.SBO_Application.MessageBox("Access Qty Found. Do you want to Continue?", 2, "Yes", "No", "");
                            if (res == 2)
                            {
                                return false;
                            }
                        }
                    }
                    else if (pVal.ColUID == "V_13")
                    {
                        if (Convert.ToDouble(ActPcs) > 0 && (Convert.ToDouble(openPcs) > Convert.ToDouble(ActPcs)))
                        {
                            Packing.SBO_Application.MessageBox("Excess Qty Found in Piece. Please Update PO or Quantity", 1, "Ok", "", "");
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", pVal.Row)).Value = ActPcs;
                            BubbleEvent = false;
                        }
                        else if ((Convert.ToDouble(openPcs) > Convert.ToDouble(ActPcs)))
                        {
                            int res = Packing.SBO_Application.MessageBox("Access Qty Found. Do you want to Continue?", 2, "Yes", "No", "");
                            if (res == 2)
                            {
                                return false;
                            }
                        }
                    }
                    else if (pVal.ColUID == "V_15" )
                    {
                        if (Convert.ToDouble(ActYard) > 0 && (Convert.ToDouble(openYard) > Convert.ToDouble(ActYard)))
                        {
                            Packing.SBO_Application.MessageBox("Excess Qty Found in Yard. Please Update PO or Quantity", 1, "Ok", "", "");
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", pVal.Row)).Value = ActYard;
                            BubbleEvent = false;
                        }
                        else if ((Convert.ToDouble(openYard) > Convert.ToDouble(ActYard)))
                        {
                            int res = Packing.SBO_Application.MessageBox("Access Qty Found. Do you want to Continue?", 2, "Yes", "No", "");
                            if (res == 2)
                            {
                                return false;
                            }
                        }
                    }



                }

                #endregion

                #region key pressed
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN )
                {
                    int key = pVal.CharPressed;
                    if (key == 15)
                        oForm.Items.Item("btnCopy").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                }
                #endregion

                #region uncheck
                if (pVal.ItemUID == "2" && pVal.ColUID == "V_8" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.BeforeAction==false)
                {
                    oMatrix = oForm.Items.Item("2").Specific;
                    oCheckBox = (SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", pVal.Row);
                    string openmeter = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value.ToString();
                    string openBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", pVal.Row)).Value.ToString();
                    string openPcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", pVal.Row)).Value.ToString();
                    string openYard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", pVal.Row)).Value.ToString();
                    try
                    {
                        oForm.Freeze(true);
                        if (oCheckBox.Checked == false)
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value = "0";
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", pVal.Row)).Value = "0";
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", pVal.Row)).Value = "0";
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", pVal.Row)).Value = "0";
                        }
                        else if (oCheckBox.Checked == true && (Convert.ToDouble(openmeter) == 0 && Convert.ToDouble(openBale) == 0 && Convert.ToDouble(openPcs) == 0 && Convert.ToDouble(openYard) == 0))
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).Value;
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", pVal.Row)).Value = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", pVal.Row)).Value;
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", pVal.Row)).Value = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", pVal.Row)).Value;
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", pVal.Row)).Value = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", pVal.Row)).Value;
                        }
                        oForm.Freeze(false);
                    }
                    catch { oForm.Freeze(false); }
                }


                #endregion

                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN && pVal.BeforeAction == false && pVal.ItemUID == "2" && (pVal.ColUID == "V_9" || pVal.ColUID == "V_11" || pVal.ColUID == "V_13" || pVal.ColUID == "V_15"))
                {
                    oMatrix = oForm.Items.Item("2").Specific;
                    if (pVal.CharPressed == 40)
                    {
                        oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row+1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    }
                    else if (pVal.CharPressed == 38)
                    {
                        oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row - 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    }
                    

                }
                return true;
            }
            catch
            { return false; }
        }

        public void LoadFromXML(String FormName)
        {
            string sXmlFileName;
            string QStr = null;
            string DocEnt = null;
            int Docentry = 0;

            //SAPbobsCOM.Recordset InsertRec = null;
            //InsertRec = (SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset));

            sXmlFileName = Application.StartupPath.ToString();
            sXmlFileName = sXmlFileName + "\\" + FormName + ".srf";
            XmlDocument oXmlDoc = new XmlDocument();
            oXmlDoc.Load(sXmlFileName);
            string sXML = oXmlDoc.InnerXml.ToString();
            Packing.SBO_Application.LoadBatchActions(ref sXML);
            oForm = Packing.SBO_Application.Forms.ActiveForm;


            #region PackingCredit
            if (FormName == "PackingCredit")
            {
                oForm = Packing.SBO_Application.Forms.Item("PackingCredit");
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;

                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);
                //oForm.EnableMenu("1292", true);
                //oForm.EnableMenu("1283", false);
                //oForm.EnableMenu("1287", true);
                //oForm.EnableMenu("1286", false);
                //oForm.EnableMenu("1284", false);

                oForm.DataBrowser.BrowseBy = "DocEntry";
                //AddChooseFromList();

                string NowDate = Packing.oCompany.GetCompanyDate().ToString("yyyyMMdd").Replace("/", "-");
                oForm.Items.Item("Item_15").Specific.value = NowDate;
                oForm.Items.Item("Item_15").Enabled = false;

                string Sql = "SELECT (CASE WHEN (ISNULL(MAX(CONVERT(NUMERIC,DocEntry) ),0))=0 THEN 1 ELSE (MAX(CONVERT(NUMERIC,DocEntry)) + 1) END) AS CODE FROM [dbo].[@OPCF]";
                SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                oRset.DoQuery(Sql);

                if (oRset.RecordCount > 0)
                {
                    oForm.Items.Item("DocEntry").Specific.value = Convert.ToString(oRset.Fields.Item("CODE").Value);
                    oForm.Items.Item("Item_13").Specific.value = Convert.ToString(oRset.Fields.Item("CODE").Value);
                }
                // oForm.Items.Item("Item_17").Specific.value = NowDate;
                //oForm.Items.Item("Item_17").Enabled = false;
            }
            #endregion

            #region Program Sheet
            if (FormName == "ProgramSheet")
            {
                oForm = Packing.SBO_Application.Forms.Item("OPST");
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;

                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);

                oForm.DataBrowser.BrowseBy = "DocEntry";
                //AddChooseFromList();

                oForm.EnableMenu("1292", true);
                oForm.EnableMenu("1293", true);

                //ProgSheetformLoad();

            }
            #endregion

        }

    }
}

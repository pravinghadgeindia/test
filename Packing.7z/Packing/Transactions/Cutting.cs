using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace Packing.Transactions
{
    class Cutting
    {

        #region Variables

        public SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        DataAcessLayer oDal = new DataAcessLayer();
        string headerTable = "@CUTTING";
        string childTable = "@CUTTING1";
        string menuId = "Cutting";
        string formId = "Cutting";
        string objectId = "Cutting";

        string primaryMatrixColUID = "V_2";
        string apprQtyColUID = "V_2";
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            #region Inventory Transfer DocNum
                            if (pVal.ItemUID == "ITNo")
                            {
                                oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                                string cardCode = string.Empty;
                                cardCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).ToString();

                                ArrayList alCondVal = new ArrayList();
                                string query = "SELECT DocEntry FROM OWTR T0 WHERE T0.CARDCODE='" + cardCode + "' AND NOT EXISTS (SELECT 1 FROM [" + headerTable + "] T1 WHERE T0.DocEntry=T1.U_ITDE )";
                                oDal.AddChooseFromList_WithCond(oForm, "CFL_IT", "67", query, "DocEntry", alCondVal);
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CheckNo", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        Packing.SBO_Application.StatusBar.SetText("Please select the Checking No.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        Packing.SBO_Application.StatusBar.SetText("Document No can't be blank. Please select series", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        Packing.SBO_Application.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            Packing.SBO_Application.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                }
                            }
                            #endregion

                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        Packing.SBO_Application.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.Action_Success == true)
                            {
                                if (pVal.FormTypeEx == formId && pVal.ItemUID == "1" && pVal.FormMode == 3)
                                {
                                    oForm = (SAPbouiCOM.Form)Packing.SBO_Application.Forms.Item(pVal.FormUID);
                                    string Code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).ToString();
                                    if (Code.Trim() == string.Empty)
                                    {
                                        LoadForm("1282");
                                        return;
                                    }
                                }

                            }
                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = Packing.SBO_Application.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                           if (oCFLEvento.ChooseFromListUID == "CFL_CHECK")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_CheckNo", 0, oDataTable.GetValue("DocNum", 0).ToString());
                                oDbDataSource.SetValue("U_CheckDE", 0, oDataTable.GetValue("DocEntry", 0).ToString());
                                FillMatrix();
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_LotNo")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item(childTable).SetValue("U_LotNo", pVal.Row - 1, oDataTable.GetValue("MnfSerial", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item(childTable).InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item(childTable).Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item(childTable).SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_5").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                GlobalVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                GlobalVariables.ColNo = oPos.ColumnIndex;
                                GlobalVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                if (pVal.ItemUID == "Series")
                                {
                                    oForm = Packing.SBO_Application.Forms.Item(FormUID);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(0);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objectId).ToString();//objclsComman.GetMaxDocNum("KIT_PO", idefaultseries);
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Packing.SBO_Application.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formId)
                            {
                                if (GlobalVariables.boolCFLSelected)
                                {
                                    GlobalVariables.boolCFLSelected = false;
                                    oForm = (SAPbouiCOM.Form)Packing.SBO_Application.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.SetCellFocus(GlobalVariables.RowNo, GlobalVariables.ColNo);
                                    GlobalVariables.RowNo = 0;
                                    GlobalVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged
                        if (pVal.ItemChanged)
                        {
                            oForm = (SAPbouiCOM.Form)Packing.SBO_Application.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "CardCode")
                            {
                                string itNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
                                if (itNo == string.Empty)
                                {
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_CardName", 0, string.Empty);
                                }
                            }

                            else if (pVal.ItemUID == "ITNo")
                            {
                                string itNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ITNo", 0).Trim();
                                if (itNo == string.Empty)
                                {
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_ITDE", 0, string.Empty);
                                }
                            }

                            else if (pVal.ItemUID == "YardConv")
                            {
                                FillMatrix_YardConv();
                            }

                            else if (pVal.ItemUID == "mtx")
                            {
                                if (pVal.ColUID == apprQtyColUID)
                                {
                                    FillMatrix_YardConv_ByRow(pVal.Row - 1);
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        Packing.SBO_Application.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion


            }
            catch (Exception ex)
            {
                Packing.SBO_Application.StatusBar.SetText("Item Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = Packing.SBO_Application.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID.ToLower() == menuId.ToLower() || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == "1292")
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);

                        string Value;
                        Value = oForm.DataSources.DBDataSources.Item(childTable).GetValue("U_LotNo", oMatrix.VisualRowCount - 1).ToString().Trim();
                        oDal.AddRow(oMatrix, oDBDataSource, Value);
                    }
                    else if (pVal.MenuUID == "1293")
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item(headerTable).Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item(childTable).GetValue("U_ITLineNo", i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item(childTable).RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item(childTable).SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();
                    }

                }
            }
            catch (Exception ex)
            {
                Packing.SBO_Application.SetStatusBarMessage("Menu Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DOCENTRY", 0);
                        oDal.SelectRecord("DELETE FROM [" + headerTable + "] WHERE  (ISNULL(U_ITLineNo,'')='') AND DOCENTRY='" + docEntry + "'");

                        if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                        {
                            oDal.SelectRecord("UPDATE [" + childTable+ "] SET U_OApprMtr= U_ApprMtr WHERE DOCENTRY='" + docEntry + "'");
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Packing.SBO_Application.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            if (MenuID.ToLower() == menuId.ToLower())
            {
                GlobalVariables.boolCFLSelected = false;
                oDal.LoadFromXML(MenuID);
                oForm = Packing.SBO_Application.Forms.ActiveForm;
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                oForm.EnableMenu("1282", true);
                oForm.EnableMenu("1281", true);
                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);
                oForm.EnableMenu("1292", true); // Add Row
                oForm.EnableMenu("1293", true); // Delete Row

                oForm.DataBrowser.BrowseBy = "DocEntry";

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;
            }

            oForm = Packing.SBO_Application.Forms.ActiveForm;
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.CommonSetting.EnableArrowKey = true;


            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            #region Series And DocNum
            oForm = Packing.SBO_Application.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                oDal.FillCombo_Series_Custom(oForm, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objectId).ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion


            oItem = oForm.Items.Item("DocNum");
            oDal.SetAutoManagedAttribute(oItem);
            oItem = oForm.Items.Item("DocEntry");
            oDal.SetAutoManagedAttribute(oItem);
            oItem = oForm.Items.Item("CheckNo");
            oDal.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("Series");
            oDal.SetAutoManagedAttribute_UpdateMode(oItem);
        }

        private void FillMatrix()
        {
            oForm = (SAPbouiCOM.Form)Packing.SBO_Application.Forms.Item(formId);
            string itrDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CheckDE", 0).Trim();

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.Clear();
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(childTable);
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T1.LineId, T1.U_ApprMtr, T1.U_Pcs ");
            sbQuery.Append(" FROM [@Checking] T0 ");
            sbQuery.Append(" INNER JOIN [@Checking1] T1 ON T0.DocEntry = T1.DocEntry ");

            sbQuery.Append(" WHERE T0.DocEntry = '" + itrDocEntry + "'");
            SAPbobsCOM.Recordset oRs = oDal.returnRecord(sbQuery.ToString());
            int row = 0;
            //string yardConv = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_YardConv", 0).Trim();
            //double dblYardConv = yardConv == string.Empty ? 1 : double.Parse(yardConv);
            while (!oRs.EoF)
            {
                oDbDataSource.InsertRecord(row + 1);
                oDbDataSource.SetValue("LineId", row, (row + 1).ToString());
                oDbDataSource.SetValue("U_CheckLin", row, oRs.Fields.Item("LineId").Value);
                oDbDataSource.SetValue("U_Pcs", row, oRs.Fields.Item("U_Pcs").Value);
                oDbDataSource.SetValue("U_ApprMtr", row, oRs.Fields.Item("U_ApprMtr").Value);
                //oDbDataSource.SetValue("U_RecvMtr", row, oRs.Fields.Item("Quantity").Value);
                //double value = double.Parse(oRs.Fields.Item("Quantity").Value.ToString()) / dblYardConv;
                //oDbDataSource.SetValue("U_Yard", row, value.ToString());
                row++;
                oRs.MoveNext();
            }

            oMatrix.LoadFromDataSource();

        }
        private void FillMatrix_YardConv()
        {
            oForm = (SAPbouiCOM.Form)Packing.SBO_Application.Forms.Item(formId);

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(childTable);
            int row = 0;
            string yardConv = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_YardConv", 0).Trim();
            double dblYardConv = yardConv == string.Empty ? 1 : double.Parse(yardConv);
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                double value = double.Parse(oDbDataSource.GetValue("U_ApprMtr", row).ToString()) / dblYardConv;
                oDbDataSource.SetValue("U_Yard", row, value.ToString());
                row++;
            }

            oMatrix.LoadFromDataSource();
        }

        private void FillMatrix_YardConv_ByRow(int row)
        {
            oForm = (SAPbouiCOM.Form)Packing.SBO_Application.Forms.Item(formId);
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(childTable);
            string yardConv = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_YardConv", 0).Trim();
            double dblYardConv = yardConv == string.Empty ? 1 : double.Parse(yardConv);
            double value = double.Parse(oDbDataSource.GetValue("U_ApprMtr", row).ToString()) / dblYardConv;
            oDbDataSource.SetValue("U_Yard", row, value.ToString());
            oMatrix.LoadFromDataSource();
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Packing.Transactions
{
    class PackingCredit
    {

        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Condition oCon = null;
        public static SAPbobsCOM.Recordset oRs;


        #endregion


        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item("PackingCredit");
                if (pVal.BeforeAction == true)
                {
                    
                }

                else if (pVal.BeforeAction == false)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_2")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;
                        string val4 = null;
                        string abc = null;
                        //string def = null;
                       
                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("DocNum",0).ToString();                        
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_2").Specific;
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }                     
                        
                        val2 = oDataTable.GetValue("DocEntry", 0).ToString();
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_26").Specific;
                        try
                        {
                            oEdit.Value = val2;
                        }
                        catch { }


                        //string Payterm = oDal.ExSelect("select  T3.PymntGroup from ORDR T0 INNER JOIN OCTG T3 ON T3.GroupNum = T0.GroupNum where T0.Docentry=" + val2.ToString() + "  ", "");
                        string Sql = "select  T3.PymntGroup from ORDR T0 INNER JOIN OCTG T3 ON T3.GroupNum = T0.GroupNum where T0.Docentry=" + val2.ToString() + "  ";
                        SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        oRset.DoQuery(Sql);

                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_5").Specific;
                        try
                        {
                            oEdit.Value = oRset.Fields.Item("PymntGroup").Value;
                        }
                        catch { }

                        abc = oDataTable.GetValue("DocTotal", 0).ToString();
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_6").Specific;
                        try
                        {
                            oEdit.Value = Convert.ToString((Convert.ToDecimal(abc) / 100) * 75);
                        }
                        catch { }

                            val3 = oDataTable.GetValue("CardName", 0).ToString();
                            abc = oDataTable.GetValue("Address2", 0).ToString();                            
                            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_3").Specific;
                            try
                            {
                                oEdit.Value = val3 + ' ' + abc;
                            }
                            catch { }

                            val4 = oDataTable.GetValue("DocDueDate", 0).ToString();
                            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_16").Specific;
                            try
                            {
                                oEdit.Value = Convert.ToDateTime(val4).ToString("yyyyMMdd");                                
                            }
                            catch { }
                            
                      
                        }                   
               }
                return true;
            }
            catch
            { return false; }
        }

    }
}

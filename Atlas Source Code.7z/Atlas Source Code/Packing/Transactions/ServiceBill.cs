﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Packing.Transactions
{
    class ServiceBill
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.Column oColumn;
        private SAPbouiCOM.Columns oColumns;
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item("ServiceItem");

                if (pVal.BeforeAction == false)
                {
                    oForm = Packing.SBO_Application.Forms.Item("ServiceItem");
                    #region Get Receipt Details on Click Matrix Receipt
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "matRec")
                    {
                        oForm = Packing.SBO_Application.Forms.Item("ServiceItem");
                        oMatrix = oForm.Items.Item("matRec").Specific;
                        int selrow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                        if (selrow >= 0)
                        {
                            string recDE = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", selrow)).Value.ToString();
                            oMatrix1 = oForm.Items.Item("matRecDet").Specific;
                            oMatrix1.FlushToDataSource();
                            try
                            {
                                oForm.DataSources.DataTables.Add(selrow.ToString());
                                oForm.DataSources.DataTables.Item(selrow.ToString()).Clear();
                                string sSQL = "select 'N' chk,ItemCode,Dscription,(IGN1.Quantity-isnull((select sum(PCH1.U_SQTY) from PCH1 where PCH1.U_RecDe=IGN1.Docentry and PCH1.U_RecLine=IGN1.Linenum),0))  Quantity,LineNum  Line from IGN1 where DocEntry='" + recDE + "' and (IGN1.Quantity-isnull((select sum(PCH1.U_SQTY) from PCH1 where PCH1.U_RecDe=IGN1.Docentry and PCH1.U_RecLine=IGN1.Linenum),0))>0";
                                oForm.DataSources.DataTables.Item(selrow.ToString()).ExecuteQuery(sSQL);
                            }
                            catch { }
                                //oMatrix = oform.Items.Item("mtx_0").Specific
                                oMatrix1.Columns.Item("V_9").DataBind.Bind(selrow.ToString(), "chk");
                                oMatrix1.Columns.Item("V_-1").DataBind.Bind(selrow.ToString(), "Line");
                                oMatrix1.Columns.Item("V_7").DataBind.Bind(selrow.ToString(), "ItemCode");
                                oMatrix1.Columns.Item("V_6").DataBind.Bind(selrow.ToString(), "Dscription");
                                oMatrix1.Columns.Item("V_5").DataBind.Bind(selrow.ToString(), "Quantity");
                                //oMatrix.Columns.Item("col_3").DataBind.Bind("X", "ItemName")

                            
                            oMatrix1.LoadFromDataSource();


                        }
                    }
                    #endregion

                    #region Copy to AP Invoice
                    if (pVal.ItemUID == "btnCpy" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        oMatrix = oForm.Items.Item("matRec").Specific;
                        oMatrix1 = oForm.Items.Item("matRecDet").Specific;
                        oMatrix1.FlushToDataSource();
                        string rate = ((SAPbouiCOM.EditText)oForm.Items.Item("6").Specific).Value.ToString();
                        string SAC = ((SAPbouiCOM.EditText)oForm.Items.Item("8").Specific).Value.ToString();
                        string[] receiptDE = new string[5000];
                        string[] Line = new string[5000];
                        string[] QTY = new string[5000];
                        //string[] receiptDE = new string[5000];
                        int cnt = 0;


                        if (Convert.ToDouble(rate) == 0)
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please Enter Rate", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            return false;
                        }
                        else if (SAC == "")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please Select SAC Code", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            return false;
                        }

                        for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                        {
                            SAPbouiCOM.DataTable dt;
                            try
                            {
                                dt = oForm.DataSources.DataTables.Item(i.ToString());

                                for (int j = 0; j < dt.Rows.Count; j++)
                                {
                                    string chk = dt.GetValue("chk", j);
                                    if (chk == "Y")
                                    {
                                        receiptDE[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value.ToString();
                                        Line[cnt] = (dt.GetValue("Line", j)).ToString();
                                        QTY[cnt] = (dt.GetValue("Quantity", j)).ToString();
                                       // receiptDE[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value.ToString();
                                        cnt = cnt + 1;
                                    }

                                }
                            }
                            catch { }
                        }

                        oForm.Close();

                        xForm = Packing.SBO_Application.Forms.GetForm("141", Packing.ParentCount_ServiceItem);
                        oMatrix = xForm.Items.Item("39").Specific;
                        for (int i = 1; i <= cnt; i++)
                        {
                            try
                            {
                                xForm.Freeze(true);
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000207", i)).Value = SAC;
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SQTY", i)).Value = QTY[i - 1].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SerRATE", i)).Value = rate;
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_RecDe", i)).Value = receiptDE[i - 1].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_RecLine", i)).Value = Line[i - 1].ToString();
                                xForm.Freeze(false);
                            }
                            catch
                            {
                                xForm.Freeze(false);
                            }
                        }

                        oMatrix.Columns.Item("254000207").Cells.Item(oMatrix.VisualRowCount).Click(SAPbouiCOM.BoCellClickType.ct_Regular);





                    }

                    #endregion

                    #region SAC Code CFL
                    if (pVal.ItemUID == "8" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("ServCode", 0).ToString();
                        //val2 = oDataTable.GetValue("DocDate", 0).ToString("yyyyMMdd");
                        val3 = oDataTable.GetValue("ServName", 0).ToString();
                        //U_DocDate.Value = ToDate.ToString("yyyyMMdd")
                        oForm = Packing.SBO_Application.Forms.Item("ServiceItem");
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("8").Specific;
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                        oForm = Packing.SBO_Application.Forms.Item("ServiceItem");
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("9").Specific;
                        try
                        {
                            oEdit.Value = val3;
                        }
                        catch { }
                    }
                    #endregion
                }


                return true;
            }
            catch
            { return false; }
        }
    }
}

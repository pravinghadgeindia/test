﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Packing.Transactions
{
    class PackingDetails
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item("OPCKDT");
                if (pVal.BeforeAction == true)
                {
                    #region choose from list Jobworker
                    if (pVal.ItemUID == "Item_3" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        String CardCode = "";
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID); 

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();

                        oCon = oCons.Add();

                        oCon.Alias = "U_Whse";
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_NOT_NULL;
                        
                        oCFL.SetConditions(oCons);
                    }

                    #endregion

                    #region choose from list Program Sheet
                    if (pVal.ItemUID == "Item_13" && pVal.ColUID=="V_0" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        String CardCode = "";
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();

                        oCon = oCons.Add();

                        oCon.Alias = "Status";
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = "O";


                        oCFL.SetConditions(oCons);
                    }

                    #endregion

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN && pVal.ItemUID == "Item_13" && (pVal.ColUID == "Col_7" || pVal.ColUID == "Col_8" || pVal.ColUID == "Col_5" || pVal.ColUID == "Col_4"))
                    {
                        oMatrix = oForm.Items.Item("Item_13").Specific;
                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_2", pVal.Row));
                        if (oCheckBox.Checked && pVal.CharPressed != 9)
                        {
                            return false;
                        }
                    }
                }
                else if (pVal.BeforeAction == false)
                {
                    #region Choose from List
                    #region choose from list JobWorker
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_3")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("CardCode", 0).ToString();
                        val2 = oDataTable.GetValue("CardName", 0).ToString();
                        val3 = oDataTable.GetValue("U_Whse", 0).ToString();

                        
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Item_3").Specific;
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("15").Specific;
                        try
                        {
                            oEdit.Value = val2;
                        }
                        catch { }
                        
                    }
                    #endregion

                    #region choose from list Item Code
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "12")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("ItemCode", 0).ToString();
                        val2 = oDataTable.GetValue("ItemName", 0).ToString();
                        


                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("12").Specific;
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("14").Specific;
                        try
                        {
                            oEdit.Value = val2;
                        }
                        catch { }

                    }
                    #endregion

                    #region choose from list JobWorker Row
                    else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "Item_13" && pVal.ColUID == "V_0")
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("U_Serial", 0).ToString();
                        val2 = oDataTable.GetValue("DocEntry", 0).ToString();
                        //val3 = oDataTable.GetValue("U_Serial", 0).ToString();

                        oMatrix = oForm.Items.Item("Item_13").Specific;

                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row);
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                        //oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row);
                        //try
                        //{
                        //    oEdit.Value = val2;
                        //}
                        //catch { }
                        
                        if (oMatrix.VisualRowCount == pVal.Row)
                        {
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                oMatrix.AddRow(1, oMatrix.VisualRowCount);
                            }
                            else if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(1);
                                oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                //oMatrix.FlushToDataSource();
                                //oMatrix.LoadFromDataSource();
                                oMatrix.AddRow(1, oMatrix.VisualRowCount);
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_0", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_1", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_6", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_7", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_8", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_5", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_4", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_2", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_3", oMatrix.VisualRowCount)).Value = "";
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("#", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();

                            }
                            //oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_23", oMatrix.VisualRowCount));
                            //oCheckBox.Checked = true;
                        }
                    }
                    #endregion
                    #endregion

                    #region calculate qty in row
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "Item_13" && (pVal.ColUID == "V_5" || pVal.ColUID == "V_4" || pVal.ColUID == "Col_6"))
                    {
                        oMatrix = oForm.Items.Item("Item_13").Specific;
                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_2", pVal.Row));
                        if (oCheckBox.Checked)
                        {
                            try
                            {
                                string bale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row)).Value.ToString();
                                string Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).Value.ToString();
                                string Cut = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_6", pVal.Row)).Value.ToString();
                                string YardToMtr = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_5").Specific).Value.ToString();
                                oForm.Freeze(true);
                                //Meter
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_7", pVal.Row)).Value = (Convert.ToDouble(bale) * Convert.ToDouble(Pcs) * Convert.ToDouble(Cut) * Convert.ToDouble(YardToMtr)).ToString();
                                //Yards
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_8", pVal.Row)).Value = (Convert.ToDouble(bale) * Convert.ToDouble(Pcs) * Convert.ToDouble(Cut)).ToString();
                                //Pcs
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_5", pVal.Row)).Value = (Convert.ToDouble(bale) * Convert.ToDouble(Pcs)).ToString();
                                //Bale
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_4", pVal.Row)).Value = (Convert.ToDouble(bale)).ToString();

                                oForm.Freeze(false);
                            }
                            catch { oForm.Freeze(false); }
                        }
                    }
                    #endregion


                    #region Bale Number
                    if (((pVal.ColUID == "Col_2" && pVal.Row == 1) || (pVal.ColUID == "V_5" && pVal.Row > 1)) && pVal.ItemUID == "Item_13" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
                    {
                        oMatrix = oForm.Items.Item("Item_13").Specific;
                        if (pVal.ColUID == "Col_2" && pVal.Row == 1)
                        {
                            string BaleCnt = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row)).Value.ToString();
                            string StartBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_2", pVal.Row)).Value.ToString();


                            string endbale = (Convert.ToDouble(StartBale == "" ? "0" : StartBale) + Convert.ToDouble(BaleCnt == "" ? "0" : BaleCnt) -1).ToString();

                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_3", pVal.Row)).Value = (Convert.ToInt32(endbale)).ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_2", pVal.Row+1)).Value = (Convert.ToInt32(Convert.ToDouble( endbale)+1)).ToString();
                        }
                        else if (pVal.ColUID == "V_5" && pVal.Row > 1)
                        {
                            string BaleCnt = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row)).Value.ToString();
                            string StartBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_2", pVal.Row)).Value.ToString();


                            string endbale = (Convert.ToDouble(StartBale == "" ? "0" : StartBale) + Convert.ToDouble(BaleCnt == "" ? "0" : BaleCnt) -1).ToString();

                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_3", pVal.Row)).Value = (Convert.ToInt32(endbale)).ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_2", pVal.Row + 1)).Value = (Convert.ToInt32(Convert.ToDouble(endbale) + 1)).ToString();
                        }


                    }
                    #endregion

                    #region Packing List
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED && pVal.ItemUID=="1" && pVal.BeforeAction == false && pVal.ActionSuccess == true)
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            string lastPackD = oDal.ExSelect("select Max(Docentry) from [@OPCKDT]", "");

                            if (Packing.ParentForm_PackDet == "Ready")
                            {
                                oForm.Close();
                                xForm = Packing.SBO_Application.Forms.GetForm(Packing.ParentForm_PackDet, Packing.ParentCount_PackDet);
                                oMatrix = xForm.Items.Item("4").Specific;
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", Packing.PrgSheet_CurrentRow)).Value = lastPackD;
                            }
                            else if (Packing.ParentForm_PackDet == "721")
                            {
                                oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                ((SAPbouiCOM.EditText)oForm.Items.Item("3").Specific).Value = lastPackD;
                                oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                xForm = Packing.SBO_Application.Forms.GetForm("721", Packing.ParentCount_PackDet);
                                ((SAPbouiCOM.EditText)xForm.Items.Item("txtPackD").Specific).Value = lastPackD;
                            }
                        }
                    }
                    #endregion

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "btnCopy")
                    {
                        string Docentry = ((SAPbouiCOM.EditText)oForm.Items.Item("3").Specific).Value.ToString();
                        int res = Packing.SBO_Application.MessageBox("Do you want to Split record as Single Bale wise?", 1, "Yes", "No", "");

                        oForm.Close();

                        xForm = Packing.SBO_Application.Forms.GetForm("721", Packing.ParentCount_PackDet);
                        oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        string qry = "";

                        
                        if (res == 1)
                        {
                            qry= "exec SP_PackingCal " + Docentry + "";
                        }
                        else
                        {
                            qry = "exec SP_Packing_WO_Cal " + Docentry + "";
                        }

                        oRs.DoQuery(qry);

                        if (oRs.RecordCount > 0)
                        {
                            oMatrix = xForm.Items.Item("13").Specific;
                            try
                            {
                                xForm.Freeze(true);
                                Packing.SBO_Application.StatusBar.SetText("Please Wait !!!", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                for (int i = 1; i <= oRs.RecordCount; i++)
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).Value = oRs.Fields.Item("U_ItmCode").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", i)).Value = oRs.Fields.Item("Mtr Per Bale").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", i)).Value = oRs.Fields.Item("U_Jobwrk").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i)).Value = oRs.Fields.Item("Whse").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", i)).Value = oRs.Fields.Item("Bale").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", i)).Value = oRs.Fields.Item("U_Pcs").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CutPcs", i)).Value = oRs.Fields.Item("U_Cut").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", i)).Value = oRs.Fields.Item("U_Yards").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", i)).Value = "0";
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_STBALE", i)).Value = oRs.Fields.Item("Start Bale").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ENBALE", i)).Value = oRs.Fields.Item("End Bale").Value.ToString();
                                    //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("", i)).Value = oRs.Fields.Item("").Value.ToString();
                                    oRs.MoveNext();
                                }
                                xForm.Freeze(false);
                            }
                            catch { xForm.Freeze(false); }
                        }
                    }

                }

                return true;
            }
            catch
            { return false; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using System.Xml;

namespace Packing.Transactions
{
    class SockTransfer
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                if (pVal.BeforeAction == true)
                {
                    if (pVal.ItemUID == "3" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        #region set condition to select only warehouse vendor (Jobworker)
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        String CardCode = "";
                        //CardCode = oForm.Items.Item("Item_4").Specific.value;
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL
                        //oCFL1 = oForm.ChooseFromLists.Item(sCFL_ID);

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();



                        oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        string qry = "select * from OCRD where isnull(U_Whse,'')<>''";

                        oRs.DoQuery(qry);

                        if (oRs.RecordCount > 0)
                        {
                            oCon = oCons.Add();
                            for (int i = 0; i < oRs.RecordCount; i++)
                            {
                                if (i > 0)
                                {
                                    oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                                    oCon = oCons.Add();
                                }

                                oCon.Alias = "CardCode";
                                oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                                oCon.CondVal = oRs.Fields.Item("CardCode").Value.ToString();
                                oRs.MoveNext();
                            }

                            oCFL.SetConditions(oCons);
                        }
                        #endregion
                    }
                }
                else if (pVal.BeforeAction == false)
                {
                    #region Stock Transfer Create fields on header
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        string Tablename = oForm.DataSources.DBDataSources.Item(0).TableName;

                        #region Transporter Name
                        oItem = oForm.Items.Item("3");
                        SAPbouiCOM.Item oNewItem = oForm.Items.Add("lblTrans", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                        oNewItem.Left = oItem.Left + oItem.Width + 5;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblTrans").Specific)).Caption = "Transporter name";
                        oNewItem.LinkTo = "3";

                        oItem = oForm.Items.Item("lblTrans");
                        oNewItem = oForm.Items.Add("txtTrans", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                        oNewItem.Left = oItem.Left + oItem.Width + 5;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "lblTrans";
                        ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_TRANSPRT");
                        #endregion

                        #region LR No
                        oItem = oForm.Items.Item("lblTrans");
                        oNewItem = oForm.Items.Add("lblLR", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                        oNewItem.Left = oItem.Left;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top + oItem.Height + 5;
                        oNewItem.Height = oItem.Height;
                        ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblLR").Specific)).Caption = "LR No";
                        oNewItem.LinkTo = "lblTrans";

                        oItem = oForm.Items.Item("lblLR");
                        oNewItem = oForm.Items.Add("txtLR", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                        oNewItem.Left = oItem.Left + oItem.Width + 5;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "lblLR";
                        ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_LRNO");
                        #endregion

                        #region LR Date
                        oItem = oForm.Items.Item("lblLR");
                        oNewItem = oForm.Items.Add("lblLRDt", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                        oNewItem.Left = oItem.Left;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top + oItem.Height + 5;
                        oNewItem.Height = oItem.Height;
                        ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblLRDt").Specific)).Caption = "LR Date";
                        oNewItem.LinkTo = "lblLR";

                        oItem = oForm.Items.Item("lblLRDt");
                        oNewItem = oForm.Items.Add("txtLRDt", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                        oNewItem.Left = oItem.Left + oItem.Width + 5;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "lblLRDt";
                        ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_LRDT");
                        #endregion

                        #region Party Challan no
                        oItem = oForm.Items.Item("lblLRDt");
                        oNewItem = oForm.Items.Add("lblPCNO", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                        oNewItem.Left = oItem.Left;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top + oItem.Height + 5;
                        oNewItem.Height = oItem.Height;
                        ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblPCNO").Specific)).Caption = "Party Challan no";
                        oNewItem.LinkTo = "lblLRDt";

                        oItem = oForm.Items.Item("lblPCNO");
                        oNewItem = oForm.Items.Add("txtPCNO", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                        oNewItem.Left = oItem.Left + oItem.Width + 5;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "lblPCNO";
                        ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PTYCHALL");
                        #endregion

                        #region Five TAKA Report
                        oItem = oForm.Items.Item("lblPCNO");
                        oNewItem = oForm.Items.Add("lblFive", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                        oNewItem.Left = oItem.Left;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top + oItem.Height + 5;
                        oNewItem.Height = oItem.Height;
                        ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblFive").Specific)).Caption = "Five Taka Report";
                        oNewItem.LinkTo = "lblPCNO";

                        oItem = oForm.Items.Item("lblFive");
                        oNewItem = oForm.Items.Add("txtFive", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                        oNewItem.Left = oItem.Left + oItem.Width + 5;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "lblFive";
                        ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_FiveTaka");
                        oNewItem.Enabled = false;
                        #endregion

                        #region AP Invoice Link
                        oItem = oForm.Items.Item("lblFive");
                        oNewItem = oForm.Items.Add("lblAPI", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                        oNewItem.Left = oItem.Left;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top + oItem.Height + 5;
                        oNewItem.Height = oItem.Height;
                        ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblAPI").Specific)).Caption = "AP Invoice";
                        oNewItem.LinkTo = "lblPCNO";

                        oItem = oForm.Items.Item("lblAPI");
                        oNewItem = oForm.Items.Add("txtAPI", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                        oNewItem.Left = oItem.Left + oItem.Width + 5;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "lblAPI";
                        ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_APDOCE");
                        oNewItem.Enabled = false;
                        #endregion

                        //APDOCL
                        #region AP Invoice Line
                        oItem = oForm.Items.Item("lblAPI");
                        oNewItem = oForm.Items.Add("lblAPIL", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                        oNewItem.Left = oItem.Left;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top + oItem.Height + 5;
                        oNewItem.Height = oItem.Height;
                        ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblAPIL").Specific)).Caption = "Line No";
                        oNewItem.LinkTo = "lblPCNO";

                        oItem = oForm.Items.Item("lblAPIL");
                        oNewItem = oForm.Items.Add("txtAPIL", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                        oNewItem.Left = oItem.Left + oItem.Width + 5;
                        oNewItem.Width = oItem.Width;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "lblAPI";
                        ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_APDOCL");
                        oNewItem.Enabled = false;
                        #endregion

                        oItem = oForm.Items.Item("txtTrans");
                        oNewItem = oForm.Items.Add("btnCopy", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                        oNewItem.Left = oItem.Left + oItem.Width + 20;
                        oNewItem.Width = 100;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = "txtTrans";
                        ((SAPbouiCOM.Button)(oForm.Items.Item("btnCopy").Specific)).Caption = "Copy For &Transfer";

                        oItem = oForm.Items.Item("txtLR");
                        oNewItem = oForm.Items.Add("btnSP", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                        oNewItem.Left = oItem.Left + oItem.Width + 20;
                        oNewItem.Width = 100;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.LinkTo = oItem.UniqueID;
                        oNewItem.Enabled = false;
                        ((SAPbouiCOM.Button)(oForm.Items.Item("btnSP").Specific)).Caption = "Select &Pieces";


                    }
                    #endregion

                    #region Get Item
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && (pVal.ItemUID == "txtTrans" || pVal.ItemUID == "txtLR" || pVal.ItemUID == "txtLRDt" || pVal.ItemUID == "txtPCNO"))
                    {
                        oMatrix = oForm.Items.Item("23").Specific;
                        string transporter = ((SAPbouiCOM.EditText)oForm.Items.Item("txtTrans").Specific).Value.ToString();
                        string LRNO = ((SAPbouiCOM.EditText)oForm.Items.Item("txtLR").Specific).Value.ToString();
                        string LRDT = ((SAPbouiCOM.EditText)oForm.Items.Item("txtLRDt").Specific).Value.ToString();
                        string Challan = ((SAPbouiCOM.EditText)oForm.Items.Item("txtPCNO").Specific).Value.ToString();
                        string AP_Doce = ((SAPbouiCOM.EditText)oForm.Items.Item("txtAPI").Specific).Value.ToString();
                        string AP_Line = ((SAPbouiCOM.EditText)oForm.Items.Item("txtAPIL").Specific).Value.ToString();

                        if (AP_Doce != "" && AP_Line != "")
                        {

                            oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            string qry = "select * from OIBT where basetype=18 and Baseentry='" + AP_Doce + "' and baselinnum='" + AP_Line + "'";
                            qry = qry + " and whscode=(select PCH1.WhsCode from PCH1 where PCH1.Docentry='" + AP_Doce + "' and PCH1.LineNum='" + AP_Line + "')";
                            oRs.DoQuery(qry);
                            if (oRs.RecordCount > 0)
                            {
                                oMatrix.Columns.Item("1").Editable = true;
                                oMatrix.Columns.Item("10").Editable = true;
                                oMatrix.Columns.Item("U_BatchNo").Editable = true;

                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", 1)).Value = oRs.Fields.Item("ItemCode").Value.ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", 1)).Value = oRs.Fields.Item("Quantity").Value.ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", 1)).Value = oRs.Fields.Item("BatchNum").Value.ToString();
                                Packing.batchnum = oRs.Fields.Item("BatchNum").Value.ToString();


                                oMatrix.Columns.Item("1").Editable = false;
                                oMatrix.Columns.Item("10").Editable = false;
                                oMatrix.Columns.Item("U_BatchNo").Editable = false;
                                //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("", 1)).Value = oRs.Fields.Item("").Value.ToString();
                                //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("", 1)).Value = oRs.Fields.Item("").Value.ToString();
                                //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("", 1)).Value = oRs.Fields.Item("").Value.ToString();
                            }
                        }
                        else if (transporter != "" && LRNO != "" && LRDT != "" && Challan != "")
                        {
                            oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            string qry = "select * from OIBT where Quantity>0 and U_TRANSPRT='" + transporter + "' and U_LRNO='" + LRNO + "' and U_LRDT='" + LRDT + "' and U_PTYCHALL='" + Challan + "'";
                            oRs.DoQuery(qry);
                            if (oRs.RecordCount > 0)
                            {
                                oMatrix.Columns.Item("1").Editable = true;
                                oMatrix.Columns.Item("10").Editable = true;
                                oMatrix.Columns.Item("U_BatchNo").Editable = true; 

                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", 1)).Value = oRs.Fields.Item("ItemCode").Value.ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", 1)).Value = oRs.Fields.Item("Quantity").Value.ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", 1)).Value = oRs.Fields.Item("BatchNum").Value.ToString();
                                Packing.batchnum = oRs.Fields.Item("BatchNum").Value.ToString();

                                oMatrix.Columns.Item("1").Editable = false;
                                oMatrix.Columns.Item("10").Editable = false;
                                oMatrix.Columns.Item("U_BatchNo").Editable = false;
                                //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("", 1)).Value = oRs.Fields.Item("").Value.ToString();
                                //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("", 1)).Value = oRs.Fields.Item("").Value.ToString();
                                //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("", 1)).Value = oRs.Fields.Item("").Value.ToString();
                            }

                        }
                    }
                    #endregion

                    #region Open  5 Taka
                    if (pVal.ItemUID == "txtFive" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        string takareport = ((SAPbouiCOM.EditText)oForm.Items.Item("txtFive").Specific).Value.ToString();


                        LoadFromXML("FULLTAKAREPORT");

                        xForm = Packing.SBO_Application.Forms.Item("OFT");

                        oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        string SeriesQuery = "SELECT * from NNM1 WHERE ObjectCode='OFT'";

                        oRs.DoQuery(SeriesQuery);

                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        if (takareport != "")
                        {
                            xForm = Packing.SBO_Application.Forms.Item("OFT");
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            ((SAPbouiCOM.EditText)xForm.Items.Item("3").Specific).Value = takareport;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            xForm.Items.Item("Item_71").Enabled = true;
                            xForm.Items.Item("Item_71").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            //foreach (SAPbouiCOM.Item it in xForm.Items)
                            //{
                            //    if (it.UniqueID == "Item_71" || it.UniqueID == "1" || it.UniqueID == "2" || it.UniqueID == "40")
                            //    { }
                            //    else
                            //    {
                            //        it.Enabled = false;
                            //    }
                            //}
                        }
                        else
                        {
                            xForm = Packing.SBO_Application.Forms.Item("OFT");
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                            getfields_taka();
                            oMatrix = xForm.Items.Item("35").Specific;
                            oMatrix.AddRow(1, 0);
                            xForm.Items.Item("Item_71").Enabled = false;
                        }
                    }
                    #endregion

                    #region Open  PI
                    if (pVal.ItemUID == "txtAPI" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        string ST = ((SAPbouiCOM.EditText)oForm.Items.Item("txtAPI").Specific).Value.ToString();
                        if (ST != "")
                        {
                            Packing.SBO_Application.ActivateMenuItem("2308");
                            xForm = Packing.SBO_Application.Forms.ActiveForm;//GetForm("141", 1)
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            ((SAPbouiCOM.ComboBox)xForm.Items.Item("88").Specific).Select(oDal.ExSelect("Select Series from OPCH where Docentry='" + ST + "'", ""), SAPbouiCOM.BoSearchKey.psk_ByValue);
                            ((SAPbouiCOM.EditText)xForm.Items.Item("8").Specific).Value = oDal.ExSelect("Select DocNum from OPCH where Docentry='" + ST + "'", "");
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }
                    }
                    #endregion


                    #region Open  Base Document
                    if (pVal.ItemUID == "23" && pVal.ColUID == "U_POBSEntry" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        oMatrix = oForm.Items.Item("23").Specific;
                        string DE = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", pVal.Row)).Value.ToString();
                        string Line = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSLine", pVal.Row)).Value.ToString();
                        string Basetype = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", pVal.Row)).Value.ToString();
                        if (DE != "" && Line != "" && Basetype != "")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please Wait!!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                            if (Basetype == "18")
                            {
                                Packing.SBO_Application.ActivateMenuItem("2308");
                                xForm = Packing.SBO_Application.Forms.ActiveForm;//GetForm("141", 1)
                                xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                ((SAPbouiCOM.ComboBox)xForm.Items.Item("88").Specific).Select(oDal.ExSelect("Select Series from OPCH where Docentry='" + DE + "'", ""), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                ((SAPbouiCOM.EditText)xForm.Items.Item("8").Specific).Value = oDal.ExSelect("Select DocNum from OPCH where Docentry='" + DE + "'", "");
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            }
                            else if (Basetype == "20")
                            {
                                Packing.SBO_Application.ActivateMenuItem("2306");
                                xForm = Packing.SBO_Application.Forms.ActiveForm;//GetForm("141", 1)
                                xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                ((SAPbouiCOM.ComboBox)xForm.Items.Item("88").Specific).Select(oDal.ExSelect("Select Series from OPDN where Docentry='" + DE + "'", ""), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                ((SAPbouiCOM.EditText)xForm.Items.Item("8").Specific).Value = oDal.ExSelect("Select DocNum from OPDN where Docentry='" + DE + "'", "");
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            }
                            else if (Basetype == "59")
                            {
                                Packing.SBO_Application.ActivateMenuItem("3078");
                                xForm = Packing.SBO_Application.Forms.ActiveForm;//GetForm("141", 1)
                                xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                ((SAPbouiCOM.ComboBox)xForm.Items.Item("30").Specific).Select(oDal.ExSelect("Select Series from OIGN where Docentry='" + DE + "'", ""), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                ((SAPbouiCOM.EditText)xForm.Items.Item("7").Specific).Value = oDal.ExSelect("Select DocNum from OIGN where Docentry='" + DE + "'", "");
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            }
                            Packing.SBO_Application.StatusBar.SetText("Success!!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }
                    }
                    #endregion

                    #region select warehouse on BP partner lost focus
                    if (pVal.ItemUID == "3" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
                    {
                        string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("3").Specific).Value.ToString();
                        string whse = oDal.ExSelect("select U_Whse from OCRD where CardCode='" + cardcode + "'", "");
                        if (whse != "")
                        {
                            ((SAPbouiCOM.EditText)oForm.Items.Item("18").Specific).Value = whse;
                            update_row_jobworker();
                        }
                    }
                    #endregion

                    if (pVal.ItemUID == "23" && pVal.ColUID == "1" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
                    {
                        update_row_jobworker();
                    }

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "btnCopy")
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            oForm = Packing.SBO_Application.Forms.ActiveForm;
                            for (int i = 1; i < Packing.SBO_Application.Forms.Count; i++)
                            {
                                if (Packing.SBO_Application.Forms.Item(i).UniqueID == "IT_Transfer")
                                {
                                    Packing.SBO_Application.Forms.Item(i).Select();
                                    //return;
                                }
                            }

                            LoadFromXML("IT_Transfer");


                        }
                        else
                        {
                            Packing.SBO_Application.StatusBar.SetText("Sorry, This document is already added", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                    }
                }

                return true;
            }
            catch
            { return false; }
        }


        public void LoadFromXML(String FormName)
        {
            string sXmlFileName;
            string QStr = null;
            string DocEnt = null;




            int Docentry = 0;

            //SAPbobsCOM.Recordset InsertRec = null;
            //InsertRec = (SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset));

            sXmlFileName = Application.StartupPath.ToString();
            sXmlFileName = sXmlFileName + "\\" + FormName + ".srf";
            XmlDocument oXmlDoc = new XmlDocument();
            oXmlDoc.Load(sXmlFileName);
            string sXML = oXmlDoc.InnerXml.ToString();
            Packing.SBO_Application.LoadBatchActions(ref sXML);
            oForm = Packing.SBO_Application.Forms.ActiveForm;

            if (FormName == "IT_Transfer")
            {
                Packing.whse = "";
                xForm = Packing.SBO_Application.Forms.Item("IT_Transfer");
                oCombo = xForm.Items.Item("6").Specific;
                oCombo.ValidValues.Add("18", "Purchase Invoice");
                oCombo.ValidValues.Add("20", "Goods Receipt PO");
                oCombo.ValidValues.Add("59", "Goods Receipt");

                xForm.Items.Item("6").DisplayDesc = true;
            }

            if (FormName == "SHIPMENT1")
            {
                oForm = Packing.SBO_Application.Forms.Item("SHIPMENT");
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;



                //oForm.DataBrowser.BrowseBy = "3";

                //  oMatrix = oForm.Items.Item("5").Specific;


                xForm = Packing.SBO_Application.Forms.GetForm("143", 1);





                for (int i = 0; i < oMatrix.VisualRowCount - 1; i++)
                {
                    //oColumn.ValidValues.Add(oRs.Fields.Item(0).Value.ToString(), oRs.Fields.Item(1).Value.ToString());
                    oRs.MoveNext();
                }



                for (int i = 0; i <= oMatrix.VisualRowCount - 1; i++)
                {
                    //   oColumn.ValidValues.Add(oRs.Fields.Item(0).Value.ToString(), oRs.Fields.Item(1).Value.ToString());
                    oRs.MoveNext();
                }
            }
        }

        public void getfields_taka()
        {
            try
            {
                string series = ((SAPbouiCOM.ComboBox)oForm.Items.Item("40").Specific).Selected.Value.ToString();
                string docnum = ((SAPbouiCOM.EditText)oForm.Items.Item("11").Specific).Value.ToString();

                string qry = "select ToWhsCode,T2.U_LRNO,T2.U_LRDT,T2.ItemCode,T0.DocEntry,T2.U_PTYCHALL,T2.BatchNum from IBT1 [T1] inner join OWTR [T0] on T1.BaseEntry=T0.DocEntry and T1.BaseType=T0.ObjType and T0.ToWhsCode=T1.WhsCode "
                    //ajay
                    + " inner join OIBT [T2] on T1.BatchNum=T2.BatchNum and T1.WhsCode=T2.WhsCode where T0.DocNum=" + docnum + " and T0.Series='" + series + "'";

                oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                oRs.DoQuery(qry);
                if (oRs.RecordCount > 0)
                {
                    ((SAPbouiCOM.EditText)xForm.Items.Item("Item_0").Specific).String = "a";
                    ((SAPbouiCOM.EditText)xForm.Items.Item("Item_39").Specific).Value = oDal.ExSelect("select cardname from OCRD where U_Whse='" + oRs.Fields.Item("ToWhsCode").Value.ToString() + "'", "");
                    ((SAPbouiCOM.EditText)xForm.Items.Item("Item_40").Specific).Value = oRs.Fields.Item("U_LRNO").Value.ToString();
                    string lrdt1 = (oRs.Fields.Item("U_LRDT").Value.ToString());
                    ((SAPbouiCOM.EditText)xForm.Items.Item("Item_41").Specific).String = lrdt1.Replace(" 00:00:00", "").Replace(" 12:00:00 AM","");
                    //((SAPbouiCOM.EditText)xForm.Items.Item("45").Specific).Value = oRs.Fields.Item("BatchNum").Value.ToString();
                    ((SAPbouiCOM.EditText)xForm.Items.Item("Item_2").Specific).Value = oRs.Fields.Item("DocEntry").Value.ToString();
                    ((SAPbouiCOM.EditText)xForm.Items.Item("Item_74").Specific).Value = oRs.Fields.Item("ItemCode").Value.ToString();
                    ((SAPbouiCOM.EditText)xForm.Items.Item("41").Specific).Value = oRs.Fields.Item("U_PTYCHALL").Value.ToString();


                    string doctype = oDal.ExSelect("SELECT BaseType FROM oibt WHERE BATCHNUM='" + oRs.Fields.Item("BatchNum").Value.ToString() + "'", "");
                    string qry1 = "";
                    if (doctype == "18")
                    {
                        qry1 = " select top 1 T4.DocNum,T4.CardName,T4.DocDate,T4.U_Broker from PCH1 [T2] inner join  OIBT [T3] on T2.ObjType=T3.BaseType and T2.DocEntry=T3.BaseEntry and T2.LineNum=T3.BaseLinNum "
                                     + " inner join OPCH [T4] on T2.DocEntry = T4.DocEntry  where T3.BatchNum='" + oRs.Fields.Item("BatchNum").Value.ToString() + "'";
                    }
                    else if (doctype == "59")
                    {
                        qry1 = "select top 1 T4.DocNum,(select OCRD.Cardname from OCRD where U_WHSE=T2.WhsCode) CardName,T4.DocDate,T4.U_Broker from IGN1 [T2] inner join  OIBT [T3] on T2.ObjType=T3.BaseType and T2.DocEntry=T3.BaseEntry and T2.LineNum=T3.BaseLinNum  inner join OIGN [T4] on T2.DocEntry = T4.DocEntry  where T3.BatchNum='" + oRs.Fields.Item("BatchNum").Value.ToString() + "'";
                    }
                    SAPbobsCOM.Recordset ORSBatch = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    ORSBatch.DoQuery(qry1);
                    if (ORSBatch.RecordCount > 0)
                    {
                        ((SAPbouiCOM.EditText)xForm.Items.Item("Item_33").Specific).Value = ORSBatch.Fields.Item("DocNum").Value.ToString();
                        ((SAPbouiCOM.EditText)xForm.Items.Item("Item_36").Specific).Value = ORSBatch.Fields.Item("CardName").Value.ToString();
                        ((SAPbouiCOM.EditText)xForm.Items.Item("Item_38").Specific).Value = ORSBatch.Fields.Item("U_Broker").Value.ToString();
                        string pchdate = ORSBatch.Fields.Item("DocDate").Value.ToString();
                        ((SAPbouiCOM.EditText)xForm.Items.Item("Item_72").Specific).String = pchdate.Replace(" 00:00:00", "");
                        //((SAPbouiCOM.EditText)xForm.Items.Item("Item_2").Specific).Value = oRs.Fields.Item("DocEntry").Value.ToString();
                    }
                }

            }
            catch { }

        }

        public void update_row_jobworker()
        {
            try
            {
                string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("3").Specific).Value.ToString();
                oMatrix = oForm.Items.Item("23").Specific;
                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                {
                    string icode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).Value.ToString();
                    if (icode != "")
                    {
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Jobwrkr", i)).Value = cardcode;
                    }

                }
            }
            catch { }
        }
    }
}

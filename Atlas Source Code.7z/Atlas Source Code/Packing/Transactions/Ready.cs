﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace Packing.Transactions
{
    class Ready
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.Column oColumn;
        private SAPbouiCOM.Columns oColumns;
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                #region beforeaction true
                if (pVal.BeforeAction == true)
                {
                    if (pVal.ItemUID == "1" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        oMatrix = oForm.Items.Item("4").Specific;
                        for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                        {
                            string de = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).Value.ToString();
                            if (de == "")
                            {
                                Packing.SBO_Application.StatusBar.SetText("Packing List not found for line :" + i.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                return false;
                            }
                        }
                    }
                }
                #endregion

                #region beforeaction false
                else if (pVal.BeforeAction == false)
                {
                    #region Open Packing List
                    if (pVal.ItemUID == "4" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK)
                    {
                        if (pVal.Row != 0)
                        {
                            oMatrix = oForm.Items.Item("4").Specific;
                            string Proc = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0",pVal.Row)).Value.ToString();


                            LoadFromXML("packingdetails");

                            xForm = Packing.SBO_Application.Forms.Item("OPCKDT");
                            oMatrix1 = xForm.Items.Item("Item_13").Specific;
                            oMatrix1.Columns.Item("V_5").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto;
                            oMatrix1.Columns.Item("V_4").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto;
                            oMatrix1.Columns.Item("Col_4").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto;
                            oMatrix1.Columns.Item("Col_5").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto;
                            oMatrix1.Columns.Item("Col_6").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto;
                            oMatrix1.Columns.Item("Col_7").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto;
                            oMatrix1.Columns.Item("Col_8").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto;

                            oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                            oMatrix = oForm.Items.Item("4").Specific;
                            


                            string IName = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row)).Value.ToString();
                            string Whse = "01";
                            string ICode = oDal.ExSelect("select ItemCode from OITM where ItemName='"+IName+"'","");

                            Packing.ParentCount_PackDet = pVal.FormTypeCount;
                            Packing.ParentForm_PackDet = "Ready";
                            Packing.PrgSheet_CurrentRow = pVal.Row;
                            
                            if (Proc != "")
                            {
                                xForm = Packing.SBO_Application.Forms.Item("OPCKDT");
                                xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                ((SAPbouiCOM.EditText)xForm.Items.Item("3").Specific).Value = Proc;
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                xForm.Items.Item("btnCopy").Enabled = false;
                            }
                            else
                            {
                                xForm = Packing.SBO_Application.Forms.Item("OPCKDT");
                                xForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                                oMatrix = xForm.Items.Item("Item_13").Specific;
                                oMatrix.AddRow(1, 0);
                                ((SAPbouiCOM.EditText)xForm.Items.Item("12").Specific).Value = ICode;
                                xForm.Items.Item("Item_5").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                xForm.Items.Item("12").Enabled = false;
                                xForm.Items.Item("Item_3").Enabled = false;
                                xForm.Items.Item("btnCopy").Enabled = false;
                            }

                        }
                    }
                    #endregion

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED && pVal.ItemUID == "1" && pVal.BeforeAction == false && pVal.ActionSuccess == true)
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            string lastPackD = oDal.ExSelect("select Max(Docentry) from [@Ready]", "");
                            oForm.Close();

                            xForm = Packing.SBO_Application.Forms.GetForm("143", Packing.ParentCount_PackDet);
                            ((SAPbouiCOM.EditText)xForm.Items.Item("txtPL").Specific).Value = lastPackD;


                            #region Copy to Purchase Invoice
                            oForm = Packing.SBO_Application.Forms.GetForm(Packing.ParentForm_CFPO, Packing.ParentCount_CFPO);
                            oMatrix = oForm.Items.Item("38").Specific;
                            SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            oRset.DoQuery("exec sp_Ready_Split '" + lastPackD + "'");
                            string[] exist_po = new string[1000];
                            int exist_cnt = 0;

                            oMatrix.Columns.Item("1").Editable = true;

                            for (int i = 0; i < oRset.RecordCount; i++)
                            {
                                try
                                {

                                    string Doce = oRset.Fields.Item("DocEntry").Value.ToString();
                                    string line = oRset.Fields.Item("LineNum").Value.ToString();

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i + 1)).Value = oRset.Fields.Item("ItemCode").Value.ToString();
                                    //SAPbouiCOM.CommonSetting oRowCtrl =oMatrix.CommonSetting;
                                    //oRowCtrl.SetCellEditable(i + 1, 1, false);



                                    oForm.Freeze(true);

                                    try
                                    {
                                        oColumn = oMatrix.Columns.Item("U_SUOM");
                                        oColumn.Editable = true;
                                        ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_SUOM", i + 1)).Select(oRset.Fields.Item("U_SUOM").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    }
                                    catch { }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i + 1)).Value = oRset.Fields.Item("Mtr Per Bale").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("11").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i + 1)).Value = oRset.Fields.Item("Mtr Per Bale").Value.ToString(); ;
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", i + 1)).Value = oRset.Fields.Item("Mtr Per Bale").Value.ToString(); ;
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_GrsQty").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", i + 1)).Value = oRset.Fields.Item("Mtr Per Bale").Value.ToString(); ;
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", i + 1)).Value = oRset.Fields.Item("PriceBefDi").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("14").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", i + 1)).Value = oRset.Fields.Item("PriceBefDi").Value.ToString();
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i + 1)).Value = oRset.Fields.Item("DiscPrcnt").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("15").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i + 1)).Value = oRset.Fields.Item("DiscPrcnt").Value.ToString();
                                    }

                                    try
                                    {

                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", i + 1)).Value = oRset.Fields.Item("U_Pcs").Value.ToString(); ;
                                        oColumn = oMatrix.Columns.Item("U_SUOM");
                                        oColumn.Editable = false;
                                    }
                                    catch { }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", i + 1)).Value = oRset.Fields.Item("Bale").Value.ToString(); ;//oRset.Fields.Item("U_Bale").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_Bale").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", i + 1)).Value = oRset.Fields.Item("Bale").Value.ToString(); ;//oRset.Fields.Item("U_Bale").Value.ToString();

                                    }

                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", i + 1)).Value = oRset.Fields.Item("U_Yards").Value.ToString();//oRset.Fields.Item("U_Yard").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_Yard").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", i + 1)).Value = oRset.Fields.Item("U_Yards").Value.ToString();//oRset.Fields.Item("U_Yard").Value.ToString();
                                    }

                                    try
                                    {
                                        ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_RateBaseOn", i + 1)).Select(oRset.Fields.Item("U_RateBaseOn").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_RateBaseOn").Visible = true;
                                        ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_RateBaseOn", i + 1)).Select(oRset.Fields.Item("U_RateBaseOn").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRate", i + 1)).Value = oRset.Fields.Item("U_SRate").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_SRate").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRate", i + 1)).Value = oRset.Fields.Item("U_SRate").Value.ToString();
                                    }

                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_YardTMtr", i + 1)).Value = oRset.Fields.Item("U_YardTMtr").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_YardTMtr").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_YardTMtr", i + 1)).Value = oRset.Fields.Item("U_YardTMtr").Value.ToString();
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i + 1)).Value = oRset.Fields.Item("DiscPrcnt").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("15").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", i + 1)).Value = oRset.Fields.Item("DiscPrcnt").Value.ToString();
                                    }
                                    //try
                                    //{
                                    //    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_U_Jobw", i + 1)).Value = oRset.Fields.Item("U_U_Jobw").Value.ToString();
                                    //}
                                    //catch 
                                    //{
                                    //    oMatrix.Columns.Item("U_U_Jobw").Visible = true;
                                    //    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_U_Jobw", i + 1)).Value = oRset.Fields.Item("U_U_Jobw").Value.ToString();
                                    //}

                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", i + 1)).Value = oRset.Fields.Item("U_JobWrkr").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_JobWrkr").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", i + 1)).Value = oRset.Fields.Item("U_JobWrkr").Value.ToString();
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkrNm", i + 1)).Value = oRset.Fields.Item("U_JobWrkrNm").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_JobWrkrNm").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkrNm", i + 1)).Value = oRset.Fields.Item("U_JobWrkrNm").Value.ToString();
                                    }


                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", i + 1)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_POBSEntry").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", i + 1)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSLine", i + 1)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_POBSLine").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSLine", i + 1)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", i + 1)).Value = oRset.Fields.Item("TaxCode").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("160").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", i + 1)).Value = oRset.Fields.Item("TaxCode").Value.ToString();
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", i + 1)).Value = oRset.Fields.Item("WhsCode").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("24").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", i + 1)).Value = oRset.Fields.Item("WhsCode").Value.ToString();
                                    }


                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CutPcs", i + 1)).Value = oRset.Fields.Item("U_Cut").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_CutPcs").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CutPcs", i + 1)).Value = oRset.Fields.Item("U_Cut").Value.ToString();
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_STBALE", i + 1)).Value = oRset.Fields.Item("U_BaleFrom").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_STBALE").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_STBALE", i + 1)).Value = oRset.Fields.Item("U_BaleFrom").Value.ToString();
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ENBALE", i + 1)).Value = oRset.Fields.Item("U_BaleTo").Value.ToString();
                                    }
                                    catch
                                    {
                                        oMatrix.Columns.Item("U_ENBALE").Visible = true;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ENBALE", i + 1)).Value = oRset.Fields.Item("U_BaleTo").Value.ToString();
                                    }



                                    try
                                    {
                                        //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", i + 1)).Value = oRset.Fields.Item("U_JobWrkr").Value.ToString();
                                        //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkrNm", i + 1)).Value = oRset.Fields.Item("U_JobWrkrNm").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgShtDE", i + 1)).Value = oRset.Fields.Item("U_PrgShtDE").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgShtDN", i + 1)).Value = oRset.Fields.Item("U_PrgShtDN").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Label", i + 1)).Value = oRset.Fields.Item("U_Label").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgSer", i + 1)).Value = oRset.Fields.Item("U_PrgSer").Value.ToString();
                                    }
                                    catch { }

                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oForm.Items.Item("U_Broker").Specific).Value = oRset.Fields.Item("U_Broker").Value.ToString();
                                    }
                                    catch
                                    { }
                                    oForm.Freeze(false);

                                    
                                }
                                catch
                                { }

                                bool chpresent = false;
                                string docentry=oRset.Fields.Item("DocEntry").Value.ToString();
                                for (int j = 0; j < exist_cnt; j++)
                                {
                                    
                                    if (exist_po[j].ToString() == docentry)
                                    {
                                        chpresent = true;
                                    }
                                }
                                if (!chpresent)
                                {
                                    exist_po[exist_cnt] = docentry;
                                    exist_cnt = exist_cnt + 1;
                                }

                                oRset.MoveNext();
                            }

                            oMatrix.Columns.Item("1").Editable = false;


                            oForm.Freeze(true);
                            oForm.Items.Item("138").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            oForm.Items.Item("498").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            xForm = Packing.SBO_Application.Forms.GetForm("540020007", 1);
                            SAPbouiCOM.Matrix omatrix1 = xForm.Items.Item("5").Specific;

                            for (int z = 0; z < exist_cnt; z++)
                            {
                                try
                                {
                                    oCombo = ((SAPbouiCOM.ComboBox)omatrix1.GetCellSpecific("1", z+1));
                                    oCombo.Select("22", SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    ((SAPbouiCOM.EditText)omatrix1.GetCellSpecific("3", z + 1)).Value = oDal.ExSelect("select Docnum from OPOR where Docentry='" + exist_po[z].ToString() + "'", "");
                                    

                                    
                                }
                                catch
                                {
                                    oForm.Freeze(false);
                                }
                            }
                            xForm.Items.Item("540020001").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            oForm.Items.Item("112").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            oForm.Items.Item("14").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            oForm.Freeze(false);
                            #endregion


                        }
                    }
                }
                #endregion


                return true;
            }
            catch { return false; }
        }


        public void LoadFromXML(String FormName)
        {
            string sXmlFileName;
            string QStr = null;
            string DocEnt = null;
            int Docentry = 0;

            //SAPbobsCOM.Recordset InsertRec = null;
            //InsertRec = (SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset));

            sXmlFileName = Application.StartupPath.ToString();
            sXmlFileName = sXmlFileName + "\\" + FormName + ".srf";
            XmlDocument oXmlDoc = new XmlDocument();
            oXmlDoc.Load(sXmlFileName);
            string sXML = oXmlDoc.InnerXml.ToString();
            Packing.SBO_Application.LoadBatchActions(ref sXML);
            oForm = Packing.SBO_Application.Forms.ActiveForm;


        }
    }
}

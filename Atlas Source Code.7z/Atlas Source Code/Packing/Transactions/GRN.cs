﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace Packing.Transactions
{
    class GRN
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.Column oColumn;
        private SAPbouiCOM.Columns oColumns;
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                #region beforeaction true
                if (pVal.BeforeAction == true)
                {
                    #region AP Invoice Can not change Item If copied from PO
                    if (pVal.FormTypeEx == "143" && pVal.ItemUID == "38" && pVal.ColUID == "1" && (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK || pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN || pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST) && pVal.BeforeAction == true)
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        oMatrix = oForm.Items.Item("38").Specific;
                        string PObaseentry = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", pVal.Row)).Value.ToString();
                        if (PObaseentry != "" && pVal.CharPressed != 9)
                        {
                            BubbleEvent = false;
                        }

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {

                        }
                    }


                    #endregion

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE && pVal.ItemUID == "4")
                    {
                        string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value.ToString();
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("cmbFSett").Specific;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            if (cardcode != "" && oCombo.Selected == null)
                            {
                                Packing.SBO_Application.StatusBar.SetText("Please select Form Setting for respective Entry", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                return false;
                            }
                            else if (cardcode == "")
                            { }
                            else
                            {

                                string formsetting = ((SAPbouiCOM.ComboBox)oForm.Items.Item("cmbFSett").Specific).Selected.Value.ToString();
                                if (cardcode != "" && formsetting == "")
                                {
                                    Packing.SBO_Application.StatusBar.SetText("Please select Form Setting for respective Entry", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return false;
                                }
                            }
                        }
                    }

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.FormTypeEx == "143" && pVal.BeforeAction == true && pVal.ItemUID == "10000329")
                    {
                        try
                        {
                            oForm = Packing.SBO_Application.Forms.GetForm("143", pVal.FormTypeCount);
                            oCombo = oForm.Items.Item("10000329").Specific;
                            oCombo.ValidValues.Add("Issue To JobWorker", "Jobworker Issue");
                        }
                        catch { }
                    }

                    #region choose from list on Goods Issue for Goods Receipt Beore action true
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "txtRec" && pVal.BeforeAction == true) //
                    {
                        //oForm = Packing.SBO_Application.Forms.ActiveForm;
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        String CardCode = "";
                        //CardCode = oForm.Items.Item("Item_4").Specific.value;
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL
                        //oCFL1 = oForm.ChooseFromLists.Item(sCFL_ID);

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();



                        oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        string qry = "select DocEntry from OIGN where DocEntry not in (select distinct U_RecNum from OPCH where U_RecNum  is not null)";

                        oRs.DoQuery(qry);

                        if (oRs.RecordCount > 0)
                        {
                            oCon = oCons.Add();
                            for (int i = 0; i < oRs.RecordCount; i++)
                            {
                                if (i > 0)
                                {
                                    oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                                    oCon = oCons.Add();
                                }

                                oCon.Alias = "DocEntry";
                                oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                                oCon.CondVal = oRs.Fields.Item("DocEntry").Value.ToString();
                                oRs.MoveNext();
                            }

                            oCFL.SetConditions(oCons);
                        }

                        //oCon.Alias = "DocStatus";
                        //oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        //oCon.CondVal = "O";
                        //oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND;


                        //oCon = oCons.Add();
                        //oCon.Alias = "CardCode";
                        //oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        //oCon.CondVal = CardCode;


                    }
                    #endregion

                    if (pVal.ItemUID == "14" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE)
                    {
                        string numatcard = ((SAPbouiCOM.EditText)oForm.Items.Item("14").Specific).Value.ToString();
                        string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value.ToString();
                        string cnt = oDal.ExSelect("select isnull(count(Docentry),0) from OPCH where Cardcode='" + cardcode + "' and Numatcard='" + numatcard + "' and canceled='N'", "");
                        if (Convert.ToInt32(cnt) > 0 && oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            Packing.SBO_Application.StatusBar.SetText("This Ref. No. Already Present in system. Please change or find existing.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            return false;
                        }


                    }

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE && pVal.ItemUID == "38" && pVal.ColUID == "U_SRate")
                    {
                        oMatrix = oForm.Items.Item("38").Specific;
                        string pobase_entry = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", pVal.Row)).Value.ToString();
                        string PObase_Line = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSLine", pVal.Row)).Value.ToString();
                        string U_Srate = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRate", pVal.Row)).Value.ToString();
                        double U_Srate_dbl = Convert.ToDouble(U_Srate);
                        string superuser = oDal.ExSelect("select superuser from OUSR where User_code='" + Packing.oCompany.UserName + "'", "");

                        if (pobase_entry != "" && PObase_Line != "")
                        {
                            string PORate = oDal.ExSelect("select isnull(U_SRate,'0') from POR1 where Docentry='" + pobase_entry + "' and LineNum='" + PObase_Line + "'", "");
                            double PORate_dbl = Convert.ToDouble(PORate);


                            if ((U_Srate_dbl < PORate_dbl - 0.25 || U_Srate_dbl > PORate_dbl + 0.25) && superuser == "N")
                            {
                                Packing.SBO_Application.StatusBar.SetText("Sorry, PO Rate Can not be changed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRate", pVal.Row)).Value = PORate;
                                //return false;
                            }


                        }
                    }

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN && pVal.ItemUID == "38" && (pVal.ColUID == "U_PrgShtDE" || pVal.ColUID == "U_PrgShtDN" || pVal.ColUID == "U_JobWrkr" || pVal.ColUID == "U_JobWrkrNm" || pVal.ColUID == "U_Label" || pVal.ColUID == "U_PrgSer" || pVal.ColUID == "U_POBSEntry" || pVal.ColUID == "U_POBSLine"))
                    {
                        if (pVal.CharPressed != 9)
                        {
                            return false;
                        }
                    }
                }
                #endregion

                #region beforeaction false
                else if (pVal.BeforeAction == false)
                {
                    #region Ap Invoice Fold Percentage
                    if (pVal.FormTypeEx == "143" && pVal.BeforeAction == false && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "38" && pVal.ColUID == "U_FoldPer")
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        oMatrix = oForm.Items.Item("38").Specific;
                        string foldper = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value.ToString();
                        string grsqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", pVal.Row)).Value.ToString();
                        string foldqty_Act = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FoldQty", pVal.Row)).Value.ToString();


                        double foldqty = Convert.ToDouble(grsqty) * (Convert.ToDouble(foldper) / 100);

                        if (foldqty > 0)
                        {
                            Packing.SBO_Application.MessageBox("Fold Meters is " + (Math.Round(foldqty, 1)).ToString() + " .", 1, "Ok", "", "");
                            if (Math.Round(Convert.ToDouble(foldqty_Act), 0) != Math.Round(foldqty, 0))
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FoldQty", pVal.Row)).Value = (Math.Round(foldqty, 1)).ToString();
                        }
                        else if (foldqty == 0 && Convert.ToDouble(foldqty_Act) > 0)
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FoldQty", pVal.Row)).Value = "0";
                        }




                        //SAPbouiCOM.DBDataSource db = oForm.DataSources.DBDataSources.Item("PCH1");

                        //db.SetValue("AcctCode", 1, "5405079");

                        //oMatrix.Columns.Item("29").Editable = true;

                        //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("29", pVal.Row)).Value = "5405079";
                    }
                    #endregion

                    #region fold qty calculation
                    if (pVal.FormTypeEx == "143" && pVal.BeforeAction == false && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "38" && pVal.ColUID == "U_FoldQty")
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        oMatrix = oForm.Items.Item("38").Specific;

                        string qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", pVal.Row)).Value.ToString(); ;
                        string foldqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FoldQty", pVal.Row)).Value.ToString();

                        if (Convert.ToDouble(foldqty) == 0)
                            foldqty = "0";

                        try
                        {
                            double foldper = (Convert.ToDouble(foldqty) / Convert.ToDouble(qty)) * 100;
                            string actfoldper = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FoldPer", pVal.Row)).Value.ToString();
                            if (Math.Round((Convert.ToDouble(actfoldper)), 4) != Math.Round(foldper, 4))
                            {
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FoldPer", pVal.Row)).Value = Math.Round(foldper, 4).ToString();
                            }
                        }
                        catch
                        { }

                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", pVal.Row)).Value = (Math.Round((Convert.ToDouble(qty) - Convert.ToDouble(foldqty)), 1)).ToString();

                    }

                    #endregion

                    #region Ap Invoice Lost focus QTY check
                    if (pVal.FormTypeEx == "143" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "38" && (pVal.ColUID == "U_Pcs" || pVal.ColUID == "U_Yard" || pVal.ColUID == "U_Bale" || pVal.ColUID == "U_GrsQty"))
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE && pVal.BeforeAction == false)
                        {
                            oMatrix = oForm.Items.Item("38").Specific;
                            string SecondUOM = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_SUOM", pVal.Row)).Selected.Value.ToString();
                            string grsqty = "";// ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", pVal.Row)).Value.ToString();
                            string baseqty = "";
                            string prevqty = "";
                            string field = "";

                            string baseentry_field = "BaseEntry";
                            string baseline_field = "BaseLine";

                            string basekey = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("45", pVal.Row)).Value.ToString();
                            string baseLine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("46", pVal.Row)).Value.ToString();

                            if (basekey == "" && baseLine == "")
                            {
                                basekey = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", pVal.Row)).Value.ToString();
                                baseLine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSLine", pVal.Row)).Value.ToString();
                                baseentry_field = "U_POBSEntry";
                                baseline_field = "U_POBSLine";
                            }

                            if (SecondUOM == "Mtr")
                            {
                                grsqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", pVal.Row)).Value.ToString();
                                baseqty = oDal.ExSelect("select Quantity from POR1  where DocEntry='" + basekey + "' and LineNum='" + baseLine + "'", "");
                                prevqty = oDal.ExSelect("select isnull(sum(U_grsqty),0) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1." + baseentry_field + "='" + basekey + "' and " + baseline_field + "='" + baseLine + "'", "");
                                field = "Gross Qty";
                            }
                            else if (SecondUOM == "Pcs")
                            {
                                grsqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", pVal.Row)).Value.ToString();
                                baseqty = oDal.ExSelect("select U_pcs from POR1 where DocEntry='" + basekey + "' and LineNum='" + baseLine + "'", "");
                                prevqty = oDal.ExSelect("select isnull(sum(U_pcs),0) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and " + baseentry_field + "='" + basekey + "' and " + baseline_field + "='" + baseLine + "'", "");
                                field = "Pieces";
                            }
                            else if (SecondUOM == "Bale")
                            {
                                grsqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", pVal.Row)).Value.ToString();
                                baseqty = oDal.ExSelect("select U_Bale from POR1 where DocEntry='" + basekey + "' and LineNum='" + baseLine + "'", "");
                                prevqty = oDal.ExSelect("select isnull(sum(U_Bale),0) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and " + baseentry_field + "='" + basekey + "' and " + baseline_field + "='" + baseLine + "'", "");
                                field = "Bale";
                            }
                            else if (SecondUOM == "Yard")
                            {
                                grsqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", pVal.Row)).Value.ToString();
                                baseqty = oDal.ExSelect("select U_Yard from POR1 where DocEntry='" + basekey + "' and LineNum='" + baseLine + "'", "");
                                prevqty = oDal.ExSelect("select isnull(sum(U_Yard),0) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and " + baseentry_field + "='" + basekey + "' and " + baseline_field + "='" + baseLine + "'", "");
                                field = "Yards";
                            }

                            if (Convert.ToDouble(baseqty) < (Convert.ToDouble(prevqty) + Convert.ToDouble(grsqty)))
                            {
                                Packing.SBO_Application.MessageBox("Excess Qty Found in " + field + ". Please Update PO or Quantity", 1, "Ok", "", "");
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value = (Convert.ToDouble(baseqty) - Convert.ToDouble(prevqty)).ToString();
                                BubbleEvent = false;

                            }


                        }
                        //double foldqty = Convert.ToDouble(grsqty) * (Convert.ToDouble(foldper) / 100);

                        //if (foldqty > 0)
                        //{
                        //    SBO_Application.MessageBox("Fold Meters is " + (Math.Round(foldqty, 1)).ToString() + " .", 1, "Ok", "", "");
                        //    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FoldQty", pVal.Row)).Value = (Math.Round(foldqty, 1)).ToString();
                        //}
                    }
                    #endregion

                    #region Purchase Order yard to meter calculation
                    if (pVal.ItemUID == "38" && (pVal.ColUID == "U_Yard" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS) || (pVal.ColUID == "U_YardTMtr" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS) && pVal.BeforeAction == false)
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        oMatrix = oForm.Items.Item("38").Specific;
                        string SUOM = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_SUOM", pVal.Row)).Selected.Value.ToString();
                        if (SUOM == "Yard")
                        {
                            oForm.Freeze(true);
                            string yard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", pVal.Row)).Value.ToString();
                            string yardtmtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_YardTMtr", pVal.Row)).Value.ToString();
                            string qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", pVal.Row)).Value.ToString();

                            if (Convert.ToDouble(qty) != Convert.ToDouble(yard) * Convert.ToDouble(yardtmtr))
                            {
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", pVal.Row)).Value = (Convert.ToDouble(yard) * Convert.ToDouble(yardtmtr)).ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrsQty", pVal.Row)).Value = (Convert.ToDouble(yard) * Convert.ToDouble(yardtmtr)).ToString();
                            }
                            oForm.Freeze(false);
                        }
                    }
                    #endregion


                    #region Add Button On PI
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        string Tablename = oForm.DataSources.DBDataSources.Item(0).TableName;

                        if (pVal.FormTypeEx == "143")
                        {


                            oItem = oForm.Items.Item("4");
                            SAPbouiCOM.Item oNewItem = oForm.Items.Add("btnCopy", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oNewItem.Left = oItem.Left + oItem.Width + 20;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "4";
                            ((SAPbouiCOM.Button)(oForm.Items.Item("btnCopy").Specific)).Caption = "Copy From Broker PO";

                            #region AP Invoice Link
                            oItem = oForm.Items.Item("85");
                            oNewItem = oForm.Items.Add("lblPL", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left + oItem.Width + 20;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblPL").Specific)).Caption = "Packing List No";
                            oNewItem.LinkTo = "85";

                            oItem = oForm.Items.Item("lblPL");
                            oNewItem = oForm.Items.Add("txtPL", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oNewItem.Left = oItem.Left + oItem.Width + 5;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblPL";
                            ((SAPbouiCOM.EditText)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_PackList");
                            oNewItem.Enabled = false;
                            #endregion

                            #region add form matrix setting


                            oItem = oForm.Items.Item("54");
                            oNewItem = oForm.Items.Add("lblFSett", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oNewItem.Left = oItem.Left+oItem.Width+5;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top ;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "54";
                            ((SAPbouiCOM.StaticText)(oForm.Items.Item("lblFSett").Specific)).Caption = "Form Setting";

                            oItem = oForm.Items.Item("lblFSett");
                            oNewItem = oForm.Items.Add("cmbFSett", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX);
                            oNewItem.Left = oItem.Left + oItem.Width + 5;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Top = oItem.Top ;
                            oNewItem.Height = oItem.Height;
                            oNewItem.LinkTo = "lblFSett";
                            ((SAPbouiCOM.ComboBox)oNewItem.Specific).DataBind.SetBound(true, Tablename, "U_FormSet");
                            oNewItem.Enabled = true;

                            oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                            oCombo = oForm.Items.Item("cmbFSett").Specific;
                            SAPbobsCOM.Recordset oRS_Process = null;
                            oRS_Process = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            string strSQL = null;
                            strSQL = "select Name from [@FormSet] where U_Type='" + pVal.FormTypeEx + "'";
                            oRS_Process.DoQuery(strSQL);
                            //strSeries = "";
                            if (oRS_Process.RecordCount > 0)
                            {
                                for (int i = 0; i < oRS_Process.RecordCount; i++)
                                {
                                    oCombo.ValidValues.Add(oRS_Process.Fields.Item("Name").Value.ToString(), oRS_Process.Fields.Item("Name").Value.ToString());
                                    oRS_Process.MoveNext();
                                }

                                if (oRS_Process.RecordCount == 1)
                                {
                                    try
                                    {
                                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);

                                    }
                                    catch { }
                                }

                            }
                            #endregion

                        
                        }
                    }
                    #endregion

                    #region Open Stock Transfer from PI
                    if (pVal.FormTypeEx == "143" && pVal.ItemUID == "txtST" && pVal.BeforeAction == false && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        string ST = ((SAPbouiCOM.EditText)oForm.Items.Item("txtST").Specific).Value.ToString();
                        if (ST != "")
                        {
                            Packing.SBO_Application.ActivateMenuItem("3080");
                            xForm = Packing.SBO_Application.Forms.ActiveForm;//GetForm("940", 1)
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            ((SAPbouiCOM.ComboBox)xForm.Items.Item("40").Specific).Select(oDal.ExSelect("Select Series from OWTR where Docentry='" + ST + "'", ""), SAPbouiCOM.BoSearchKey.psk_ByValue);
                            ((SAPbouiCOM.EditText)xForm.Items.Item("11").Specific).Value = oDal.ExSelect("Select DocNum from OWTR where Docentry='" + ST + "'", "");
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }
                    }
                    #endregion

                    #region Open Copy From PO
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.FormTypeEx == "143" && pVal.ItemUID == "btnCopy" && pVal.BeforeAction == false)
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value.ToString();
                        string dt = ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value.ToString();
                        string InvType = ((SAPbouiCOM.ComboBox)oForm.Items.Item("3").Specific).Selected.Value.ToString();
                        string PackNo = ((SAPbouiCOM.EditText)oForm.Items.Item("txtPL").Specific).Value.ToString();

                        if (cardcode == "")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please select vendor First", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                        else if (InvType == "S")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please select Item as Item/Service Type", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                        else if (PackNo != "")
                        {
                            LoadFromXML("Ready");
                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            xForm.Freeze(true);
                            xForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                            ((SAPbouiCOM.EditText)xForm.Items.Item("3").Specific).Value = PackNo;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            xForm.Freeze(false);
                        }
                        else
                        {
                            LoadFromXML("CFPO");
                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            ((SAPbouiCOM.EditText)xForm.Items.Item("10").Specific).Value = dt;


                            Packing.ParentForm_CFPO = pVal.FormTypeEx;
                            Packing.ParentCount_CFPO = pVal.FormTypeCount;

                            oMatrix = xForm.Items.Item("2").Specific;

                            //string Sql = "select 'N' chk,T0.CardCode,T0.CardName,T0.DocEntry,T0.DocNum,T1.LineNum,T1.ItemCode,T1.Dscription,T1.Quantity [OpenQty],isnull(T1.U_Bale,0) U_Bale,isnull(T1.U_Pcs,0) U_Pcs,isnull(T1.U_Yard,0) U_Yard, " +
                            //            " isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed QTY], " +
                            //            " isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed Bale], " +
                            //            " isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed PCS], " +
                            //            " isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed Yard], " +
                            //            " (T1.Quantity -isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenMtr] " +
                            //            " ,(isnull(T1.U_Bale,0)-isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenBale] " +
                            //            " ,(isnull(T1.U_Pcs,0)-isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenPcs] " +
                            //            " ,(isnull(T1.U_Yard,0)-isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenYard] " +
                            //            " from OPOR [T0] inner join [POR1] [T1] on T0.DocEntry=T1.DocEntry " +
                            //            " inner join OCRD [T2] on T0.CardCode=T2.CardCode " +
                            //            " where T0.DocStatus='O' and T1.LineStatus='O' and T0.DocDate<='" + dt + "' " +
                            //            " and  " +
                            //             " ((T1.Quantity -isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) >0 " +
                            //             " or (isnull(T1.U_Bale,0)-isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0))>0  " +
                            //             " or	(isnull(T1.U_Pcs,0)-isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) >0 " +
                            //             "	 or (isnull(T1.U_Yard,0)-isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) >0) "; //and T2.GroupCode='103'


                            string Sql = "exec sp_GetBrokerPO '" + dt + "','',''";

                            SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            oRset.DoQuery(Sql);
                            oMatrix.Clear();


                            xForm.DataSources.DataTables.Add("PO");
                            xForm.DataSources.DataTables.Item("PO").Clear();

                            xForm.DataSources.DataTables.Item("PO").ExecuteQuery(Sql);

                            oMatrix.Columns.Item("V_8").DataBind.Bind("PO", "chk");
                            oMatrix.Columns.Item("V_6").DataBind.Bind("PO", "CardName");
                            oMatrix.Columns.Item("V_5").DataBind.Bind("PO", "Dscription");
                            oMatrix.Columns.Item("V_4").DataBind.Bind("PO", "OpenMtr");
                            oMatrix.Columns.Item("V_10").DataBind.Bind("PO", "OpenBale");
                            oMatrix.Columns.Item("V_12").DataBind.Bind("PO", "OpenPcs");
                            oMatrix.Columns.Item("V_14").DataBind.Bind("PO", "OpenYard");
                            oMatrix.Columns.Item("V_3").DataBind.Bind("PO", "DocEntry");
                            oMatrix.Columns.Item("V_2").DataBind.Bind("PO", "DocNum");
                            oMatrix.Columns.Item("V_1").DataBind.Bind("PO", "LineNum");
                            oMatrix.Columns.Item("V_0").DataBind.Bind("PO", "DocEntry");

                            oMatrix.LoadFromDataSource();

                            //            ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", i)).Checked = false;
                            //            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).Value = oRset.Fields.Item("CardCode").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value = oRset.Fields.Item("CardName").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value = oRset.Fields.Item("Dscription").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value = oRset.Fields.Item("OpenMtr").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).Value = oRset.Fields.Item("OpenBale").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", i)).Value = oRset.Fields.Item("OpenPcs").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", i)).Value = oRset.Fields.Item("OpenYard").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", i)).Value = oRset.Fields.Item("DocNum").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();





                            //xForm.Items.Item("4").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            //if (oRset.RecordCount > 0)
                            //{
                            //    try
                            //    {
                            //        oForm.Freeze(true);
                            //        for (int i = 1; i <= oRset.RecordCount; i++)
                            //        {
                            //            oMatrix.AddRow(1, (i - 1));
                            //            ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", i)).Checked = false;
                            //            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).Value = oRset.Fields.Item("CardCode").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value = oRset.Fields.Item("CardName").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value = oRset.Fields.Item("Dscription").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value = oRset.Fields.Item("OpenMtr").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).Value = oRset.Fields.Item("OpenBale").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", i)).Value = oRset.Fields.Item("OpenPcs").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", i)).Value = oRset.Fields.Item("OpenYard").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", i)).Value = oRset.Fields.Item("DocNum").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                            //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();


                            //            oRset.MoveNext();
                            //        }
                            //        oForm.Freeze(false);
                            //    }
                            //    catch { oForm.Freeze(false); }
                            //}

                        }


                    }
                    #endregion

                    #region Copy from Receipt for Service Bill              btnRec
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.FormTypeEx == "143" && pVal.ItemUID == "btnRec" && pVal.BeforeAction == false)
                    {
                        oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value.ToString();
                        string dt = ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value.ToString();
                        string InvType = ((SAPbouiCOM.ComboBox)oForm.Items.Item("3").Specific).Selected.Value.ToString();

                        if (cardcode == "")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please select vendor First", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                        else if (InvType == "I")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please select Service as Item/Service Type", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                        else
                        {
                            LoadFromXML("ServiceItem");
                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            //((SAPbouiCOM.EditText)xForm.Items.Item("10").Specific).Value = dt;

                            Packing.ParentCount_ServiceItem = pVal.FormTypeCount;

                            oMatrix = xForm.Items.Item("matRec").Specific;

                            string Sql = "select Docentry,Docnum,convert(varchar(20), Docdate,103) Docdate from OIGN where Docentry in " +
                                         " (select DocEntry from IGN1 where whscode=(select U_whse from OCRD where cardcode='" + cardcode + "') and (IGN1.Quantity-isnull((select sum(PCH1.U_SQTY) from PCH1 where PCH1.U_RecDe=IGN1.Docentry and PCH1.U_RecLine=IGN1.Linenum),0))>0)  "; //and T2.GroupCode='103'
                            SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            oRset.DoQuery(Sql);
                            oMatrix.Clear();


                            if (oRset.RecordCount > 0)
                            {
                                try
                                {
                                    oForm.Freeze(true);
                                    for (int i = 1; i <= oRset.RecordCount; i++)
                                    {
                                        oMatrix.AddRow(1, (i - 1));
                                        //((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", i)).Checked = false;
                                        //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).Value = oRset.Fields.Item("CardCode").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value = oRset.Fields.Item("Docentry").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value = oRset.Fields.Item("Docnum").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).String = oRset.Fields.Item("Docdate").Value.ToString();


                                        oRset.MoveNext();
                                    }
                                    oForm.Freeze(false);
                                }
                                catch { oForm.Freeze(false); }
                            }

                        }


                    }

                    #endregion

                    #region Calculate Rate on PO & PI
                    if ((pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS || pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS) && pVal.BeforeAction == false)
                    {
                        if (pVal.ItemUID == "38" && (((pVal.ColUID == "U_Pcs" || pVal.ColUID == "U_Bale" || pVal.ColUID == "U_Yard" || pVal.ColUID == "U_SRate" || pVal.ColUID == "11" || pVal.ColUID == "U_RateBaseOn") && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS))) //|| (pVal.ColUID == "U_RateBaseOn" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)   && pVal.ItemChanged==true
                        {
                            oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                            oMatrix = oForm.Items.Item("38").Specific;
                            oCombo = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_RateBaseOn", pVal.Row));
                            string Piece = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", pVal.Row)).Value.ToString();
                            string Bale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", pVal.Row)).Value.ToString();
                            string Yard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", pVal.Row)).Value.ToString();
                            string SRate = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRate", pVal.Row)).Value.ToString();
                            string Qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", pVal.Row)).Value.ToString();
                            string Rate;
                            string linetotal = "0";
                            string RateBaseOn = oCombo.Selected.Value.ToString();
                            if ((RateBaseOn == "Mtr" || RateBaseOn == "Kgs") && Convert.ToDouble(SRate) > 0)
                            {
                                string rt = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).Value.ToString();
                                if (rt.Contains("INR "))
                                    rt = rt.Replace("INR ", "");
                                else if (rt == "")
                                    rt = "0";
                                if (Convert.ToDouble(rt) != Convert.ToDouble(SRate))
                                {

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).Value = SRate;
                                }
                            }
                            else
                            {
                                if (RateBaseOn == "Bale")
                                {
                                    linetotal = (Convert.ToDouble(Bale) * Convert.ToDouble(SRate)).ToString();
                                }
                                else if (RateBaseOn == "Pcs")
                                {
                                    linetotal = (Convert.ToDouble(Piece) * Convert.ToDouble(SRate)).ToString();
                                }
                                else if (RateBaseOn == "Yard")
                                {
                                    linetotal = (Convert.ToDouble(Yard) * Convert.ToDouble(SRate)).ToString();
                                }

                                if (Convert.ToDouble(Qty) > 0)
                                {
                                    oForm.Freeze(true);
                                    Rate = (Convert.ToDouble(linetotal) / Convert.ToDouble(Qty)).ToString();
                                    string z = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).Value.ToString();
                                    if (z.Contains("INR "))
                                        z = z.Replace("INR ", "");
                                    else if (z == "")
                                        z = "0";

                                    if (Convert.ToDouble(z) != Convert.ToDouble(Rate))
                                    {

                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).Value = Rate;
                                    }

                                    string line = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("21", pVal.Row)).Value.ToString();
                                    if (line != linetotal && line != "")
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("21", pVal.Row)).Value = linetotal;

                                    oForm.Freeze(false);
                                }
                            }
                        }
                    }
                    #endregion

                    #region Copy AP Invoice data to Stock Transfer
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT && pVal.ItemUID == "10000329" && pVal.FormTypeEx == "143" && pVal.BeforeAction == false)
                    {
                        //oForm = SBO_Application.Forms.GetForm("143", pVal.FormTypeCount);

                        //oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                        string ST = "";//((SAPbouiCOM.EditText)oForm.Items.Item("txtST").Specific).Value.ToString();

                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("10000329").Specific;
                        if (oCombo.Selected.Value == "Issue To JobWorker")
                        {
                            oMatrix = oForm.Items.Item("38").Specific;
                            int selrow;
                            bool selection_required = false;
                            if (oMatrix.VisualRowCount == 1)
                            {
                                ST = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ITEntry", 1)).Value.ToString();
                                selrow = 1;
                                selection_required = true;

                            }
                            else
                            {
                                selrow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                                if (selrow < 0)
                                {
                                    Packing.SBO_Application.StatusBar.SetText("Please select Row to Transfer !!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    ST = "Row Not Select";
                                }
                                else if (oMatrix.VisualRowCount > 1 && selrow >= 0)
                                {
                                    selection_required = true;
                                    ST = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ITEntry", selrow)).Value.ToString();
                                }
                            }


                            if (ST == "Row Not Select")
                            { }

                            else if (ST != "")
                            {
                                Packing.SBO_Application.StatusBar.SetText("Issue To Jobworker already done!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                            else
                            {
                                if (selection_required)
                                {
                                    string ser = ((SAPbouiCOM.ComboBox)oForm.Items.Item("88").Specific).Selected.Value.ToString();
                                    string docnum = ((SAPbouiCOM.EditText)oForm.Items.Item("8").Specific).Value.ToString();
                                    string docentry = oDal.ExSelect("select DocEntry From OPCH where Series='" + ser + "' and DocNum='" + docnum + "'", "");
                                    string linenum = oDal.ExSelect("select Linenum from PCH1 where Docentry='" + docentry + "' and Visorder='" + (selrow - 1).ToString() + "'", "");

                                    string qry = "select T0.Docentry,T1.U_JobWrkr,T1.U_LRNO,REPLACE( convert(varchar(20), T1.U_LRDT,104),'.','') U_LRDT,T1.U_PTYCHALL,T1.U_TRANSPRT,(select OCRD.U_whse from OCRD where OCRD.Cardcode=T1.U_JobWrkr) [Whse],T1.WhsCode "
                                                    + " from OPCH [T0] inner join PCH1 [T1] on T0.DocEntry=T1.DocEntry "
                                        //+ " inner join PCH1 [T1] on T0.Docentry=T1.Docentry "
                                                    + " inner join OIBT [T2] on T0.DocEntry=T2.BaseEntry and T0.ObjType=T2.BaseType and T2.BaseLinNum=T1.LineNum  "
                                                    + " where T0.DocEntry='" + docentry + "' and T1.LineNum=" + linenum + ""; //(selrow - 1).ToString() 

                                    oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                    oRs.DoQuery(qry);
                                    if (oRs.RecordCount > 0)
                                    {
                                        Packing.SBO_Application.ActivateMenuItem("3080");
                                        xForm = Packing.SBO_Application.Forms.ActiveForm;//GetForm("940", 1);

                                        xForm.Items.Item("3").Enabled = false;
                                        xForm.Items.Item("7").Enabled = false;

                                        string Whse = oRs.Fields.Item("Whse").Value.ToString();
                                        if (Whse != "")
                                            ((SAPbouiCOM.EditText)xForm.Items.Item("1470000101").Specific).Value = Whse;

                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtAPI").Specific).Value = oRs.Fields.Item("Docentry").Value.ToString();
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtTrans").Specific).Value = oRs.Fields.Item("U_TRANSPRT").Value.ToString();
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtLR").Specific).Value = oRs.Fields.Item("U_LRNO").Value.ToString();
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtLRDt").Specific).String = oRs.Fields.Item("U_LRDT").Value.ToString();
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtPCNO").Specific).Value = oRs.Fields.Item("U_PTYCHALL").Value.ToString();
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("txtAPIL").Specific).Value = linenum;
                                        ((SAPbouiCOM.EditText)xForm.Items.Item("9").Specific).Value = "";




                                    }

                                }
                            }
                        }
                        else if (oCombo.Selected.Value.Contains("Credit"))
                        {
                            string Docentry = oDal.ExSelect("Select Docentry from OPCH where Series='" + Packing.OPCH_Series + "' and Docnum='" + Packing.OPCH_DocNum + "'", "");
                            string qry = "select T0.LineNum,T1.Quantity from PCH1 [T0] inner join OIBT [T1] on T0.DocEntry=T1.BaseEntry and T0.ObjType=T1.BaseType and T0.LineNum=T1.BaseLinNum and T0.WhsCode=T1.WhsCode "
                                        + " where T0.DocEntry=" + Docentry + " order by T0.LineNum";
                            oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                            oRs.DoQuery(qry);
                            if (oRs.RecordCount > 0)
                            {
                                oForm = Packing.SBO_Application.Forms.GetForm("181", pVal.FormTypeCount);
                                oMatrix = oForm.Items.Item("38").Specific;
                                int[] linenum = new int[1000];
                                int linecnt = 0;
                                for (int i = 1; i <= oRs.RecordCount; i++)
                                {
                                    string qty = oRs.Fields.Item("Quantity").Value.ToString();

                                    if (Convert.ToDouble(qty) == 0)
                                    {
                                        linenum[linecnt] = i;
                                        linecnt = linecnt + 1;
                                    }

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i)).Value = (Convert.ToDouble(qty) == 0 ? "1" : qty);

                                    oRs.MoveNext();
                                }

                                while (linecnt > 0)
                                {
                                    oMatrix.DeleteRow(linenum[linecnt - 1]);
                                    linecnt = linecnt - 1;
                                }
                            }
                        }

                    }

                    #endregion


                    #region Open Copy From PO
                    //if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.FormTypeEx == "143" && pVal.ItemUID == "btnCopy" && pVal.BeforeAction == false)
                    //{
                    //    oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                    //    string cardcode = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value.ToString();
                    //    string dt = ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value.ToString();

                    //    if (cardcode != "")
                    //    {
                    //        LoadFromXML("CFPO");
                    //        xForm = Packing.SBO_Application.Forms.ActiveForm;
                    //        ((SAPbouiCOM.EditText)xForm.Items.Item("10").Specific).Value = dt;

                    //        Packing.ParentCount_CFPO = pVal.FormTypeCount;

                    //        oMatrix = xForm.Items.Item("2").Specific;

                    //        string Sql = "select T0.CardCode,T0.CardName,T0.DocEntry,T0.DocNum,T1.LineNum,T1.ItemCode,T1.Dscription,T1.Quantity [OpenQty],isnull(T1.U_Bale,0) U_Bale,isnull(T1.U_Pcs,0) U_Pcs,isnull(T1.U_Yard,0) U_Yard, " +
                    //                    " isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed QTY], " +
                    //                    " isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed Bale], " +
                    //                    " isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed PCS], " +
                    //                    " isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed Yard], " +
                    //                    " (T1.Quantity -isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenMtr] " +
                    //                    " ,(isnull(T1.U_Bale,0)-isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenBale] " +
                    //                    " ,(isnull(T1.U_Pcs,0)-isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenPcs] " +
                    //                    " ,(isnull(T1.U_Yard,0)-isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenYard] " +
                    //                    " from OPOR [T0] inner join [POR1] [T1] on T0.DocEntry=T1.DocEntry " +
                    //                    " inner join OCRD [T2] on T0.CardCode=T2.CardCode " +
                    //                    " where T0.DocStatus='O' and T1.LineStatus='O' and T0.DocDate<='" + dt + "'"; //and T2.GroupCode='103'
                    //        SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    //        oRset.DoQuery(Sql);
                    //        oMatrix.Clear();


                    //        //xForm.Items.Item("4").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                    //        if (oRset.RecordCount > 0)
                    //        {
                    //            try
                    //            {
                    //                oForm.Freeze(true);
                    //                for (int i = 1; i <= oRset.RecordCount; i++)
                    //                {
                    //                    oMatrix.AddRow(1, (i - 1));
                    //                    ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", i)).Checked = false;
                    //                    //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).Value = oRset.Fields.Item("CardCode").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value = oRset.Fields.Item("CardName").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value = oRset.Fields.Item("Dscription").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value = oRset.Fields.Item("OpenMtr").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).Value = oRset.Fields.Item("OpenBale").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", i)).Value = oRset.Fields.Item("OpenPcs").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", i)).Value = oRset.Fields.Item("OpenYard").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", i)).Value = oRset.Fields.Item("DocNum").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                    //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();


                    //                    oRset.MoveNext();
                    //                }
                    //                oForm.Freeze(false);
                    //            }
                    //            catch { oForm.Freeze(false); }
                    //        }

                    //    }
                    //    else
                    //    {
                    //        Packing.SBO_Application.StatusBar.SetText("Please select vendor First", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    //    }

                    //}
                    #endregion

                    #region choose from list for Goods Receipt Beore action False
                    if (pVal.ItemUID == "txtRec" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.BeforeAction == false)
                    {
                        //oForm = Packing.SBO_Application.Forms.GetForm("720", pVal.FormTypeCount);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("DocNum", 0).ToString();
                        //val2 = oDataTable.GetValue("DocDate", 0).ToString("yyyyMMdd");
                        val3 = oDataTable.GetValue("DocEntry", 0).ToString();
                        //U_DocDate.Value = ToDate.ToString("yyyyMMdd")
                        oForm = Packing.SBO_Application.Forms.GetForm("143", pVal.FormTypeCount);
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("txtRec").Specific;
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                        oForm = Packing.SBO_Application.Forms.GetForm("143", pVal.FormTypeCount);
                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("txtRecDE").Specific;
                        try
                        {
                            oEdit.Value = val3;
                        }
                        catch { }

                    }
                    #endregion

                    #region Calculate Unit price for Service Bill on Lost focus of Service Rate or Service QTY
                    if (pVal.ItemUID == "39" && (pVal.ColUID == "U_SerRATE" || pVal.ColUID == "U_SQTY") && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
                    {
                        oMatrix = oForm.Items.Item("39").Specific;
                        string srate = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SerRATE", pVal.Row)).Value.ToString();
                        string sqty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SQTY", pVal.Row)).Value.ToString();
                        double val = Convert.ToDouble(srate) * Convert.ToDouble(sqty);
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("5", pVal.Row)).Value = val.ToString();

                    }
                    #endregion

                }
                #endregion


                return true;
            }
            catch { return false; }
        }

        public void LoadFromXML(String FormName)
        {
            string sXmlFileName;
            string QStr = null;
            string DocEnt = null;
            int Docentry = 0;

            //SAPbobsCOM.Recordset InsertRec = null;
            //InsertRec = (SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset));

            sXmlFileName = Application.StartupPath.ToString();
            sXmlFileName = sXmlFileName + "\\" + FormName + ".srf";
            XmlDocument oXmlDoc = new XmlDocument();
            oXmlDoc.Load(sXmlFileName);
            string sXML = oXmlDoc.InnerXml.ToString();
            Packing.SBO_Application.LoadBatchActions(ref sXML);
            oForm = Packing.SBO_Application.Forms.ActiveForm;


            #region PackingCredit
            if (FormName == "PackingCredit")
            {
                oForm = Packing.SBO_Application.Forms.Item("PackingCredit");
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;

                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);
                //oForm.EnableMenu("1292", true);
                //oForm.EnableMenu("1283", false);
                //oForm.EnableMenu("1287", true);
                //oForm.EnableMenu("1286", false);
                //oForm.EnableMenu("1284", false);

                oForm.DataBrowser.BrowseBy = "DocEntry";
                //AddChooseFromList();

                string NowDate = Packing.oCompany.GetCompanyDate().ToString("yyyyMMdd").Replace("/", "-");
                oForm.Items.Item("Item_15").Specific.value = NowDate;
                oForm.Items.Item("Item_15").Enabled = false;

                string Sql = "SELECT (CASE WHEN (ISNULL(MAX(CONVERT(NUMERIC,DocEntry) ),0))=0 THEN 1 ELSE (MAX(CONVERT(NUMERIC,DocEntry)) + 1) END) AS CODE FROM [dbo].[@OPCF]";
                SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                oRset.DoQuery(Sql);

                if (oRset.RecordCount > 0)
                {
                    oForm.Items.Item("DocEntry").Specific.value = Convert.ToString(oRset.Fields.Item("CODE").Value);
                    oForm.Items.Item("Item_13").Specific.value = Convert.ToString(oRset.Fields.Item("CODE").Value);
                }
                // oForm.Items.Item("Item_17").Specific.value = NowDate;
                //oForm.Items.Item("Item_17").Enabled = false;
            }
            #endregion

            #region Program Sheet
            if (FormName == "ProgramSheet")
            {
                oForm = Packing.SBO_Application.Forms.Item("OPST");
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;

                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);

                oForm.DataBrowser.BrowseBy = "DocEntry";
                //AddChooseFromList();

                oForm.EnableMenu("1292", true);
                oForm.EnableMenu("1293", true);

                //ProgSheetformLoad();

            }
            #endregion

        }
    }
}

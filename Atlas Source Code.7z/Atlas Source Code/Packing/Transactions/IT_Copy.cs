﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Packing.Transactions
{
    class IT_Copy
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Matrix oMatrix2;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                if (pVal.BeforeAction == true)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE && pVal.ItemUID == "matRecDet" && (pVal.ColUID == "V_4" || pVal.ColUID == "V_2" || pVal.ColUID == "V_0"))
                    {
                        oMatrix = oForm.Items.Item(pVal.ItemUID).Specific;
                        string sel = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value.ToString();
                        if (Convert.ToDouble(sel) > 0)
                        {
                            string pend = "";
                            if (pVal.ColUID == "V_4")
                                pend = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row)).Value.ToString();
                            else if (pVal.ColUID == "V_2")
                                pend = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", pVal.Row)).Value.ToString();
                            else if (pVal.ColUID == "V_0")
                                pend = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", pVal.Row)).Value.ToString();

                            if (Convert.ToDouble(sel) > Convert.ToDouble(pend))
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value = pend;

                        }
                    }
                }
                else if (pVal.BeforeAction == false)
                {
                    #region Choose from list Warehouse
                    if (pVal.ItemUID == "8" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;


                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;


                        val1 = oDataTable.GetValue("WhsCode", 0).ToString();
                        val2 = oDataTable.GetValue("WhsName", 0).ToString();

                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("8").Specific;
                        oEdit1 = (SAPbouiCOM.EditText)oForm.Items.Item("9").Specific;

                        bool allow = false;
                        if (Packing.whse == "")
                        {

                            allow = true;
                        }
                        else if (Packing.whse == val1)
                        {
                            allow = true;
                        }
                        else
                        {
                            allow = false;
                            Packing.SBO_Application.StatusBar.SetText("More thant 1 Warehouse selection not allowed...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            try
                            {
                                oEdit.Value = Packing.whse;
                            }
                            catch { }
                        }

                        if (allow)
                        {
                            try
                            {
                                oEdit.Value = val1;

                            }
                            catch { }

                            try
                            {
                                oEdit1.Value = val2;

                            }
                            catch { }

                            fill_Document_header_matrix(val1);
                        }
                    }
                    #endregion

                    #region Combo Select
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT && pVal.ItemUID == "6")
                    {
                        oCombo = oForm.Items.Item("6").Specific;
                        if (oCombo.Selected != null)
                        {
                            string sel = oCombo.Selected.Value.ToString();
                            if (sel == "18" || sel == "20")
                            {
                                oEdit = oForm.Items.Item("8").Specific;
                                oEdit.Value = "01";

                                //fill_Document_header_matrix("01");
                            }
                            else
                            {
                                oEdit = oForm.Items.Item("8").Specific;
                                oEdit.Value = "";
                            }

                        }
                    }

                    #endregion

                    #region Get Receipt Details on Click Matrix Receipt
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "matRec" && pVal.ColUID == "V_-1")
                    {
                        //oForm = Packing.SBO_Application.Forms.Item("ServiceItem");
                        oMatrix = oForm.Items.Item("matRec").Specific;
                        int selrow = pVal.Row;
                        string sel = "";
                        oCombo = oForm.Items.Item("6").Specific;
                        if (oCombo.Selected != null)
                        {
                            sel = oCombo.Selected.Value.ToString();
                        }


                        if (selrow >= 0 && sel != "")
                        {
                            string recDE = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", selrow)).Value.ToString();
                            string dbSource_String = sel + "_" + recDE;
                            oMatrix1 = oForm.Items.Item("matRecDet").Specific;
                            oMatrix1.FlushToDataSource();
                            try
                            {
                                oForm.DataSources.DataTables.Add(dbSource_String);
                                oForm.DataSources.DataTables.Item(dbSource_String).Clear();

                                string sSQL = "";
                                if (sel == "18")
                                {
                                    sSQL = "exec sp_get_IT_PurchaseInvoice_Details " + recDE + "";
                                }
                                else if (sel == "20")
                                {
                                    sSQL = "exec sp_get_IT_GRPO_Details " + recDE + "";
                                }
                                else if (sel == "59")
                                {
                                    sSQL = "exec sp_get_IT_GR_Details " + recDE + "";
                                }
                                oForm.DataSources.DataTables.Item(dbSource_String).ExecuteQuery(sSQL);
                            }
                            catch { }
                            //oMatrix = oform.Items.Item("mtx_0").Specific
                            oMatrix1.Columns.Item("V_9").DataBind.Bind(dbSource_String, "chk");
                            oMatrix1.Columns.Item("V_-1").DataBind.Bind(dbSource_String, "LineNum");
                            oMatrix1.Columns.Item("V_7").DataBind.Bind(dbSource_String, "ItemCode");
                            oMatrix1.Columns.Item("V_6").DataBind.Bind(dbSource_String, "Dscription");
                            oMatrix1.Columns.Item("V_5").DataBind.Bind(dbSource_String, "Quantity");

                            oMatrix1.Columns.Item("V_4").DataBind.Bind(dbSource_String, "SelMtr");
                            oMatrix1.Columns.Item("V_3").DataBind.Bind(dbSource_String, "PendingPcs");
                            oMatrix1.Columns.Item("V_2").DataBind.Bind(dbSource_String, "SelPcs");
                            oMatrix1.Columns.Item("V_1").DataBind.Bind(dbSource_String, "PendingBales");
                            oMatrix1.Columns.Item("V_0").DataBind.Bind(dbSource_String, "SelBales");

                            oMatrix1.Columns.Item("V_12").DataBind.Bind(dbSource_String, "U_BALENOS");
                            oMatrix1.Columns.Item("V_11").DataBind.Bind(dbSource_String, "U_STBALE");
                            oMatrix1.Columns.Item("V_10").DataBind.Bind(dbSource_String, "U_ENBALE");
                            oMatrix1.Columns.Item("V_8").DataBind.Bind(dbSource_String, "U_LRNO");
                            oMatrix1.Columns.Item("V_13").DataBind.Bind(dbSource_String, "U_LRDT");
                            oMatrix1.Columns.Item("V_14").DataBind.Bind(dbSource_String, "Batchnum");

                            oMatrix1.Columns.Item("V_17").DataBind.Bind(dbSource_String, "U_TRANSPRT");
                            oMatrix1.Columns.Item("V_16").DataBind.Bind(dbSource_String, "U_PrgShtDN");
                            oMatrix1.Columns.Item("V_15").DataBind.Bind(dbSource_String, "U_PrgSer");

                            //oMatrix.Columns.Item("col_3").DataBind.Bind("X", "ItemName")


                            oMatrix1.LoadFromDataSource();


                        }
                    }
                    #endregion

                    #region Check Uncheck Matrec
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "matRec" && pVal.ColUID == "V_0")
                    {
                        oMatrix = oForm.Items.Item("matRec").Specific;
                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row));
                        if (oCheckBox.Checked)
                        {
                            oMatrix.Columns.Item("V_-1").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            oMatrix1 = oForm.Items.Item("matRecDet").Specific;
                            bool check_already_Checked = false;
                            for (int i = 1; i <= oMatrix1.VisualRowCount; i++)
                            {
                                oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix1.GetCellSpecific("V_9", i));
                                if (oCheckBox.Checked == true)
                                {
                                    check_already_Checked = true;
                                }
                            }

                            if (check_already_Checked == false)
                            {
                                for (int i = 1; i <= oMatrix1.VisualRowCount; i++)
                                {
                                    oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix1.GetCellSpecific("V_9", i));
                                    oCheckBox.Checked = true;
                                }
                            }
                        }
                        else
                        {
                            oMatrix.Columns.Item("V_-1").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            oMatrix1 = oForm.Items.Item("matRecDet").Specific;
                            for (int i = 1; i <= oMatrix1.VisualRowCount; i++)
                            {
                                oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix1.GetCellSpecific("V_9", i));
                                oCheckBox.Checked = false;
                            }
                        }
                    }

                    #endregion


                    #region Check Uncheck Details
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "matRecDet" && pVal.ColUID == "V_9")
                    {
                        oMatrix = oForm.Items.Item("matRecDet").Specific;
                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_9", pVal.Row));
                        if (oCheckBox.Checked)
                        {
                            Packing.whse = ((SAPbouiCOM.EditText)oForm.Items.Item("8").Specific).Value.ToString();
                            #region Check Parent Item Row
                            try
                            {
                                oMatrix1 = oForm.Items.Item("matRec").Specific;
                                int selrow = oMatrix1.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                                oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix1.GetCellSpecific("V_0", selrow));
                                if (!oCheckBox.Checked)
                                {
                                    oCheckBox.Checked = true;
                                }
                            }
                            catch { }
                            #endregion

                            string pend_Mtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row)).Value.ToString();
                            string Sel_Mtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).Value.ToString();
                            string pend_Bale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", pVal.Row)).Value.ToString();
                            string sel_Bale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", pVal.Row)).Value.ToString();
                            string pend_Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", pVal.Row)).Value.ToString();
                            string sel_Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row)).Value.ToString();

                            oForm.Freeze(true);
                            if (Convert.ToDouble(Sel_Mtr) == 0 && Convert.ToDouble(sel_Bale) == 0 && Convert.ToDouble(sel_Pcs) == 0 && Convert.ToDouble(Sel_Mtr) != Convert.ToDouble(pend_Mtr))
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).Value = pend_Mtr;
                            if (Convert.ToDouble(Sel_Mtr) == 0 && Convert.ToDouble(sel_Bale) == 0 && Convert.ToDouble(sel_Pcs) == 0 && Convert.ToDouble(sel_Bale) != Convert.ToDouble(pend_Bale))
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", pVal.Row)).Value = pend_Bale;
                            if (Convert.ToDouble(Sel_Mtr) == 0 && Convert.ToDouble(sel_Bale) == 0 && Convert.ToDouble(sel_Pcs) == 0 && Convert.ToDouble(sel_Pcs) != Convert.ToDouble(pend_Pcs))
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row)).Value = pend_Pcs;
                            oForm.Freeze(false);
                        }
                        else
                        {
                            #region UnCheck Parent Item Row
                            bool check_allunchecked = false;
                            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                            {
                                oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_9", i));
                                if (oCheckBox.Checked == true)
                                {
                                    check_allunchecked = true;
                                }
                            }

                            if (check_allunchecked == false)
                            {
                                oMatrix1 = oForm.Items.Item("matRec").Specific;
                                int selrow = oMatrix1.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                                oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix1.GetCellSpecific("V_0", selrow));
                                if (oCheckBox.Checked)
                                {
                                    oCheckBox.Checked = false;
                                }
                            }
                            #endregion

                            oForm.Freeze(true);
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).Value = "0";
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", pVal.Row)).Value = "0";
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row)).Value = "0";
                            oForm.Freeze(false);

                        }
                    }

                    #endregion

                    #region check Det row on change of Sel Mtr,bale,pcs
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "matRecDet" && (pVal.ColUID == "V_4" || pVal.ColUID == "V_2" || pVal.ColUID == "V_0"))
                    {
                        oMatrix = oForm.Items.Item(pVal.ItemUID).Specific;
                        string sel = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value.ToString();
                        if (Convert.ToDouble(sel) > 0)
                        {
                            string pend = "";
                            if (pVal.ColUID == "V_4")
                                pend = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row)).Value.ToString();
                            else if (pVal.ColUID == "V_2")
                                pend = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", pVal.Row)).Value.ToString();
                            else if (pVal.ColUID == "V_0")
                                pend = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", pVal.Row)).Value.ToString();

                            //if (Convert.ToDouble(sel) > Convert.ToDouble(pend))
                            //    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row)).Value = pend;

                            oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_9", pVal.Row));
                            if (oCheckBox.Checked == false)
                                oCheckBox.Checked = true;
                        }
                        else if (Convert.ToDouble(sel) == 0)
                        {
                            //string pend_Mtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", pVal.Row)).Value.ToString();
                            string Sel_Mtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).Value.ToString();
                            //string pend_Bale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", pVal.Row)).Value.ToString();
                            string sel_Bale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", pVal.Row)).Value.ToString();
                            //string pend_Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", pVal.Row)).Value.ToString();
                            string sel_Pcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row)).Value.ToString();

                            if (Convert.ToDouble(Sel_Mtr) == 0 && Convert.ToDouble(sel_Bale) == 0 && Convert.ToDouble(sel_Pcs) == 0)
                            {
                                oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_9", pVal.Row));
                                if (oCheckBox.Checked == true)
                                    oCheckBox.Checked = false;
                            }


                        }

                    }

                    #endregion

                    #region Copy to Inventory Transfer
                    if (pVal.ItemUID == "btnCpy" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        oMatrix1 = oForm.Items.Item("matRecDet").Specific;
                        oMatrix1.FlushToDataSource();
                        string whse = ((SAPbouiCOM.EditText)oForm.Items.Item("8").Specific).Value.ToString();

                        string[] Type = new string[5000];
                        string[] DE = new string[5000];
                        string[] Line = new string[5000];
                        string[] Item = new string[5000];
                        string[] Mtr = new string[5000];
                        string[] Pcs = new string[5000];
                        string[] Bale = new string[5000];
                        string[] Batch = new string[5000];
                        string[] Baleno = new string[5000];
                        string[] SBale = new string[5000];
                        string[] EBale = new string[5000];
                        string[] LRNo = new string[5000];
                        string[] LrDt = new string[5000];
                        string[] U_TRANSPRT = new string[5000];
                        string[] U_PrgShtDN = new string[5000];
                        string[] U_PrgSer = new string[5000];
                        //string[] QTY = new string[5000];
                        //string[] receiptDE = new string[5000];
                        int cnt = 0;


                        int DBSrcCount = oForm.DataSources.DataTables.Count;

                        for (int i = 0; i < DBSrcCount; i++)
                        {
                            SAPbouiCOM.DataTable dt = oForm.DataSources.DataTables.Item(i);
                            string dtname = dt.UniqueID.ToString();
                            if (dtname != "18" && dtname != "20" && dtname != "59")
                            {
                                for (int j = 0; j < dt.Rows.Count; j++)
                                {
                                    string chk = dt.GetValue("chk", j);
                                    if (chk == "Y")
                                    // ajay - get data from "copy for transfer" start
                                    {
                                        Type[cnt] = dtname.Substring(0, dtname.IndexOf("_"));
                                        DE[cnt] = dtname.Substring(dtname.IndexOf("_") + 1);
                                        Line[cnt] = (dt.GetValue("LineNum", j)).ToString();
                                        Item[cnt] = (dt.GetValue("ItemCode", j)).ToString();
                                        Mtr[cnt] = (dt.GetValue("SelMtr", j)).ToString();
                                        Pcs[cnt] = (dt.GetValue("SelPcs", j)).ToString();
                                        Bale[cnt] = (dt.GetValue("SelBales", j)).ToString();
                                        Batch[cnt] = (dt.GetValue("Batchnum", j)).ToString();
                                        Baleno[cnt] = (dt.GetValue("U_BALENOS", j)).ToString();
                                        SBale[cnt] = (dt.GetValue("U_STBALE", j)).ToString();
                                        EBale[cnt] = (dt.GetValue("U_ENBALE", j)).ToString();
                                        LRNo[cnt] = (dt.GetValue("U_LRNO", j)).ToString();
                                        LrDt[cnt] = (dt.GetValue("U_LRDT", j)).ToString();
                                        U_TRANSPRT[cnt] = (dt.GetValue("U_TRANSPRT", j)).ToString();
                                        U_PrgSer[cnt] = (dt.GetValue("U_PrgSer", j)).ToString();
                                        U_PrgShtDN[cnt] = (dt.GetValue("U_PrgShtDN", j)).ToString();

                                        cnt = cnt + 1;
                                    }

                                }
                            }
                        }
                        Packing.whse = "";
                        oForm.Close();

                        xForm = Packing.SBO_Application.Forms.GetForm("940", Packing.parentformcnt);
                        oMatrix = xForm.Items.Item("23").Specific;

                        ((SAPbouiCOM.EditText)xForm.Items.Item("18").Specific).Value = whse;

                        en_dis_able_matrix(true, oMatrix, xForm);
                        for (int i = 0; i < cnt; i++)
                        {
                            try
                            {
                                xForm.Freeze(true);
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i + 1)).Value = Item[i].ToString();

                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", i + 1)).Value = Type[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSEntry", i + 1)).Value = DE[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_POBSLine", i + 1)).Value = Line[i].ToString();
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", i + 1)).Value = Mtr[i].ToString();
                                // ajay - update data from "copy for transfter" to tabel line level
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", i + 1)).Value = Pcs[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", i + 1)).Value = Bale[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", i + 1)).Value = Batch[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BALENOS", i + 1)).Value = Baleno[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_STBALE", i + 1)).Value = SBale[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ENBALE", i + 1)).Value = EBale[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRNO", i + 1)).Value = LRNo[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TRANSPRT", i + 1)).Value = U_TRANSPRT[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgSer", i + 1)).Value = U_PrgSer[i].ToString();
                                }
                                catch { }

                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrgShtDN", i + 1)).Value = U_PrgShtDN[i].ToString();
                                }
                                catch { }
                                try
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRDT", i + 1)).String = LrDt[i].ToString().Substring(0, 10);
                                }
                                catch { }
                                xForm.Freeze(false);
                            }
                            catch { xForm.Freeze(false); }
                        }
                        en_dis_able_matrix(false, oMatrix, xForm);


                    }
                    #endregion


                }

                return true;
            }
            catch
            { return false; }
        }

        public void fill_Document_header_matrix(string whse)
        {
            string DocType = "";
            //string whse = ""; 
            oCombo = oForm.Items.Item("6").Specific;
            if (oCombo.Selected != null)
            {
                DocType = oCombo.Selected.Value.ToString();
            }

            //whse = ((SAPbouiCOM.EditText)oForm.Items.Item("6").Specific).Value.ToString();
            if (whse == "")
            {
                Packing.SBO_Application.StatusBar.SetText("Please select warehouse first", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            else if (DocType == "")
            {
                Packing.SBO_Application.StatusBar.SetText("Please select Document Type", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            else
            {
                oMatrix = oForm.Items.Item("matRec").Specific;
                oMatrix.FlushToDataSource();
                try
                {
                    oForm.DataSources.DataTables.Add(DocType);
                    oForm.DataSources.DataTables.Item(DocType).Clear();
                    string sSQL = "";
                    if (DocType == "18")
                    {
                        sSQL = "exec sp_get_IT_PurchaseInvoice '" + whse + "'";
                    }
                    else if (DocType == "20")
                    {
                        sSQL = "exec sp_get_IT_GRPO '" + whse + "'";
                    }
                    else if (DocType == "59")
                    {
                        sSQL = "exec sp_get_IT_GR '" + whse + "'";
                    }

                    oForm.DataSources.DataTables.Item(DocType).ExecuteQuery(sSQL);
                }
                catch { }

                oMatrix.Columns.Item("V_0").DataBind.Bind(DocType, "chk");
                oMatrix.Columns.Item("V_4").DataBind.Bind(DocType, "DocEntry");
                oMatrix.Columns.Item("V_5").DataBind.Bind(DocType, "DocNum");
                oMatrix.Columns.Item("V_3").DataBind.Bind(DocType, "DocDate");
                //oMatrix1.Columns.Item("V_5").DataBind.Bind(DocType, "Quantity");





                oMatrix.LoadFromDataSource();

                SAPbouiCOM.Column oColumn = (SAPbouiCOM.Column)oMatrix.Columns.Item("V_4");
                SAPbouiCOM.LinkedButton oLink = ((SAPbouiCOM.LinkedButton)(oColumn.ExtendedObject));
                oLink.LinkedObjectType = DocType;

                //oMatrix.Columns.Item("V_4").Type=SAPbouiCOM.BoFormItemTypes.
                //SAPbouiCOM.LinkedButton col = (SAPbouiCOM.LinkedButton)oMatrix.Columns.Item("V_4");
                //col.LinkedObjectType = DocType;
            }

        }


        public void en_dis_able_matrix(bool visible, SAPbouiCOM.Matrix mat, SAPbouiCOM.Form frm)
        {
            try
            {
                frm.Freeze(true);
                frm.Items.Item("41").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                mat.Columns.Item("1").Editable = visible;
                mat.Columns.Item("2").Editable = visible;
                mat.Columns.Item("U_BaseType").Editable = visible;
                mat.Columns.Item("U_POBSEntry").Editable = visible;
                mat.Columns.Item("U_POBSLine").Editable = visible;
                mat.Columns.Item("10").Editable = visible;
                mat.Columns.Item("U_Pcs").Editable = visible;
                mat.Columns.Item("U_Bale").Editable = visible;
                mat.Columns.Item("U_BatchNo").Editable = visible;
                mat.Columns.Item("U_BALENOS").Editable = visible;
                mat.Columns.Item("U_STBALE").Editable = visible;
                mat.Columns.Item("U_ENBALE").Editable = visible;
                mat.Columns.Item("U_LRNO").Editable = visible;
                mat.Columns.Item("U_TRANSPRT").Editable = visible;
                mat.Columns.Item("U_PrgSer").Editable = visible;
                mat.Columns.Item("U_PrgShtDN").Editable = visible;
                frm.Freeze(false);
            }
            catch
            {
                frm.Freeze(false);

            }

        }

    }
}

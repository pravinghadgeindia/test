﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using System.Xml;

namespace Packing.Transactions
{
    class OFD
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item("OFT");
                if (pVal.BeforeAction == true)
                {
                    if (pVal.ItemUID == "40" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                    {
                        //int res= Packing.SBO_Application.MessageBox("Do you really want to stop this batch? Once stopped batch can not be use in Lot Number Allocation.", 2, "Yes", "No", "");
                        //if (res == 1)
                        //{

                        //}
                        //else
                        //{
                        //    return false;
                        //}
                    }

                    if (pVal.ItemUID == "Item_71" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE)
                    {
                        string fullreportdt = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_71").Specific).Value.ToString();
                        string fivetakadt = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_32").Specific).Value.ToString();
                        string res= oDal.ExSelect("select case when convert(datetime, '"+fullreportdt+"')< convert(datetime, '"+fivetakadt+"') then 0 else 1 end", "");
                        if (res == "0")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Full Report Received Date Can't be less than 5 Taka Report Date", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            return false;
                        }

                    }

                    if (pVal.ItemUID == "Item_32" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE)
                    {
                        string fullreportdt = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_32").Specific).Value.ToString();
                        string fivetakadt = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_70").Specific).Value.ToString();
                        string res = oDal.ExSelect("select case when convert(datetime, '" + fullreportdt + "')< convert(datetime, '" + fivetakadt + "') then 0 else 1 end", "");
                        if (res == "0")
                        {
                            Packing.SBO_Application.StatusBar.SetText("5 Taka Report Date Can't be less than Lot Date", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            return false;
                        }

                    }

                    if (pVal.ItemUID == "Item_70" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE)
                    {
                        string fullreportdt = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_70").Specific).Value.ToString();
                        string fivetakadt = ((SAPbouiCOM.EditText)oForm.Items.Item("Item_0").Specific).Value.ToString();
                        string res = oDal.ExSelect("select case when convert(datetime, '" + fullreportdt + "')< convert(datetime, '" + fivetakadt + "') then 0 else 1 end", "");
                        if (res == "0")
                        {
                            Packing.SBO_Application.StatusBar.SetText("Lot Date Can't be less than Transaction Date", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            return false;
                        }

                    }
                }
                else if (pVal.BeforeAction == false)
                {
                    #region WtPerMtr Calculation
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "35" && (pVal.ColUID == "V_2" || pVal.ColUID == "V_1"))
                    {
                        oMatrix = oForm.Items.Item("35").Specific;
                        string meter = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", pVal.Row)).Value.ToString();
                        int cnt = oMatrix.VisualRowCount;
                        if (Convert.ToDouble(meter) > 0 && pVal.Row == cnt)
                        {
                            oMatrix.AddRow(1, cnt);
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_-1", oMatrix.VisualRowCount)).Value = oMatrix.VisualRowCount.ToString();
                        }

                        string wt = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", pVal.Row)).Value.ToString();
                        if (Convert.ToDouble(meter) > 0 && Convert.ToDouble(wt) > 0)
                        {
                            string wtpermtr = (Convert.ToDouble(wt) / Convert.ToDouble(meter)).ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", pVal.Row)).Value = wtpermtr;
                            oMatrix.AutoResizeColumns();
                        }

                        ((SAPbouiCOM.EditText)oForm.Items.Item("Item_30").Specific).Value = (AvgWt()).ToString();
                    }
                    #endregion

                    if (pVal.ItemUID == "1" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED && pVal.ActionSuccess == true && oForm.Mode==SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                    {
                        oForm.Close();
                        try
                        {
                            xForm = Packing.SBO_Application.Forms.GetForm("940", 1);
                            Packing.SBO_Application.ActivateMenuItem("1304");
                            
                            //xForm.Refresh();
                        }
                        catch
                        {
 
                        }
                    }
                }

                return true;
            }
            catch
            { return false; }
        }

        public double AvgWt()
        {
            double avgwt = 0;
            double totwt = 0;
            double totmtr = 0;

            try
            {
                oMatrix = oForm.Items.Item("35").Specific;
                int cnt = oMatrix.VisualRowCount;
                for (int i = 1; i <= cnt; i++)
                {
                    string mtr = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", i)).Value.ToString();
                    string wt = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value.ToString();

                    totmtr = totmtr + Convert.ToDouble(mtr);
                    totwt = totwt + Convert.ToDouble(wt);
                }

                if (totmtr > 0)
                {
                    avgwt = totwt / totmtr;
                }


                return avgwt;
            }
            catch
            {
                return avgwt;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using System.Xml;

namespace Packing.Transactions
{
    class BatchCreation
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Matrix oMatrix2;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                if (pVal.BeforeAction == true)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        Packing.ParentFormBatch_Creation = Packing.SBO_Application.Forms.ActiveForm.TypeEx;
                        Packing.ParentFormBatch_Creation_count = Packing.SBO_Application.Forms.ActiveForm.TypeCount;

                        if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "141" || Packing.SBO_Application.Forms.ActiveForm.TypeEx == "721" || Packing.SBO_Application.Forms.ActiveForm.TypeEx == "143")
                        {
                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "141" || Packing.SBO_Application.Forms.ActiveForm.TypeEx == "143")
                            {
                                oMatrix = xForm.Items.Item("38").Specific;
                            }
                            else if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "721")
                            {
                                oMatrix = xForm.Items.Item("13").Specific;
                            }
                            Array.Clear(Packing.batch_Transporter, 0, Packing.batch_Transporter.Length);
                            Array.Clear(Packing.batch_LRDT, 0, Packing.batch_LRDT.Length);
                            Array.Clear(Packing.batch_LRNO, 0, Packing.batch_LRNO.Length);
                            Array.Clear(Packing.batch_PartyChallan, 0, Packing.batch_PartyChallan.Length);
                            Array.Clear(Packing.batch_Pcs, 0, Packing.batch_Pcs.Length);
                            Array.Clear(Packing.batch_StartBale, 0, Packing.batch_StartBale.Length);
                            Array.Clear(Packing.batch_EndBale, 0, Packing.batch_EndBale.Length);
                            Array.Clear(Packing.batch_batch, 0, Packing.batch_batch.Length);
                                //U_BatchNo
                            Packing.batch_cnt = 0;

                            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                            {
                                string item = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).Value.ToString();

                                if (item != "")
                                {
                                    Packing.batch_Transporter[Packing.batch_cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TRANSPRT",i)).Value.ToString();
                                    Packing.batch_LRDT[Packing.batch_cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRDT",i)).Value.ToString();
                                    Packing.batch_LRNO[Packing.batch_cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRNO",i)).Value.ToString();
                                    Packing.batch_PartyChallan[Packing.batch_cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PTYCHALL",i)).Value.ToString();
                                    Packing.batch_Pcs[Packing.batch_cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs",i)).Value.ToString();
                                    try
                                    {
                                        Packing.batch_StartBale[Packing.batch_cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_STBALE", i)).Value.ToString();
                                        Packing.batch_EndBale[Packing.batch_cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ENBALE", i)).Value.ToString();
                                    }
                                    catch { }

                                    if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "721")
                                    {
                                        try
                                        {
                                        string etype = ((SAPbouiCOM.ComboBox)xForm.Items.Item("U_EType").Specific).Selected.Value.ToString();
                                        if (etype == "Excess")
                                        {
                                            Packing.batch_Excess = true;
                                            Packing.batch_batch[Packing.batch_cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", i)).Value.ToString();
                                        }

                                        }
                                            catch
                                        {}
                                    }

                                    Packing.batch_cnt = Packing.batch_cnt + 1;
                                }
                            }

                        }

                        //if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "181")
                        //{
                        //    xForm = Packing.SBO_Application.Forms.ActiveForm;
                        //    oMatrix = xForm.Items.Item("38").Specific;

                        //    Array.Clear(Packing.batch_debit, 0, Packing.batch_debit.Length);
                        //    Array.Clear(Packing.qty_debit, 0, Packing.qty_debit.Length);
                        //    Packing.debit_cnt = 0;

                        //    for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                        //    {
                        //        string item = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).Value.ToString();
                        //        string batch = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", i)).Value.ToString();
                        //        string Qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i)).Value.ToString();

                        //        if (item != "")
                        //        {
                        //            Packing.qty_debit[Packing.debit_cnt] = Qty;
                        //            Packing.batch_debit[Packing.debit_cnt] = batch;
                        //            Packing.debit_cnt = Packing.debit_cnt + 1;
                        //        }
                        //    }


                        //}

                    }
                }
                else if (pVal.BeforeAction == false)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        if (Packing.ParentFormBatch_Creation == "141" || Packing.ParentFormBatch_Creation == "721" || Packing.ParentFormBatch_Creation == "143")
                        {
                            oMatrix = oForm.Items.Item("35").Specific;
                            xForm = Packing.SBO_Application.Forms.GetForm(Packing.ParentFormBatch_Creation, Packing.ParentFormBatch_Creation_count);
                            int cnt = oMatrix.RowCount;
                            string docdate = "";// ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", i)).Value.ToString();
                            if (Packing.ParentFormBatch_Creation == "141" || Packing.ParentFormBatch_Creation == "143")
                                docdate = ((SAPbouiCOM.EditText)xForm.Items.Item("10").Specific).String.ToString();
                            else if (Packing.ParentFormBatch_Creation == "721")
                                docdate = ((SAPbouiCOM.EditText)xForm.Items.Item("9").Specific).String.ToString();

                            docdate = docdate.Replace("/", "");
                            docdate = docdate.Replace("-", "");
                            docdate = docdate.Replace(".", "");
                            //docdate = docdate.Replace("/", "");

                            for (int i = 1; i <= cnt; i++)
                            {
                                oMatrix.Columns.Item("0").Cells.Item(i).Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                string docnum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", i)).Value.ToString();
                                
                                docnum = docnum.Replace(" ", "-");
                                string item = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("5", i)).Value.ToString();
                                string batch = docnum + "-" + i.ToString()+"-"+docdate; ;//item+"-"+docnum+"-"+i.ToString();

                                oMatrix1 = oForm.Items.Item("3").Specific;
                                if (Packing.batch_Excess)
                                {
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("2", 1)).Value = Packing.batch_batch[i - 1].ToString();
                                    oMatrix1.Columns.Item("U_TRANSPRT").Cells.Item(1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                                else
                                {
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("2", 1)).Value = batch;
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("U_TRANSPRT", 1)).Value = Packing.batch_Transporter[i - 1].ToString();
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("U_LRNO", 1)).Value = Packing.batch_LRNO[i - 1].ToString();
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("U_LRDT", 1)).Value = Packing.batch_LRDT[i - 1].ToString();
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("U_PTYCHALL", 1)).Value = Packing.batch_PartyChallan[i - 1].ToString();
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("U_Pcs", 1)).Value = Packing.batch_Pcs[i - 1].ToString();
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("U_STBALE", 1)).Value = Packing.batch_StartBale[i - 1].ToString();
                                    ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("U_ENBALE", 1)).Value = Packing.batch_EndBale[i - 1].ToString();

                                    oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                            }
                            oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "141" || Packing.SBO_Application.Forms.ActiveForm.TypeEx == "143")
                            {
                                oMatrix2 = xForm.Items.Item("38").Specific;
                            }
                            else if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "721")
                            {
                                oMatrix2 = xForm.Items.Item("13").Specific;
                            }
                            if (oMatrix2.VisualRowCount != 1)
                            {
                                xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            }
                            Packing.batch_Excess = false;
                        }

                        //else if (Packing.ParentFormBatch == "181")
                        //{
                        //    oMatrix1 = oForm.Items.Item("3").Specific;
                        //    for (int j = 1; j <= oMatrix1.VisualRowCount; j++)
                        //    {
                        //        bool chk = true;

                        //        oMatrix1.Columns.Item("0").Cells.Item(j).Click(SAPbouiCOM.BoCellClickType.ct_Regular);


                        //        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("10000053").Specific;
                        //        oCombo.Select("1", SAPbouiCOM.BoSearchKey.psk_ByValue);

                        //        oMatrix2 = oForm.Items.Item("5").Specific;
                        //        int selected_cnt = oMatrix2.VisualRowCount;
                        //        if (selected_cnt > 0)
                        //            chk = false;

                        //        oMatrix = oForm.Items.Item("4").Specific;
                        //        int cnt = oMatrix.RowCount;
                        //        try
                        //        {
                        //            for (int i = 1; i <= cnt; i++)
                        //            {
                        //                string batch = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("0", i)).Value.ToString();
                        //                if (batch == Packing.batch_debit[j - 1].ToString() && chk)
                        //                {
                        //                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("4", i)).Value = Packing.qty_debit[j - 1].ToString();
                        //                    oForm.Items.Item("48").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        //                    oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                        //                    chk = false;
                        //                }
                        //            }
                        //        }
                        //        catch { }
                        //    }

                        //    //oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                        //    //xForm = Packing.SBO_Application.Forms.ActiveForm;
                        //    //xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        //}

                    }
                }

                return true;
            }
            catch
            { return false; }
        }
    }
}

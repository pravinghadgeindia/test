﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using System.Xml;


namespace Packing.Transactions
{
    class BatchSelection
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Matrix oMatrix2;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                if (pVal.BeforeAction == true)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        Packing.ParentFormBatch = Packing.SBO_Application.Forms.ActiveForm.TypeEx;
                        
                        if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "940")
                        {
                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            oMatrix = xForm.Items.Item("23").Specific;
                            //Packing.QuantityBatch = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", 1)).Value.ToString();


                            Array.Clear(Packing.IT_batch, 0, Packing.IT_batch.Length);
                            Packing.IT_batch_cnt = 0;
                            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                            {
                                string item = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).Value.ToString();
                                string batch = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", i)).Value.ToString();
                                //string Qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", i)).Value.ToString();

                                if (item != "")
                                {
                                    Packing.IT_batch[Packing.IT_batch_cnt] = batch;
                                    Packing.IT_batch_cnt = Packing.IT_batch_cnt+ 1;
                                }
                            }

                        }

                        if (Packing.SBO_Application.Forms.ActiveForm.TypeEx == "181")
                        {
                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            oMatrix = xForm.Items.Item("38").Specific;

                            Array.Clear(Packing.batch_debit, 0, Packing.batch_debit.Length);
                            Array.Clear(Packing.qty_debit, 0, Packing.qty_debit.Length);
                            Packing.debit_cnt = 0;

                            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                            {
                                string item = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).Value.ToString();
                                string batch = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", i)).Value.ToString();
                                string Qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i)).Value.ToString();

                                if (item != "")
                                {
                                    Packing.qty_debit[Packing.debit_cnt] = Qty;
                                    Packing.batch_debit[Packing.debit_cnt] = batch;
                                    Packing.debit_cnt = Packing.debit_cnt + 1;
                                }
                            }


                        }

                    }
                }
                else if (pVal.BeforeAction == false)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        if (Packing.ParentFormBatch == "940")
                        {
                            oMatrix1 = oForm.Items.Item("3").Specific;

                            for (int i = 1; i <= oMatrix1.VisualRowCount; i++)
                            {
                                oMatrix1.Columns.Item("0").Cells.Item(i).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                string qty = ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("17", i)).Value.ToString();
                                oMatrix = oForm.Items.Item("4").Specific;
                                int cnt = oMatrix.RowCount;
                                bool  selected = false;
                                for (int j = 1; j <= cnt; j++)
                                {
                                    if (!selected)
                                    {
                                        string batch = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("0", j)).Value.ToString();
                                        if (batch == Packing.IT_batch[i - 1].ToString())
                                        {
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("234000059", j)).Value = qty;  //234000059 for SAP 9.3 PL 05 , 4 for SAP 9.2 PL 10
                                            oForm.Items.Item("48").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                            oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                            selected = true;
                                            //oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                            //xForm = Packing.SBO_Application.Forms.ActiveForm;
                                            //xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                        }
                                    }
                                }   
                            }
                            oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            xForm = Packing.SBO_Application.Forms.ActiveForm;
                            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            
                        }

                        else if (Packing.ParentFormBatch == "181")
                        {
                            oMatrix1 = oForm.Items.Item("3").Specific;
                            for (int j = 1; j <= oMatrix1.VisualRowCount; j++)
                            {
                                bool chk = true;

                                oMatrix1.Columns.Item("0").Cells.Item(j).Click(SAPbouiCOM.BoCellClickType.ct_Regular);


                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("10000053").Specific;
                                oCombo.Select("1", SAPbouiCOM.BoSearchKey.psk_ByValue);

                                oMatrix2 = oForm.Items.Item("5").Specific;
                                int selected_cnt=oMatrix2.VisualRowCount;
                                if (selected_cnt > 0)
                                    chk = false;

                                oMatrix = oForm.Items.Item("4").Specific;
                                int cnt = oMatrix.RowCount;
                                try
                                {
                                    for (int i = 1; i <= cnt; i++)
                                    {
                                        string batch = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("0", i)).Value.ToString();
                                        if (batch == Packing.batch_debit[j - 1].ToString() && chk )
                                        {
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("234000059", i)).Value = Packing.qty_debit[j - 1].ToString(); //234000059 for SAP 9.3 PL 05 , 4 for SAP 9.2 PL 10
                                            oForm.Items.Item("48").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                            oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                            chk = false;
                                        }
                                    }
                                }
                                catch { }
                            }

                            //oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                            //xForm = Packing.SBO_Application.Forms.ActiveForm;
                            //xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        }

                    }
                }

                return true;
            }
            catch
            { return false; }
        }
    }
}

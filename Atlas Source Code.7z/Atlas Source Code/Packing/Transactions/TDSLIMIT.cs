﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Packing.Transactions
{
    class TDSLIMIT
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Matrix oMatrix2;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx,pVal.FormTypeCount);
                if (pVal.BeforeAction == true)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && (pVal.ItemUID == "0_U_G" && pVal.ColUID == "C_0_6"))
                    {
                        //oForm = SBO_Application.Forms.ActiveForm;
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        String CardCode = "";
                        CardCode = oForm.Items.Item("0_U_E").Specific.value;
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL
                        //oCFL1 = oForm.ChooseFromLists.Item(sCFL_ID);

                        oCFL.SetConditions(null);
                        oCons = oCFL.GetConditions();



                        oRs = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        string qry = "select CRD4.WTCode from CRD4 inner join OWHT on CRD4.WTCode=OWHT.WTCode where CRD4.CardCode='" + CardCode + "' and  OWHT.Concess ='Y'";

                        oRs.DoQuery(qry);

                        if (oRs.RecordCount > 0)
                        {
                            oCon = oCons.Add();
                            for (int i = 0; i < oRs.RecordCount; i++)
                            {
                                if (i > 0)
                                {
                                    oCon.Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                                    oCon = oCons.Add();
                                }

                                oCon.Alias = "WTCode";
                                oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                                oCon.CondVal = oRs.Fields.Item("WTCode").Value.ToString();
                                oRs.MoveNext();
                            }

                            oCFL.SetConditions(oCons);
                        }
                    }

                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE && (pVal.ItemUID == "0_U_G" && pVal.ColUID == "C_0_3"))
                    {
                        oMatrix = oForm.Items.Item("0_U_G").Specific;
                        string formno = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("C_0_3", pVal.Row)).Value.ToString();
                        if (formno.Trim().Length < 10)
                        {
                            Packing.SBO_Application.StatusBar.SetText("Please enter 10 digit alphanumeric Certificate No", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            return false;
                        }
                    }
                }
                else if (pVal.BeforeAction == false)
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_GOT_FOCUS && (pVal.ItemUID == "0_U_G" && pVal.ColUID == "C_0_6"))
                    {
                        SAPbouiCOM.ChooseFromListCollection oCFLs;
                        oCFLs = oForm.ChooseFromLists;

                        SAPbouiCOM.ChooseFromList oCFL;
                        SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams;
                        oCFLCreationParams = (SAPbouiCOM.ChooseFromListCreationParams)Packing.SBO_Application.CreateObject

                        (SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams);

                        oCFLCreationParams.MultiSelection = false;
                        oCFLCreationParams.ObjectType = "178"; //my user-defined object code
                        oCFLCreationParams.UniqueID = "CFL1";

                        oCFL = oCFLs.Add(oCFLCreationParams);

                        SAPbouiCOM.Column oColumn;
                        SAPbouiCOM.Columns oColumns;

                        oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                        
                        oMatrix = oForm.Items.Item("0_U_G").Specific;
                        oColumns = oMatrix.Columns;
                        oColumn = oColumns.Item("C_0_6");
                        oColumn.ChooseFromListUID = "CFL1";
                        oColumn.ChooseFromListAlias = "WTCode";

                    }


                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && (pVal.ItemUID == "0_U_G" && pVal.ColUID == "C_0_6"))
                    {
                        //oForm = SBO_Application.Forms.GetForm("720", pVal.FormTypeCount);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                        oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                        string sCFL_ID = null;
                        sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string val1 = null;
                        string val2 = null;
                        string val3 = null;

                        SAPbouiCOM.ChooseFromList oCFL = null;
                        oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        oDataTable = oCFLEvento.SelectedObjects;

                        val1 = oDataTable.GetValue("WTCode", 0).ToString();
                        oMatrix = oForm.Items.Item("0_U_G").Specific;
                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("C_0_6",pVal.Row);
                        try
                        {
                            oEdit.Value = val1;
                        }
                        catch { }
                    }
                }

                return true;
            }
            catch
            { return false; }
        }

    }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace Packing.Transactions
{
    class Checking
    {

        #region Variables

        public SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        DataAcessLayer oDal = new DataAcessLayer();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {


                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = Packing.SBO_Application.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = Packing.SBO_Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        Packing.SBO_Application.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm =Packing.SBO_Application.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == "CFL_BP")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@CHECKING");
                                oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_IT")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@CHECKING");
                                oDbDataSource.SetValue("U_ITNo", 0, oDataTable.GetValue("DocNum", 0).ToString());
                                oDbDataSource.SetValue("U_ITDE", 0, oDataTable.GetValue("DocEntry", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_Batch")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@CHECKING");
                                oDbDataSource.SetValue("U_BatchNo", 0, oDataTable.GetValue("DistNumber", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_LotNo")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@CHECKING1").SetValue("U_LotNo", pVal.Row - 1, oDataTable.GetValue("MnfSerial", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@CHECKING1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@CHECKING1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@CHECKING1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_5").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                GlobalVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                GlobalVariables.ColNo = oPos.ColumnIndex;
                                GlobalVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                if (pVal.ItemUID == "Series")
                                {
                                    oForm = Packing.SBO_Application.Forms.Item(FormUID);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(0);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), "Checking").ToString();//objclsComman.GetMaxDocNum("KIT_PO", idefaultseries);
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Packing.SBO_Application.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message,SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        Packing.SBO_Application.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion


                #region F_et_FORM_ACTIVATE
                else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                {
                    if (pVal.FormTypeEx == "Checking")
                    {

                        if (GlobalVariables.boolCFLSelected)
                        {
                            GlobalVariables.boolCFLSelected = false;
                            oForm = (SAPbouiCOM.Form)Packing.SBO_Application.Forms.Item(pVal.FormUID);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                            oMatrix.SetCellFocus(GlobalVariables.RowNo, GlobalVariables.ColNo);
                            GlobalVariables.RowNo = 0;
                            GlobalVariables.ColNo = 0;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                Packing.SBO_Application.StatusBar.SetText("Item Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = Packing.SBO_Application.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "Checking" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == "1292")
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item("@Checking");

                        string Value;
                        Value = oForm.DataSources.DBDataSources.Item("@Checking").GetValue("U_LotNo", oMatrix.VisualRowCount - 1).ToString().Trim();
                        oDal.AddRow(oMatrix, oDBDataSource, Value);
                    }
                    else if (pVal.MenuUID == "1293")
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@Checking").Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item("@Checking").GetValue("U_LotNo", i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item("@Checking").RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item("@Checking").SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();
                    }

                }
            }
            catch (Exception ex)
            {
                Packing.SBO_Application.SetStatusBarMessage("Menu Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = Packing.SBO_Application.Forms.ActiveForm;
                        string Code = oForm.DataSources.DBDataSources.Item("@PROCESS").GetValue("DOCENTRY", 0);
                        oDal.SelectRecord("DELETE FROM [@Checking] WHERE  (ISNULL(U_LotNo,'')='') AND DOCENTRY='" + Code + "'");
                    }

                }
            }
            catch (Exception ex)
            {
                Packing.SBO_Application.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method


        private void LoadForm(string MenuID)
        {
            if (MenuID == "Checking")
            {
                GlobalVariables.boolCFLSelected = false;
                oDal.LoadFromXML(MenuID);
                oForm = Packing.SBO_Application.Forms.ActiveForm;
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                oForm.EnableMenu("1282", true);
                oForm.EnableMenu("1281", true);

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;
            }

            oForm = Packing.SBO_Application.Forms.ActiveForm;
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.CommonSetting.EnableArrowKey = true;


            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            #region Series And DocNum
            oForm = Packing.SBO_Application.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("YardConv").Specific;
                oEdit.String = "0.9144";


                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                oDal.FillCombo_Series_Custom(oForm, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "Checking").ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion


            oItem = oForm.Items.Item("DocNum");
            oDal.SetAutoManagedAttribute(oItem);
            oItem = oForm.Items.Item("DocEntry");
            oDal.SetAutoManagedAttribute(oItem);
        }

        #endregion
    }
}

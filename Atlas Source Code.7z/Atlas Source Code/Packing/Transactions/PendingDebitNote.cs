﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Packing.Transactions
{
    class PendingDebitNote
    {
        #region variables
        DataAcessLayer oDal = new DataAcessLayer();
        private SAPbouiCOM.Column oColumn;
        private SAPbouiCOM.Columns oColumns;
        private SAPbouiCOM.ComboBox oCombo = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.EditText oEdit, oEditLoc, oEditItemCode, oEditMacCode, oEditSFG, oEditSFGName;
        private SAPbouiCOM.EditText oEditType, oEditSize, oEditColor, oEditTracer, oEditReqLength, oEditReqWt, oEditReqCoilWt, oEditReqMinWt, oEditReqMaxWt, oEditLengthS;
        private SAPbouiCOM.EditText oEditBDenier, oEditYDenier, oEditPDenier, oEditPlyTPM, oEditCableTPM, oEditCore1, oEditCore2, oEditCore3, oEditOuter, oEditTotal;
        private SAPbouiCOM.EditText oEditPlyDie, oEditCableDie, oEditUGear, oEditLGear, oEditAGear, oEditBGear, oEditCGear, oEditDGear, oEditPitch;
        private SAPbouiCOM.EditText oEditBobbinFrom, oEditBobbinTo, oEditPlyFrom, oEditPlyTo, oEditXGear, oEditYGear, oEditGearPitch, oEditActualPitchPly, oEditActualPitchCable, oEditBoppTape;
        private SAPbouiCOM.EditText oEditRemark1, oEditRemark2, oEditRemark3, oEditRemark4;
        private SAPbouiCOM.EditText oEditConstr, oEditBreak;
        bool BubbleEvent;
        private SAPbouiCOM.MenuItem oMenu;
        private SAPbouiCOM.Item oItem1;
        private SAPbouiCOM.Item oItem;
        private SAPbouiCOM.Matrix oMatrix;
        private SAPbouiCOM.Matrix oMatrix1;
        private SAPbouiCOM.Form xForm;
        static string exist_ref = "";
        private SAPbouiCOM.CheckBox oCheckBox;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromList oCFL1 = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Conditions oCons1 = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.Condition oCon1 = null;
        public static SAPbobsCOM.Recordset oRs;
        String Value = "";
        private SAPbouiCOM.EditText oEdit1;

        #endregion

        public bool itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            bool bevent = true;
            try
            {
                oForm = Packing.SBO_Application.Forms.Item("PendingDebitNote");
                #region copy to Purchase Invoice From CFPO
                if (pVal.FormUID == "PendingDebitNote" && pVal.ItemUID == "btnCopy" && pVal.BeforeAction == false)
                {

                    oMatrix = oForm.Items.Item("Item_0").Specific;
                    string[] Jobworker = new string[5000];
                    string[] itype = new string[5000];
                    string[] Batchnum = new string[5000];
                    string[] Lotno = new string[5000];
                    string[] Qunaity = new string[5000];
                    string[] Bale = new string[5000];
                    string[] Pcs = new string[5000];
                    string[] Yard = new string[5000];
                    string[] ITDE = new string[5000];
                    string[] icode = new string[5000];
                    
                    int cnt = 0;

                    for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                    {
                        oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("Col_0", i));
                        if (oCheckBox.Checked)
                        {
                            Jobworker[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_1", i)).Value.ToString();
                            Batchnum[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_3", i)).Value.ToString();
                            Lotno[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_4", i)).Value.ToString();
                            Qunaity[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_7", i)).Value.ToString();
                            Bale[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_8", i)).Value.ToString();
                            Pcs[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_9", i)).Value.ToString();
                            Yard[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_10", i)).Value.ToString();
                            ITDE[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_11", i)).Value.ToString();
                            icode[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("Col_5", i)).Value.ToString();
                            itype[cnt] = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).Value.ToString();
                            
                            cnt = cnt + 1;
                        }
                    }

                    try
                    {
                        oForm.Close();
                        oForm = Packing.SBO_Application.Forms.GetForm("181", Packing.ParentCount_CFPO);
                        oMatrix = oForm.Items.Item("38").Specific;
                        SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        for (int i = 0; i < cnt; i++)
                        {
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i + 1)).Value = icode[i].ToString();
                            oForm.Freeze(true);

                            string rate = oDal.ExSelect("select PCH1.PriceBefDi from OIBT inner join PCH1 on OIBT.BaseEntry=PCH1.Docentry and OIBT.BaseLinNum=PCH1.LineNum and OIBT.BaseType=PCH1.ObjType where BatchNum='" + Batchnum[i].ToString() + "' and OIBT.WhsCode='01'", "");

                            string tax = oDal.ExSelect("select PCH1.TaxCode from OIBT inner join PCH1 on OIBT.BaseEntry=PCH1.Docentry and OIBT.BaseLinNum=PCH1.LineNum and OIBT.BaseType=PCH1.ObjType where BatchNum='" + Batchnum[i].ToString() + "' and OIBT.WhsCode='01'", "");

                            string HSN = oDal.ExSelect("select OCHP.ChapterID from OIBT inner join PCH1 on OIBT.BaseEntry=PCH1.Docentry and OIBT.BaseLinNum=PCH1.LineNum and OIBT.BaseType=PCH1.ObjType Left Join OCHP on Pch1.HsnEntry=OCHP.AbsEntry where BatchNum='" + Batchnum[i].ToString() + "' and OIBT.WhsCode='01'", "");

                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i + 1)).Value = Qunaity[i].ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", i + 1)).Value = rate;

                            try
                            {
                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", i + 1)).Value = "01";

                            }
                            catch { }


                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_JobWrkr", i + 1)).Value = Jobworker[i].ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Bale", i + 1)).Value = Bale[i].ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Pcs", i + 1)).Value = Pcs[i].ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Yard", i + 1)).Value = Yard[i].ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ITEntry", i + 1)).Value = ITDE[i].ToString();
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BatchNo", i + 1)).Value = Batchnum[i].ToString();
                            ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_itype", i + 1)).Select(itype[i].ToString(),SAPbouiCOM.BoSearchKey.psk_ByDescription);
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", i + 1)).Value = tax;
                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("254000391", i + 1)).Value = HSN;
                            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i + 1)).Value = Qunaity[i].ToString();


                            oMatrix.Columns.Item("11").Cells.Item(i + 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            //oMatrix.Columns.Item("11").Cells.Item(i+1).Click(SAPbouiCOM.BoCellClickType.ct_Right);
                            //Packing.SBO_Application.ActivateMenuItem("5896");

                            //xForm = Packing.SBO_Application.Forms.GetForm("42", 1);
                            //oCombo = (SAPbouiCOM.ComboBox)xForm.Items.Item("10000053").Specific;
                            //oCombo.Select("1", SAPbouiCOM.BoSearchKey.psk_ByValue);
                            //oMatrix1 = xForm.Items.Item("4").Specific;
                            //try
                            //{
                            //    for (int j = 1; j <= oMatrix1.VisualRowCount; j++)
                            //    {
                            //        string batch_mat = ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("0", j)).Value.ToString();
                            //        if (batch_mat == Batchnum[i].ToString())
                            //        {
                            //            ((SAPbouiCOM.EditText)oMatrix1.GetCellSpecific("4", j)).Value = Qunaity[i].ToString();
                            //            xForm.Items.Item("42").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            //            xForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            //        }


                            //    }
                            //}
                            //catch { }
                            oForm.Freeze(false);
                            
                        }
                    }
                    catch { oForm.Freeze(false); }


                }

                #endregion

                #region choose from list before action true
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "4" && pVal.BeforeAction == true)
                {
                    //SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    //oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    //string sCFL_ID = null;
                    //sCFL_ID = oCFLEvento.ChooseFromListUID;
                    //oCFL = oForm.ChooseFromLists.Item(sCFL_ID); // this is UID of CFL

                    //oCFL.SetConditions(null);
                    //oCons = oCFL.GetConditions();

                    //oCon = oCons.Add();

                    //oCon.Alias = "GroupCode";
                    //oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    //oCon.CondVal = "103";

                    //oCFL.SetConditions(oCons);
                }

                #endregion

                #region choose from list before action false
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST && pVal.ItemUID == "4" && pVal.BeforeAction == false)
                {
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                    string sCFL_ID = null;
                    sCFL_ID = oCFLEvento.ChooseFromListUID;
                    string val1 = null;
                    string val2 = null;


                    SAPbouiCOM.ChooseFromList oCFL = null;
                    oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                    SAPbouiCOM.DataTable oDataTable = null;
                    oDataTable = oCFLEvento.SelectedObjects;


                    val1 = oDataTable.GetValue("CardCode", 0).ToString();
                    val2 = oDataTable.GetValue("CardName", 0).ToString();

                    oEdit = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific);
                    try
                    {
                        oEdit.Value = val1;
                    }
                    catch
                    { }

                    oEdit = ((SAPbouiCOM.EditText)oForm.Items.Item("5").Specific);
                    oEdit.Value = val2;
                }
                #endregion

                #region Click Get PO Fill Matrix
                if (((pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK && pVal.ItemUID == "6")) && pVal.BeforeAction == false)  //|| (pVal.EventType==SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.ItemUID=="8")
                {
                    oMatrix = oForm.Items.Item("2").Specific;
                    string broker = ((SAPbouiCOM.EditText)oForm.Items.Item("4").Specific).Value.ToString();
                    string PO = ((SAPbouiCOM.EditText)oForm.Items.Item("8").Specific).Value.ToString();
                    string Dt = ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value.ToString();


                    string Sql = "select 'N' chk,T0.CardCode,T0.CardName,T0.DocEntry,T0.DocNum,T1.LineNum,T1.ItemCode,T1.Dscription,T1.Quantity [OpenQty],isnull(T1.U_Bale,0) U_Bale,isnull(T1.U_Pcs,0) U_Pcs,isnull(T1.U_Yard,0) U_Yard, " +
                                   " isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed QTY], " +
                                   " isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed Bale], " +
                                   " isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed PCS], " +
                                   " isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0) [Consumed Yard], " +
                                   " (T1.Quantity -isnull((select Sum(PCH1.U_GrsQty) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenMtr] " +
                                   " ,(isnull(T1.U_Bale,0)-isnull((select Sum(isnull(PCH1.U_bale,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenBale] " +
                                   " ,(isnull(T1.U_Pcs,0)-isnull((select Sum(isnull(PCH1.U_Pcs,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenPcs] " +
                                   " ,(isnull(T1.U_Yard,0)-isnull((select Sum(isnull(PCH1.U_Yard,0)) from PCH1 inner join OPCH on PCH1.DocEntry=OPCH.DocEntry where OPCH.CANCELED='N' and PCH1.U_POBSEntry=T1.DocEntry and PCH1.U_POBSLine=T1.LineNum),0)) [OpenYard] " +
                                   " from OPOR [T0] inner join [POR1] [T1] on T0.DocEntry=T1.DocEntry " +
                                   " inner join OCRD [T2] on T0.CardCode=T2.CardCode " +
                                   " where T0.DocStatus='O' and T1.LineStatus='O' and (T0.CardCode='" + broker + "' or '" + broker + "'='') and (T0.DocNum='" + PO + "' or '" + PO + "'='') and T0.DocDate<='" + Dt + "'"; //and T2.GroupCode='103' 

                    //SAPbobsCOM.Recordset oRset = Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    //oRset.DoQuery(Sql);

                    //oMatrix.Clear();

                    oForm.DataSources.DataTables.Item("RET").Clear();

                    oForm.DataSources.DataTables.Item("RET").ExecuteQuery(Sql);



                    //if (oRset.RecordCount > 0)
                    //{
                    //    try
                    //    {
                    //        oForm.Freeze(true);
                    //        for (int i = 1; i <= oRset.RecordCount; i++)
                    //        {
                    //            oMatrix.AddRow(1, (i - 1));
                    //            ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", i)).Checked = false;
                    //            //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).Value = oRset.Fields.Item("CardCode").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).Value = oRset.Fields.Item("CardName").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).Value = oRset.Fields.Item("Dscription").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", i)).Value = oRset.Fields.Item("OpenMtr").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).Value = oRset.Fields.Item("OpenBale").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_12", i)).Value = oRset.Fields.Item("OpenPcs").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_14", i)).Value = oRset.Fields.Item("OpenYard").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_2", i)).Value = oRset.Fields.Item("DocNum").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).Value = oRset.Fields.Item("LineNum").Value.ToString();
                    //            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).Value = oRset.Fields.Item("DocEntry").Value.ToString();


                    //            oRset.MoveNext();
                    //        }
                    //        oForm.Freeze(false);
                    //    }
                    //    catch { oForm.Freeze(false); }
                    //}
                }
                #endregion

                #region check tick
                if (pVal.ItemUID == "2" && (pVal.ColUID == "V_9" || pVal.ColUID == "V_11" || pVal.ColUID == "V_13" || pVal.ColUID == "V_15") && pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS && pVal.BeforeAction == false)
                {
                    oMatrix = oForm.Items.Item("2").Specific;
                    string openmeter = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", pVal.Row)).Value.ToString();
                    string openBale = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_11", pVal.Row)).Value.ToString();
                    string openPcs = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_13", pVal.Row)).Value.ToString();
                    string openYard = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_15", pVal.Row)).Value.ToString();
                    oCheckBox = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_8", pVal.Row));

                    if ((Convert.ToDouble(openmeter) > 0 || Convert.ToDouble(openBale) > 0 || Convert.ToDouble(openPcs) > 0 || Convert.ToDouble(openYard) > 0) && oCheckBox.Checked == false)
                    {
                        oCheckBox.Checked = true;
                    }

                }
                #endregion


                #region key pressed
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN)
                {
                    int key = pVal.CharPressed;
                    if (key == 15)
                        oForm.Items.Item("btnCopy").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                }
                #endregion

                return true;
            }
            catch
            { return false; }
        }
    }
}

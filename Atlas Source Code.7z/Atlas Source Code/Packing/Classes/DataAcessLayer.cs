using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.ComponentModel;
using System.Security.Cryptography;
using System.IO;
using System.Web;
using System.Net.Mail;
using System.Xml;

namespace Packing
{
    public class DataAcessLayer
    {
        public SqlConnection vConn = new SqlConnection();
        private SAPbouiCOM.EditText oEdit;

        //SAPbobsCOM.Company Soft_Company = new SAPbobsCOM.Company();
        public SqlCommand cmd = new SqlCommand();
        public SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand cmdOle = new SqlCommand();
        SqlConnection DRSConn = new SqlConnection();
        private SAPbouiCOM.Form oForm;
        string Server_Name = "";
        string Database = "";
        string File_Name = "";
        string UID = "";
        string UPWD = "";
        string XML = "";
        string Report_Path = "";

        string c_ip = "";
        string c_user = "";
        string c_pass = "";
        string c_location = "";

        static int RowNo;
        SqlDataReader dr;

        public int rowindex
        {
            get
            {
                return RowNo;
            }
            set
            {
                RowNo = value;
            }
        }

        public string servername
        {
            get
            {
                return Server_Name;
            }
        }

        public string DatabaseName
        {
            get
            {
                return Database;
            }
        }

        public string UserID
        {
            get
            {
                return UID;
            }
        }

        public string UserPassword
        {
            get
            {
                return UPWD;
            }
        }

        public string XMLPath
        {
            get
            {
                return XML;
            }
        }

        public string ReportPath
        {
            get
            {
                return Report_Path;
            }
        }

        public SqlConnection OpenConnection()
        {
            string path = Application.StartupPath;
            StreamReader myFile = new System.IO.StreamReader(path + "\\connection.txt");
            string str1 = myFile.ReadToEnd().ToString();
            string[] str = str1.Split(new char[] { ';' });
            myFile.Close();
            Server_Name = Packing.ServerName;
            File_Name = str[2];
            UID = str[3];
            UPWD = str[4];
            XML = str[2];
            Report_Path = str[6];
            Database = Packing.DBName;
            vConn = new SqlConnection();
            vConn.ConnectionString = "Data source='" + Server_Name + "';uid=" + UID + ";pwd=" + UPWD + ";database='" + Database + "';";
            vConn.Open();
            return vConn;
        }


        public SqlConnection OpenConnection_lable()
        {
            string path = Application.StartupPath;
            StreamReader myFile = new System.IO.StreamReader(path + "\\connection.txt");
            string str1 = myFile.ReadToEnd().ToString();
            string[] str = str1.Split(new char[] { ';' });
            myFile.Close();
            Server_Name = Packing.ServerName;
            File_Name = str[2];
            UID = str[3];
            UPWD = str[4];
            XML = str[2];
            Report_Path = str[6];
            Database = "Label";
            vConn = new SqlConnection();
            vConn.ConnectionString = "Data source='" + Server_Name + "';uid=" + UID + ";pwd=" + UPWD + ";database='" + Database + "';";
            vConn.Open();
            return vConn;
        }


        public void credential()
        {
            string path = Application.StartupPath;
            StreamReader myFile = new System.IO.StreamReader(path + "\\Credential.txt");
            string str1 = myFile.ReadToEnd().ToString();
            string[] str = str1.Split(new char[] { ';' });
            myFile.Close();

            Packing.c_ip = str[0];
            Packing.c_location = str[3];
            Packing.c_user = str[1];
            Packing.c_pass = str[2];
            //string str = @"\\192.168.6.158 -u tufropes\administrator -p set!t@1234 -i F:\getwt.exe";
            //return vConn;
        }

        public SqlConnection Open_DRSConnection()
        {
            string path = Application.StartupPath;
            StreamReader myFile = new System.IO.StreamReader(path + "\\DRS_connection.txt");
            string str1 = myFile.ReadToEnd().ToString();
            string[] str = str1.Split(new char[] { ';' });
            myFile.Close();
            Server_Name = str[0];
            File_Name = str[2];
            UID = str[3];
            UPWD = str[4];
            XML = str[2];
            Report_Path = str[6];
            Database = str[1];
            DRSConn = new SqlConnection();
            DRSConn.ConnectionString = "Data source='" + Server_Name + "';uid=" + UID + ";pwd=" + UPWD + ";database='" + Database + "';";
            DRSConn.Open();
            return DRSConn;
        }

        public SqlConnection CloseConnection()
        {
            vConn.Close();
            vConn.Dispose();
            return vConn;
        }

        public SqlConnection CloseDRSConnection()
        {
            DRSConn.Close();
            DRSConn.Dispose();
            return DRSConn;
        }

        public DataSet FillDataset(string Query)
        {
            DataSet ods = new DataSet();
            try
            {
                OpenConnection();
                cmd = new SqlCommand(Query, vConn);
                da = new SqlDataAdapter(cmd);
                da.Fill(ods);
            }
            catch (Exception oEx)
            {
                MessageBox.Show(oEx.Message);
            }
            finally
            {
                CloseConnection();
            }
            return ods;
        }

        public string ExSelect(string Query, string conName)
        {
            string Str = "";
            try
            {
                cmd = new SqlCommand(Query, (conName == "Label" ? OpenConnection_lable() : OpenConnection()));
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    Str = dr[0].ToString();
                }
                dr.Close();
                CloseConnection();
                return Str;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return Str;
            }
        }

        public string sendMails(string host, string userName, string userPassword, string Credentials, int Port, string FromEmailId, string ToEmailID, string Subject, string Body, Int16 IsHTMLFormat, Int16 Priority, Int16 IsAttachment, bool EnableSsl, string CCEmailId, string BCCEmailID, string fullPath)
        {
            try
            {
                userName = ExSelect("Select U_From from [@RPTQUERY]", "SAP"); //"manisha@softcoresolutions.com"; ///"sapsupport@sleekworld.com";//
                FromEmailId = userName;// "manisha@softcoresolutions.com"; //
                Port = Convert.ToInt32(ExSelect("Select U_Port from [@RPTQUERY]", "SAP")); //25;//587;// 587;//
                userPassword = ExSelect("Select U_Pass from [@RPTQUERY]", "SAP"); //"sapsupport123";//"manisha1234";//
                host = ExSelect("Select U_Server from [@RPTQUERY]", "SAP"); //"mail.sleekworld.com";//"192.168.0.105";"smtp.gmail.com"; //
                EnableSsl = false;//

                //userName = "support@softcoresolutions.com"; //
                //FromEmailId = "support@softcoresolutions.com";
                //Port = 587;// 
                //userPassword = "support12345";//"sapsupport123";//
                //host = "smtp.gmail.com"; //"mail.sleekworld.com";//"192.168.0.105";
                //EnableSsl = true; //

                SmtpClient smtpServer = new SmtpClient();
                MailMessage mail = new MailMessage();
                smtpServer.Host = host;

                if (!string.IsNullOrEmpty(fullPath))
                {
                    System.Net.Mail.Attachment Attachment = null;
                    Attachment = new System.Net.Mail.Attachment(fullPath);
                    mail.Attachments.Add(Attachment);
                }
                if (Credentials == "0")
                {
                    smtpServer.Credentials = new System.Net.NetworkCredential(userName, userPassword);
                }
                smtpServer.Port = Port;
                smtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpServer.EnableSsl = EnableSsl;
                mail.From = new MailAddress(FromEmailId);
                mail.To.Add(ToEmailID);
                if (!string.IsNullOrEmpty(CCEmailId))
                {
                    mail.CC.Add(CCEmailId);
                }
                if (!string.IsNullOrEmpty(BCCEmailID))
                {
                    mail.Bcc.Add(BCCEmailID);
                }
                if (IsHTMLFormat == 0)
                {
                    mail.IsBodyHtml = true;
                }
                else
                {
                    mail.IsBodyHtml = false;
                }
                mail.Priority = 0;
                mail.Subject = Subject;
                mail.Body = Body;
                smtpServer.Send(mail);
                //MyLogEvent.WriteEntry("stage in mail sent " + DateTime.Now);
                return "1";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return ex.Message;
            }
        }

              
        //private void DataTableToFilePath(DataTable tblInput, string path, out string filename)
        //{
        //    int columnindex = 0;
        //    int Exc_RowIndex = 2;
        //    Microsoft.Office.Interop.Excel.Application wapp;
        //    Microsoft.Office.Interop.Excel.Worksheet wsheet;
        //    Microsoft.Office.Interop.Excel.Workbook wbook;
        //    wapp = new Microsoft.Office.Interop.Excel.Application();
        //    wapp.Visible = false;
        //    wbook = wapp.Workbooks.Add(true);
        //    wsheet = (Microsoft.Office.Interop.Excel.Worksheet)wbook.ActiveSheet;
        //    try
        //    {
        //        for (int k = 1; k < tblInput.Columns.Count + 1; k++)
        //        {
        //            wsheet.Cells[2, k] = tblInput.Columns[k - 1].ColumnName.ToString();
        //        }

        //        int i;
        //        for (i = 0; i < tblInput.Rows.Count; i++)
        //        {
        //            for (int j = 0; j < tblInput.Columns.Count; j++)
        //            {
        //                wsheet.Cells[i + 3, j + 1] = tblInput.Rows[i][j];
        //            }
        //        }
        //        wsheet.Columns.AutoFit();

        //        wbook.SaveAs(path, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
        //        wbook.Close(false, System.Type.Missing, System.Type.Missing);
        //        wbook = null;
        //        filename = path;
        //        wapp.Quit();
        //        GC.Collect();
        //        GC.WaitForPendingFinalizers();
        //    }
        //    catch (Exception ex)
        //    {
        //        //MyLogEvent.WriteEntry("error" + ex.Message);
        //        filename = "";
        //        GC.Collect();
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        public bool CheckPresent(SAPbouiCOM.Form oForm, string TableName)
        {
            bool R = false;
            string Q = null;
            string Name = null;

            SAPbobsCOM.Recordset oRS = null;
            oRS = (SAPbobsCOM.Recordset)Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

           

            Q = "SELECT * FROM " + TableName + " WHERE Name='" + Name + "'";
            oRS.DoQuery(Q);

            if (!oRS.EoF)
            {
                R = true;

            }
            else
            {
                R = false;
            }
            return R;
        }

        public bool AutoCode(SAPbouiCOM.Form oForm, string TableName)
        {
            bool Result = false;
            SAPbobsCOM.Recordset oRS = null;
            oRS = (SAPbobsCOM.Recordset)(Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset));
            string Q = null;
            string AutoCode = null;


            Q = "SELECT isnull(max(Convert(int,Code)),'') + 1 as Code FROM " + TableName + "";
            oRS.DoQuery(Q);

            if (!oRS.EoF)
            {
                AutoCode = oRS.Fields.Item("Code").Value.ToString();

                oEdit = (SAPbouiCOM.EditText)(oForm.Items.Item("txtCode").Specific);
                oEdit.Value = AutoCode.ToString();

                Result = true;
            }
            else
            {
                Result = false;
            }

            return Result;
        }

        #region LoadFromXML
        public void LoadFromXML(String FormName)
        {
            string sXmlFileName;
            string QStr = null;
            string DocEnt = null;
            int Docentry = 0;

            //SAPbobsCOM.Recordset InsertRec = null;
            //InsertRec = (SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset));

            sXmlFileName = Application.StartupPath.ToString();
            sXmlFileName = sXmlFileName + "\\" + FormName + ".srf";
            XmlDocument oXmlDoc = new XmlDocument();
            oXmlDoc.Load(sXmlFileName);
            string sXML = oXmlDoc.InnerXml.ToString();
            Packing.SBO_Application.LoadBatchActions(ref sXML);
            oForm = Packing.SBO_Application.Forms.ActiveForm;

            if (oForm.UniqueID.ToString() == "frm_Supplier_ratecard")
            {
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;

                
                oForm.EnableMenu("1292", true);
                oForm.EnableMenu("1283", false);
                oForm.EnableMenu("1287", true);
                oForm.EnableMenu("1286", false);
                oForm.EnableMenu("1284", false);

                oForm.DataBrowser.BrowseBy = "3";
                //AddChooseFromList();
            }
            else if (oForm.UniqueID.ToString() == "frm_cust_comm")
            {
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;


                oForm.EnableMenu("1292", true);
                oForm.EnableMenu("1283", false);
                oForm.EnableMenu("1287", true);
                oForm.EnableMenu("1286", false);
                oForm.EnableMenu("1284", false);

                oForm.DataBrowser.BrowseBy = "3";
            }

            else if (oForm.UniqueID.ToString() == "frm_sup_dtl")
            {
                oForm.EnableMenu("1288", false);
                oForm.EnableMenu("1289", false);
                oForm.EnableMenu("1290", false);
                oForm.EnableMenu("1291", false);
                oForm.DataBrowser.BrowseBy = "3";
            }

            else if (oForm.UniqueID.ToString() == "frmStkInv")
            {
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;


                oForm.EnableMenu("1292", true);
                oForm.EnableMenu("1283", false);
                oForm.EnableMenu("1287", true);
                oForm.EnableMenu("1286", false);
                oForm.EnableMenu("1284", false);

                //oForm.DataBrowser.BrowseBy = "3";
            }

        }
        #endregion

        public string SelectRecord(string Querry)
        {
            SAPbobsCOM.Recordset oRS_Select = null;
            try
            {
                string str = "";
                oRS_Select = ((SAPbobsCOM.Recordset)(Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                oRS_Select.DoQuery(Querry);

                if (oRS_Select.EoF == false)
                {
                    str = oRS_Select.Fields.Item(0).Value.ToString();
                }
                else
                {
                    str = "";
                }
                return str;
            }
            catch (Exception ex)
            {
                Packing.SBO_Application.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
                return ex.Message;
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRS_Select);
                oRS_Select = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }

        public SAPbobsCOM.Recordset returnRecord(string Querry)
        {
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                oRs = ((SAPbobsCOM.Recordset)(Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                oRs.DoQuery(Querry);
                return oRs;
            }
            catch
            {
                return oRs;
            }
        }

        public void SetAutoManagedAttribute_AddMode(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, -1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
        }

        public void SetAutoManagedAttribute_UpdateMode(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
        }

        public void SetAutoManagedAttribute(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 3, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
        }

        #region AddRow And DeleteRow

        public void AddRow(SAPbouiCOM.Matrix oMatrix, SAPbouiCOM.DBDataSource oDbDataSource, string Value)
        {
            oMatrix.FlushToDataSource();
            if (oMatrix.VisualRowCount == 0)
                oMatrix.AddRow(1, oMatrix.RowCount);
            else
            {

                if (Value != string.Empty)
                {
                    oDbDataSource.InsertRecord(oMatrix.RowCount);
                    oMatrix.LoadFromDataSource();
                }
            }
        }


        #endregion

        public void FillCombo_Series_Custom(SAPbouiCOM.Form oForm, string SeriesUDF, string Mode)
        {
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                SAPbouiCOM.ComboBox oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                string ObjectCode = oForm.DataSources.DBDataSources.Item(0).TableName.Replace("@", string.Empty);

                if (Mode == "Load")
                {
                    string DOCDATE = ((SAPbouiCOM.EditText)oForm.Items.Item(SeriesUDF).Specific).Value;
                    StringBuilder sbQuery = new StringBuilder();

                    sbQuery.Append(" SELECT T0.SERIES, T0.SERIESNAME  FROM NNM1 T0  ");
                    sbQuery.Append(" INNER JOIN OFPR T1 ON T0.INDICATOR = T1.INDICATOR  ");
                    sbQuery.Append(" WHERE OBJECTCODE='" + ObjectCode + "'  AND     LOCKED = 'N'  ");
                    sbQuery.Append(" AND F_REFDATE <='" + DOCDATE + "'  AND T_REFDATE >= '" + DOCDATE + "'  ");
                    sbQuery.Append(" GROUP BY T0.SERIES, T0.SERIESNAME  ");


                    int Count = oCombo.ValidValues.Count;
                    for (int i = 0; i < Count; i++)
                    {
                        try
                        {
                            oCombo.ValidValues.Remove(oCombo.ValidValues.Count - 1, SAPbouiCOM.BoSearchKey.psk_Index);
                        }
                        catch { }
                    }
                    oRs = returnRecord(sbQuery.ToString());
                    while (!oRs.EoF)
                    {
                        try
                        {
                            oCombo.ValidValues.Add(oRs.Fields.Item("SERIES").Value.ToString(), oRs.Fields.Item("SERIESNAME").Value.ToString());
                        }
                        catch { }
                        oRs.MoveNext();
                    }

                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);

                }
                else
                {
                    oCombo.ValidValues.LoadSeries(ObjectCode, SAPbouiCOM.BoSeriesMode.sf_View);

                }
            }
            catch
            {
                Packing.SBO_Application.StatusBar.SetText("Error while loading series", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Xml;
using System.Threading;
using System.Windows.Forms;
using System.Collections;
using System.Globalization;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.Net;
using System.Drawing;
using System.Diagnostics;
using System.Timers;
using System.Net.Mail;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Microsoft.Win32;


namespace Packing
{
    class Create_DB
    {

        private SAPbobsCOM.UserTablesMD oUserTablesMD = null;
        private SAPbobsCOM.UserFieldsMD oUserFieldsMD = null;
        private SAPbobsCOM.UserObjectsMD oUserObjectMD = null;
        private SAPbouiCOM.Form oForm;
        private SAPbouiCOM.StaticText lbl_1 = null;
        private SAPbouiCOM.StaticText lbl_2 = null;
        private SAPbouiCOM.StaticText lbl_3 = null;
        private SAPbouiCOM.StaticText lbl_Status = null;

        public void itemevent(ref SAPbouiCOM.ItemEvent pVal)
        {
            #region "Addon Initialization"
            //intialization of master forms
            if (pVal.ItemUID == "3" && pVal.BeforeAction==false)
            {
                try
                {
                    int DB = 0;
                    int FD = 0;
                    int UFD = 0;
                    oForm = Packing.SBO_Application.Forms.Item("Initialize");
                    //oForm.Freeze(true);
                    lbl_1 = (SAPbouiCOM.StaticText)(oForm.Items.Item("lbl_1").Specific);
                    lbl_2 = (SAPbouiCOM.StaticText)(oForm.Items.Item("lbl_2").Specific);
                    lbl_3 = (SAPbouiCOM.StaticText)(oForm.Items.Item("lbl_3").Specific);
                    lbl_Status = (SAPbouiCOM.StaticText)(oForm.Items.Item("lbl_Status").Specific);
                    lbl_Status.Caption = "Database table creation in progress...";


                    CreateDataBase();

                    if (CreateDataBase() == true)
                    {
                        lbl_1.Caption = "Add-On database tables created successfully!";
                        DB = 1;
                    }
                    else
                        lbl_1.Caption = "Add-On database tables creation failed ! Contact Admin.";
                    lbl_Status.Caption = "Database fields creation in progress...";

                }
                catch (Exception ex)
                {

                }
            }
            #endregion
        }

        public bool CreateDataBase()
        {
            try
            {
                CreateFields("OCRD");

                //CreateFields("@PGM");                

                //CreateTable("OPCF", "Packing Credit", "Document");
                //CreateFields("@OPCF");

                //CreateTable("OPST", "Program Sheet", "Document");
                //CreateFields("@OPST");

                //CreateTable("PST1", "Program Sheet General", "DocLine");
                //CreateFields("@PST1");

                //CreateTable("PST2", "Program Sheet Design", "DocLine");
                //CreateFields("@PST2");

                //CreateTable("PST3", "Program Sheet Documents", "DocLine");
                //CreateFields("@PST3");

                //CreateTable("PST1D", "Other Detail", "Document");
                //CreateFields("@PST1D");

                //CreateTable("Stage", "Stages", "Master");
                //CreateTable("PORT", "Port", "Master");
                CreateFields("@PORT");


                //CreateTable("OFT", "FULL 5 TAKA REPORT", "Document");
                //CreateTable("OFT1", "FULL 5 TAKA Details", "DocLine");
                //CreateFields("@OFT");
                //CreateFields("@OFT1");
                //CreateUserObject("OFT", "OFT", "OFT", "OFT1", "", "Document");

                //CreateTable("PPS", "Process Packing Slip", "Document");
                //CreateTable("PPS1", "Process Packing Details", "DocLine");
                //CreateFields("@PPS");
                //CreateFields("@PPS1");
                //CreateUserObject("PPS", "PPS", "PPS", "PPS1", "", "Document");

                //CreateTable("PItem", "Party Item List", "Master");
                //CreateFields("@PItem");

                //CreateTable("OPCKDT", "Packing Detail", "Document");
                //CreateFields("@OPCKDT");

                //CreateTable("PCKDT1", "Packing Detail Matrix", "DocLine");
                //CreateFields("@PCKDT1");

                CreateTable("FormSet", "Form Setting", "Master");
                CreateFields("@FormSet");
                CreateTable("FormSet1", "Form Setting Detail 1", "Child");
                CreateFields("@FormSet1");
                CreateTable("FormSet2", "Form Setting Detail 2", "Child");
                CreateFields("@FormSet2");


                CreateTable("TDSLimit", "TDS Limit", "Master");
                CreateFields("@TDSLimit");
                CreateTable("TDSLimit1", "TDS Limit Detail", "Child");
                CreateFields("@TDSLimit1");

                CreateTable("Ready", "Ready Item List", "Document");
                CreateTable("Ready1", "Ready Details", "DocLine");
                CreateFields("@Ready1");
                CreateUserObject("Ready", "Ready", "Ready", "Ready1", "", "Document");

                //CreateUserObject("PGM", "PGM", "PGM", "", "", "Document");
                //CreateUserObject("OPCF", "OPCF", "OPCF", "", "", "Document");
                //CreateUserObject("OPST", "OPST", "OPST", "PST1", "PST2", "Document");
                //CreateUserObject("OSTAGE", "Stage", "Stage", "", "", "Master");
                //CreateUserObject("PORT", "PORT", "PORT", "", "", "Master");
                //CreateUserObject("PItem", "PItem", "PItem", "", "", "Master");
                //CreateUserObject("OPCKDT", "OPCKDT", "OPCKDT", "PCKDT1", "", "Document");
                //CreateUserObject("PST1D", "PST1D", "PST1D", "", "", "Document");

                CreateUserObject("TDSLimit", "TDS Limit", "PST1D", "TDSLimit1", "", "Document");

                CreateTable("Checking", "Checking", "Document");
                CreateTable("Checking1", "Checking Rows", "DocLine");
                CreateFields("@Checking");
                CreateFields("@Checking1");
                CreateUserObject("Checking", "Checking", "Checking", "Checking1", "", "Document");

                return true;
            }
            catch (Exception ex)
            {
               // SBO_Application.StatusBar.SetText(ex.Message.ToString(), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false;
            }

        }

        public bool CreateTable(string TableName, string TableDesc, string TableType)
        {
            try
            {
                int errCode;
                string ErrMsg = null;
                oUserTablesMD = null;
                if (oUserTablesMD == null)
                {
                    oUserTablesMD = ((SAPbobsCOM.UserTablesMD)(Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables)));
                }
                if (oUserTablesMD.GetByKey(TableName) == true)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    return true;
                }
                oUserTablesMD.TableName = TableName;
                oUserTablesMD.TableDescription = TableDesc;
                if (TableType == "Master")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_MasterData;
                }
                else if (TableType == "Child")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_MasterDataLines;
                }
                else if (TableType == "Document")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_Document;
                }
                else if (TableType == "DocLine")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_DocumentLines;
                }
                else if (TableType == "Object")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_NoObject;
                }

                long err = oUserTablesMD.Add();
                if (err != 0)
                {
                    Packing.oCompany.GetLastError(out errCode, out ErrMsg);
                }
                if (err == 0)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    CreateFields(TableName);
                }
                else
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool CreateFields(string TableName)
        {
            try
            {

                #region BP

                if (TableName == "OCRD")
                {
                    FieldDetails(TableName, "IsContr", "Is Contractor", "YesNo", false, 3, "");
                }
                #endregion

                #region Checking

                if (TableName == "@Checking")
                {
                    FieldDetails(TableName, "CardCode", "Contractor Code", "Alpha", false, 40, "");
                    FieldDetails(TableName, "CardName", "Contractor Name", "Alpha", false, 200, "");
                    FieldDetails(TableName, "ITNo", "Inventory Transfer DocNum", "Alpha", false, 20, "");
                    FieldDetails(TableName, "ITDE", "Inventory Transfer DocEntry", "Alpha", false, 20, "");
                    FieldDetails(TableName, "DocDate", "Doc Date", "Date", false, 20, "");
                    FieldDetails(TableName, "YardConv", "Yard Conversion", "Rate", false, 10, "");

                    //FieldDetails(TableName, "BatchNo", "Batch No", "Alpha", false, 72, "");
                }
                if (TableName == "@Checking1")
                {
                    FieldDetails(TableName, "ITLineNo", "IT Line No", "Alpha", false, 5, "");
                    FieldDetails(TableName, "Pcs", "Pcs", "Quantity", false, 10, "");
                    FieldDetails(TableName, "DeclMtr", "Declared Mtr", "Quantity", false, 10, "");
                    FieldDetails(TableName, "RecvMtr", "Received Mtr", "Quantity", false, 10, "");
                    FieldDetails(TableName, "ApprMtr", "Approved Mtr", "Quantity", false, 10, "");
                    FieldDetails(TableName, "OApprMtr", "Open Approved Mtr", "Quantity", false, 10, "");
                    FieldDetails(TableName, "Status", "Status", "Packing_Status", false, 1, "");
                    FieldDetails(TableName, "Yard", "Yard", "Rate", false, 10, "");
                    FieldDetails(TableName, "Remarks", "Remarks", "Alpha", false, 250, "");
                }
                #endregion


                #region @PGM
                if (TableName == "@PGM")
                {
                    FieldDetails(TableName, "Prog_no", "Program No", "Integer", false, 10, "");
                    FieldDetails(TableName, "Buyer_no", "Buyer OrdNo", "Integer", false, 10, "");
                    FieldDetails(TableName, "Itemno", "Item Code", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Itemname", "Item Name", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Quality", "Quality Name", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Sun_cont", "Subcontractor", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Width", "Required Width", "Integer", false, 10, "");
                    FieldDetails(TableName, "Lenght", "Required Lenght", "Integer", false, 10, "");
                    FieldDetails(TableName, "Fold", "Fold", "Alpha", false, 250, "");
                    FieldDetails(TableName, "Process", "Process", "Alpha", false, 250, "");
                    FieldDetails(TableName, "PODE", "Prod Docentry", "Integer", false, 10, "");
                    FieldDetails(TableName, "PODN", "Prod DocNum", "Integer", false, 10, "");

                    FieldDetails("OCRD", "Whse", "Warehouse", "Alpha", false, 250, "");
                    FieldDetails("OCRD", "JobWork", "Job Worker", "YesNo", false, 10, "");
                    FieldDetails("OWOR", "PrgNo", "Program Sheet No", "Integer", false, 10, "");
                    FieldDetails("OWOR", "Process", "Process", "Alpha", false, 250, "");


                    FieldDetails("OPOR", "PrgNo", "Prograam Sheet No", "Alpha", false, 50, "");


                }
#endregion

                #region @OPCF
                if (TableName == "@OPCF")
                {
                    FieldDetails(TableName, "SalConNo", "Sale No", "numeric", false, 10, "");
                    FieldDetails(TableName, "SalDocEnt", "SaleDocEntry", "numeric", false, 10, "");
                    FieldDetails(TableName, "InFavOf", "In Favour of", "Alpha", false, 250, "");
                    FieldDetails(TableName, "PamntTrm", "Payment Term", "Alpha", false, 200, "");
                    FieldDetails(TableName, "CntrctVal", "Contract Value", "Alpha", false, 200, "");
                    FieldDetails(TableName, "ApldAmnt", "Applied Amount", "Amount", false, 200, "");
                    FieldDetails(TableName, "AcntNo", "Account No", "Alpha", false, 50, "");
                    FieldDetails(TableName, "DocNo", "Document  No", "Alpha", false, 20, "");
                    FieldDetails(TableName, "PostDt", "Posting Date", "Date", false, 10, "");
                    FieldDetails(TableName, "CntrctDt", "Contract Date", "Date", false, 10, "");
                    FieldDetails(TableName, "DueDt", "Due Date", "Date", false, 10, "");
                    FieldDetails(TableName, "PrsApldamt", "Prev Amt ", "Amount", false, 20, "");
                    FieldDetails(TableName, "MaxmPcAmt", "Max Amount", "Amount", false, 20, "");
                    FieldDetails(TableName, "Remrk", "Remark", "Alpha", false, 200, "");

                    //FieldDetails("OJDT", "Pcklst", "PackingList", "numeric", false, 10, "");   

                    FieldDetails("PCH1", "SQTY", "Service Quantity", "Quantity", false, 100, "");
                    FieldDetails("PCH1", "SerRATE", "Service Rate", "Rate", false, 100, "");
                    FieldDetails("PCH1", "RecDe", "Receipt DE", "Alpha", false, 100, "");
                    FieldDetails("PCH1", "RecLine", "Receipt Line No", "Alpha", false, 100, "");

                }
                #endregion

                #region program Sheet
                if (TableName == "@OPST")
                {
                    FieldDetails(TableName, "BuyrCde", "Buyer Code", "Alpha", false, 25, "");
                    FieldDetails(TableName, "BuyrName", "Buyer Name", "Alpha", false, 100, "");
                    FieldDetails(TableName, "BuyrOdr", "Buyer Order No", "numeric", false, 10, "");
                    FieldDetails(TableName, "BuyrDoc", "Buyer DocEntNo", "numeric", false, 10, "");
                    FieldDetails(TableName, "BuyrDt", "Buyer Date", "Date", false, 8, "");
                    FieldDetails(TableName, "Series", "Series", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Status", "Status", "Alpha", false, 10, "");
                    FieldDetails(TableName, "PostDt", "Posting date", "Date", false, 8, "");
                    FieldDetails(TableName, "DueDt", "Due Date", "Date", false, 8, "");
                    FieldDetails(TableName, "DueDays", "Due Days", "numeric", false, 10, "");
                    FieldDetails(TableName, "Remrk", "Comments", "Alpha", false, 200, "");

                    FieldDetails(TableName, "icode", "Item Code", "Alpha", false, 100, "");
                    FieldDetails(TableName, "iname", "Item Name", "Alpha", false, 150, "");
                    FieldDetails(TableName, "QTY", "Quantity", "Quantity", false, 100, "");
                    FieldDetails(TableName, "UOM", "UOM", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Process", "Process", "Alpha", false, 100, "");

                    FieldDetails(TableName, "Serial", "Serial No", "Alpha", false, 100, "");
                    FieldDetails("OCRD", "SerialPre", "Serial Prefix", "Alpha", false, 3, "");


                    //29 March 2018
                    FieldDetails(TableName, "ShipCnt", "Country To Ship", "Alpha", false, 100, "");
                    FieldDetails(TableName, "ShipPort", "Shipment Port", "Alpha", false, 100, "");
                    FieldDetails(TableName, "PortNm", "Shipment Port Name", "Alpha", false, 150, "");
                    FieldDetails(TableName, "RefNum", "Buyer Reference No", "Alpha", false, 100, "");
                    FieldDetails(TableName, "RefDt", "Buyer Reference Date", "Date", false, 8, "");
                    FieldDetails(TableName, "Terms", "Terms", "Alpha", false, 250, "");
                    FieldDetails(TableName, "Ship", "Shipment", "Alpha", false, 250, "");
                    FieldDetails(TableName, "Insu", "Insurance", "Alpha", false, 250, "");
                    FieldDetails(TableName, "Payment", "Payment", "Alpha", false, 250, "");
                    FieldDetails(TableName, "Narra", "Narration", "Memo", false, 5000, "");
                }

                else if(TableName == "@PST1")
                {
                    FieldDetails(TableName, "ItmCode", "ItemCode", "Alpha", false, 50, "");
                    FieldDetails(TableName, "ItmsDscr", "Item Description", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Convrsn", "Conversion", "Alpha", false, 5, "");
                    FieldDetails(TableName, "Bales", "Bales", "Quantity", false, 25, "");
                    FieldDetails(TableName, "PCS", "PCS", "Quantity", false, 25, "");
                    FieldDetails(TableName, "Cut", "Cut", "Quantity", false, 25, "");
                    FieldDetails(TableName, "Mtrs", "Mtrs", "Quantity", false, 25, "");
                    FieldDetails(TableName, "Yards", "Yards", "Quantity", false, 25, "");
                    FieldDetails(TableName, "PcsBal", "Pcs Bales", "Quantity", false, 25, "");
                    FieldDetails(TableName, "Vendor", "Vendor", "Alpha", false, 25, "");
                    FieldDetails(TableName, "Whse", "WareHouse", "Alpha", false, 50, "");
                    FieldDetails(TableName, "ReqWidth", "Required width", "Quantity", false, 25, "");
                    FieldDetails(TableName, "ReqLength", "Required length", "Quantity", false, 25, "");
                    FieldDetails(TableName, "Fold", "Fold", "Alpha", false, 30, "");
                    FieldDetails(TableName, "Pck1", "Packing 1", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck2", "Packing 2", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck3", "Packing 3", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck4", "Packing 4", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck5", "Packing 5", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck6", "Packing 6", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck7", "Packing 7", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck8", "Packing 8", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Size", "Size", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Sleves", "Sleves", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Button", "Button", "Alpha", false, 50, "");
                    FieldDetails(TableName, "BagType", "Type of bag", "Alpha", false, 50, "");
                    FieldDetails(TableName, "TotPcs", "Total Pcs", "Alpha", false, 50, "");
                    FieldDetails(TableName, "TP", "TP", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Stamp1", "Stamping1", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Stamp2", "Stamping2", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Stamp3", "Stamping3", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Stamp4", "Stamping4", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Lable", "Lable", "Alpha", false, 50, "");
                    FieldDetails(TableName, "SlvgStyl", "Selvage style", "Alpha", false, 100, "");
                    FieldDetails(TableName, "SlvgUpr", "Selvage Upper", "Alpha", false, 100, "");
                    FieldDetails(TableName, "SlvgLwr", "Selvage Lower", "Alpha", false, 100, "");
                    FieldDetails(TableName, "GenRemrk", "Remark", "Alpha", false, 200, "");
                    FieldDetails(TableName, "GoodIsue", "Goods issue", "Alpha", false, 100, "");
                    FieldDetails(TableName, "GoodRecpt", "Goods Receipt", "Alpha", false, 100, "");

                    FieldDetails(TableName, "Process", "Process", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Vendornm", "Vendor Name", "Alpha", false, 150, "");
                    FieldDetails(TableName, "QTY", "Quantity", "Quantity", false, 100, "");
                    FieldDetails(TableName, "UOM", "UOM", "Alpha", false, 100, "");

                    //29 March 2018
                    FieldDetails(TableName, "YardTMtr", "Yard To Meter", "Quantity", false, 100, "");
                    FieldDetails(TableName, "Curr", "Currency", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Rate", "Rate", "Amount", false, 20, "");
                    FieldDetails(TableName, "Stop", "Stop Program", "Alpha", false, 100, "");
                    FieldDetails(TableName, "DelDt", "Delivery Date", "Date", false, 8, "");
                    FieldDetails(TableName, "DelSch", "Delivery Schedule", "Alpha", false, 200, "");
                    FieldDetails(TableName, "MainItem", "Main Item", "Alpha", false, 200, "");
                    FieldDetails(TableName, "QTYDes", "Quantity Per Design", "Quantity", false, 100, "");
                    FieldDetails(TableName, "ShipMark", "Shipping Mark", "Alpha", false, 200, "");
                    FieldDetails(TableName, "SampType", "Type Of Sample", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Narra", "Narration", "Memo", false, 5000, "");
                    FieldDetails(TableName, "Finish", "Finishing", "Alpha", false, 200, "");
                    FieldDetails(TableName, "TotDes", "Total Designs", "Quantity", false, 20, "");
                    FieldDetails(TableName, "BaleCal", "Bales Calculation", "Quantity", false, 25, "");
                    FieldDetails(TableName, "calcTick", "Calculation Tick", "YN", false, 1, "");


                    FieldDetails(TableName, "OthDet", "Other Details", "Alpha", false, 20, "");
                    FieldDetails(TableName, "RowStat", "Row Status", "Alpha", false, 20, "O");

                    //YN    OthDet
                }
                else if (TableName == "@PST2")
                {
                    FieldDetails(TableName, "DsgNo", "Design No", "numeric", false, 100, "");
                    FieldDetails(TableName, "BalePcs", "Bales/ pcs", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Pcs", "Pcs", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Uom", "UOM", "Alpha", false, 20, "");
                    FieldDetails(TableName, "QtyPrDesg", "Qty per design", "Quantity", false, 50, "");
                    FieldDetails(TableName, "DesgRemrk", "Remark", "Alpha", false, 200, "");
                    FieldDetails(TableName, "DesgImg", "Design Image", "Alpha", false, 200, "");

                }

                #region PST3
                else if (TableName == "@PST3")
                {
                    FieldDetails(TableName, "DocType", "Document Type", "Alpha", false, 100, "");
                    FieldDetails(TableName, "DocE", "Document Entry", "Alpha", false, 50, "");
                    FieldDetails(TableName, "DocN", "Document Number", "Alpha", false, 50, "");
                    FieldDetails(TableName, "BaseLine", "Base Line", "Alpha", false, 50, "");
                    FieldDetails(TableName, "BaseJW", "Base Job Worker", "Alpha", false, 100, "");
                    FieldDetails(TableName, "BaseJWN", "Base Job Worker Name", "Alpha", false, 150, "");
                    //FieldDetails(TableName, "QtyPrDesg", "Qty per design", "Quantity", false, 50, "");
                    //FieldDetails(TableName, "DesgRemrk", "Remark", "Alpha", false, 200, "");
                    //FieldDetails(TableName, "DesgImg", "Design Image", "Alpha", false, 200, "");

                    FieldDetails("OPOR", "PrgShtDE", "Program Sheet Docentry", "Alpha", false, 20, "");
                    FieldDetails("OPOR", "PrgShtDN", "Program Sheet DocNum", "Alpha", false, 20, "");
                    FieldDetails("OPOR", "JobWrkr", "Job Worker Code", "Alpha", false, 50, "");
                    FieldDetails("OPOR", "JobWrkrNm", "Job Worker Name", "Alpha", false, 200, "");
                    FieldDetails("OPOR", "Label", "Label", "Alpha", false, 50, "");
                    FieldDetails("OPOR", "PrgSer", "Program Serial Number", "Alpha", false, 50, "");

                    FieldDetails("POR1", "PrgShtDE", "Program Sheet Docentry", "Alpha", false, 20, "");
                    FieldDetails("POR1", "PrgShtDN", "Program Sheet DocNum", "Alpha", false, 20, "");
                    FieldDetails("POR1", "JobWrkr", "Job Worker Code", "Alpha", false, 50, "");
                    FieldDetails("POR1", "JobWrkrNm", "Job Worker Name", "Alpha", false, 200, "");
                    FieldDetails("POR1", "Label", "Label", "Alpha", false, 50, "");
                    FieldDetails("POR1", "PrgSer", "Program Serial Number", "Alpha", false, 50, "");

                    FieldDetails("PCH1", "POBSEntry", "PO Base Entry", "Integer", false, 10, "");
                    FieldDetails("PCH1", "POBSLine", "PO Base Line", "Integer", false, 10, "");

                    //RateBaseOn
                    FieldDetails("POR1", "RateBaseOn", "Rate Based On", "RateBaseOn", false, 50, "");
                    //Rate
                    FieldDetails("POR1", "SRate", "Second Rate", "Rate", false, 50, "");

                    FieldDetails("OIGE", "PrgShtDE", "Program Sheet Docentry", "Alpha", false, 20, "");
                    FieldDetails("OIGE", "PrgShtDN", "Program Sheet DocNum", "Alpha", false, 20, "");
                    FieldDetails("OIGE", "JobWrkr", "Job Worker Code", "Alpha", false, 50, "");
                    FieldDetails("OIGE", "JobWrkrNm", "Job Worker Name", "Alpha", false, 200, "");
                    FieldDetails("OIGE", "Label", "Label", "Alpha", false, 50, "");
                    FieldDetails("OIGE", "PrgSer", "Program Serial Number", "Alpha", false, 50, "");
                    FieldDetails("IGE1", "PrgShtDE", "Program Sheet Docentry", "Alpha", false, 20, "");
                    FieldDetails("IGE1", "PrgShtDN", "Program Sheet DocNum", "Alpha", false, 20, "");
                    FieldDetails("IGE1", "JobWrkr", "Job Worker Code", "Alpha", false, 50, "");
                    FieldDetails("IGE1", "JobWrkrNm", "Job Worker Name", "Alpha", false, 200, "");
                    FieldDetails("IGE1", "Label", "Label", "Alpha", false, 50, "");
                    FieldDetails("IGE1", "PrgSer", "Program Serial Number", "Alpha", false, 50, "");

                    FieldDetails("OWTQ", "PrgShtDE", "Program Sheet Docentry", "Alpha", false, 20, "");
                    FieldDetails("OWTQ", "PrgShtDN", "Program Sheet DocNum", "Alpha", false, 20, "");
                    FieldDetails("OWTQ", "JobWrkr", "Job Worker Code", "Alpha", false, 50, "");
                    FieldDetails("OWTQ", "JobWrkrNm", "Job Worker Name", "Alpha", false, 200, "");
                    FieldDetails("OWTQ", "Label", "Label", "Alpha", false, 50, "");
                    FieldDetails("OWTQ", "PrgSer", "Program Serial Number", "Alpha", false, 50, "");
                    FieldDetails("WTQ1", "PrgShtDE", "Program Sheet Docentry", "Alpha", false, 20, "");
                    FieldDetails("WTQ1", "PrgShtDN", "Program Sheet DocNum", "Alpha", false, 20, "");
                    FieldDetails("WTQ1", "JobWrkr", "Job Worker Code", "Alpha", false, 50, "");
                    FieldDetails("WTQ1", "JobWrkrNm", "Job Worker Name", "Alpha", false, 200, "");
                    FieldDetails("WTQ1", "Label", "Label", "Alpha", false, 50, "");
                    FieldDetails("WTQ1", "PrgSer", "Program Serial Number", "Alpha", false, 50, "");


                    //31/03/2018
                    //YesNo
                    FieldDetails("OPOR", "CQYN", "Comm to Pay", "YesNo", false, 10, "");
                    FieldDetails("OPOR", "Broker", "Broker", "Alpha", false, 50, "");
                    FieldDetails("OPOR", "PRDT", "Program Date", "Date", false, 20, "");

                    FieldDetails("POR1", "TRANSPRT", "Transporter", "Alpha", false, 150, "");
                    FieldDetails("POR1", "STBALE", "Starting Bale No", "Quantity", false, 20, "");
                    FieldDetails("POR1", "ENBALE", "Ending Bale No", "Quantity", false, 20, "");
                    FieldDetails("POR1", "BALENOS", "Bale Nos", "Alpha", false, 200, "");
                    FieldDetails("POR1", "LRDT", "L.R. Dt.", "Date", false, 20, "");
                    FieldDetails("POR1", "LRNO", "L.R. No", "Alpha", false, 200, "");
                    FieldDetails("POR1", "GCHKPROC", "GREY CHECKING PROC", "Alpha", false, 200, "");
                    FieldDetails("POR1", "PTYCHALL", "Party Challan No", "Alpha", false, 200, "");
                    FieldDetails("POR1", "CHKPCS", "PROC CHECK PCS", "Quantity", false, 20, "");
                    FieldDetails("POR1", "QLTYNM", "QUALITY NAME", "Alpha", false, 200, "");
                    FieldDetails("POR1", "CHKMTRS", "PROC CHECK MTRS", "Quantity", false, 20, "");
                    FieldDetails("POR1", "GWT", "Gross Weight P/Bale", "Quantity", false, 20, "");
                    FieldDetails("POR1", "NWT", "Net Weight P/Bale", "Quantity", false, 20, "");
                    FieldDetails("POR1", "LABLE", "Lable", "Alpha", false, 200, "");
                    FieldDetails("POR1", "Design", "Design no.", "Alpha", false, 200, "");

                    FieldDetails("POR1", "COLOR1", "Color", "Alpha", false, 200, "");
                    FieldDetails("POR1", "LABITEM", "Label Item", "Alpha", false, 200, "");
                    FieldDetails("POR1", "PTYITEM", "PARTY ADDL / MAIN ITEM", "Alpha", false, 200, "");
                    FieldDetails("POR1", "BUYER", "BUYER", "Alpha", false, 200, "");
                    FieldDetails("POR1", "LBALE", "Length-Bale", "Quantity", false, 20, "");
                    FieldDetails("POR1", "BBALE", "Breadth-Bale", "Quantity", false, 20, "");
                    FieldDetails("POR1", "HBALE", "Height-Bale", "Quantity", false, 20, "");



                    FieldDetails("PCH1", "ITEntry", "Inventory Transfer Entry", "Alpha", false, 20, "");
                    FieldDetails("PCH1", "BatchNo", "Batch Number", "Alpha", false,100, "");
                    FieldDetails("PCH1", "CutPcs", "CutPcs", "Quantity", false, 20, "");


                    //FieldDetails("POR1", "", "", "Alpha", false, 200, "");
                    //FieldDetails("POR1", "", "", "Alpha", false, 200, "");
                    //FieldDetails("POR1", "", "", "Alpha", false, 200, "");
                    //FieldDetails("POR1", "", "", "Alpha", false, 200, "");
                    //FieldDetails("POR1", "", "", "Alpha", false, 200, "");
                    //FieldDetails("POR1", "", "", "Alpha", false, 200, "");


                }
                #endregion

                #region Other Detail
                if (TableName == "@PST1D")
                {
                    FieldDetails(TableName, "Curr", "Currency", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Rate", "Rate", "Amount", false, 20, "");
                    FieldDetails(TableName, "Stop", "Stop Program", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Fold", "Fold", "Alpha", false, 30, "");

                    FieldDetails(TableName, "DelDt", "Delivery Date", "Date", false, 8, "");
                    FieldDetails(TableName, "DelSch", "Delivery Schedule", "Alpha", false, 200, "");
                    FieldDetails(TableName, "ReqWidth", "Required width", "Quantity", false, 25, "");
                    FieldDetails(TableName, "ReqLength", "Required length", "Quantity", false, 25, "");


                    FieldDetails(TableName, "Pck1", "Packing 1", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck2", "Packing 2", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck3", "Packing 3", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck4", "Packing 4", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck5", "Packing 5", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck6", "Packing 6", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck7", "Packing 7", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Pck8", "Packing 8", "Alpha", false, 100, "");


                    FieldDetails(TableName, "Size", "Size", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Sleves", "Sleves", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Button", "Button", "Alpha", false, 50, "");
                    FieldDetails(TableName, "BagType", "Type of bag", "Alpha", false, 50, "");


                    FieldDetails(TableName, "QTYDes", "Quantity Per Design", "Quantity", false, 100, "");
                    FieldDetails(TableName, "TotDes", "Total Designs", "Quantity", false, 20, "");
                    FieldDetails(TableName, "TotPcs", "Total Pcs", "Alpha", false, 50, "");
                    FieldDetails(TableName, "TP", "TP", "Alpha", false, 50, "");

                    FieldDetails(TableName, "Stamp1", "Stamping1", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Stamp2", "Stamping2", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Stamp3", "Stamping3", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Stamp4", "Stamping4", "Alpha", false, 100, "");

                    FieldDetails(TableName, "Lable", "Lable", "Alpha", false, 50, "");
                    FieldDetails(TableName, "Finish", "Finishing", "Alpha", false, 200, "");
                    FieldDetails(TableName, "ShipMark", "Shipping Mark", "Alpha", false, 200, "");
                    FieldDetails(TableName, "SampType", "Type Of Sample", "Alpha", false, 200, "");

                    FieldDetails(TableName, "SlvgStyl", "Selvage style", "Alpha", false, 100, "");
                    FieldDetails(TableName, "SlvgUpr", "Selvage Upper", "Alpha", false, 100, "");
                    FieldDetails(TableName, "SlvgLwr", "Selvage Lower", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Narra", "Narration", "Memo", false, 5000, "");
                }

                #endregion
                #endregion

                #region Full 5 taka report
                if (TableName == "@OFT")
                {
                    FieldDetails(TableName, "Date", "Date", "Date", false, 10, "");
                    FieldDetails(TableName, "TrnNo", "Trnsctn No.", "Alpha", false, 100, "");
                    FieldDetails(TableName, "IsuInvNo", "Isue Invic No", "Alpha", false, 100, "");
                    
                    FieldDetails(TableName, "AvgWt", "Avg Wt", "Quantity", false, 100, "");
                    FieldDetails(TableName, "LotNo", "Lot No", "Alpha", false, 100, "");
                    FieldDetails(TableName, "TakRprtDt", "TakRprt Date", "Date", false, 10, "");
                    FieldDetails(TableName, "BllNo", "Bill No", "Alpha", false, 100, "");
                    FieldDetails(TableName, "SperNme", "Supler Nme", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Brokr", "Broker", "Alpha", false, 100, "");

                    FieldDetails(TableName, "PtyNme", "Party Name", "Alpha", false, 100, "");
                    FieldDetails(TableName, "LR_No", "LR No", "Alpha", false, 100, "");
                    FieldDetails(TableName, "LR_Dt", "LR Dt", "Date", false, 10, "");

                    FieldDetails(TableName, "StpLot", "Stop Lot", "YN", false, 1, "");
                    FieldDetails(TableName, "LotDt", "Lot Date", "Date", false, 10, "");
                    FieldDetails(TableName, "FRptRdDt", "Ful Rpt Rvd Dt", "Date", false, 10, "");
                    FieldDetails(TableName, "BilDt", "Bill Dt", "Date", false, 10, "");
                    FieldDetails(TableName, "Isue_Itm", "Isue Itm", "Alpha", false, 100, "");

                    FieldDetails(TableName, "PrgShtDE", "Program Sheet Docentry", "Alpha", false, 20, "");
                    FieldDetails(TableName, "Linenum", "PS Linenum", "Integer", false, 10, "");

                    FieldDetails(TableName, "PTYCHALL", "Party Challan No", "Alpha", false, 200, "");
                    FieldDetails(TableName, "INVTNO", "Inventory Trf No", "Alpha", false, 200, "");
                    FieldDetails(TableName, "batch", "Batch Number", "Alpha", false, 200, "");
                    //FieldDetails(TableName, "Isue_Itm", "Isue Itm", "Alpha", false, 100, "");
                    //FieldDetails(TableName, "Isue_Itm", "Isue Itm", "Alpha", false, 100, "");
                    //FieldDetails(TableName, "Isue_Itm", "Isue Itm", "Alpha", false, 100, "");
                }

                if (TableName == "@OFT1")
                {
                    FieldDetails(TableName, "Mtr", "Meter", "Quantity", false, 50, "");
                    FieldDetails(TableName, "Wght", "Weight", "Quantity", false, 50, "");
                    FieldDetails(TableName, "WtPerMtr", "Weight Per Meter", "Quantity", false, 50, "");
                }
                #endregion

                #region PORT , OBTN , OWTR
                if (TableName == "@PORT")
                {
                    FieldDetails(TableName, "Country", "Country", "Alpha", false, 100, "");


                    FieldDetails("OBTN", "TRANSPRT", "Transporter", "Alpha", false, 150, "");
                    FieldDetails("OBTN", "LRDT", "L.R. Dt.", "Date", false, 20, "");
                    FieldDetails("OBTN", "LRNO", "L.R. No", "Alpha", false, 200, "");
                    FieldDetails("OBTN", "PTYCHALL", "Party Challan No", "Alpha", false, 200, "");
                    
                    FieldDetails("OBTN", "StpLot", "Stop Lot", "YN", false, 1, "");
                    FieldDetails("OBTN", "Pcs", "Pieces", "Quantity", false, 20, "");
                    FieldDetails("OBTN", "FRptRdDt", "Full Report Dt", "Date", false, 20, "");
                    //U_
                    FieldDetails("OBTN", "PTYCHALL", "Party Challan No", "Alpha", false, 200, "");

                    FieldDetails("OBTN", "STBALE", "Starting Bale No", "Quantity", false, 20, "");
                    FieldDetails("OBTN", "ENBALE", "Ending Bale No", "Quantity", false, 20, "");


                    FieldDetails("OWTR", "TRANSPRT", "Transporter", "Alpha", false, 150, "");
                    FieldDetails("OWTR", "LRDT", "L.R. Dt.", "Date", false, 20, "");
                    FieldDetails("OWTR", "LRNO", "L.R. No", "Alpha", false, 200, "");
                    FieldDetails("OWTR", "PTYCHALL", "Party Challan No", "Alpha", false, 200, "");
                    FieldDetails("OWTR", "FiveTaka", "5 Taka Report", "Alpha", false, 20, "");




                    FieldDetails("OWTR", "APDOCE", "AP Invoice Docentry", "Alpha", false, 150, "");
                    FieldDetails("OWTR", "APDOCL", "AP Invoice LineNum", "Alpha", false, 150, "");
                    FieldDetails("OPCH", "STDOCE", "Stock Transfer Docentry", "Alpha", false, 150, "");

                    FieldDetails("WTR1", "BaseType", "IT Base Type", "Alpha", false, 150, "");
                    
                    FieldDetails("OIGN", "EType", "Entry Type", "EType", false, 30, "");
                    FieldDetails("OIGN", "RecNum", "Receipt No", "Alpha", false, 30, "");
                    FieldDetails("OIGN", "RecDN", "Receipt DocNum", "Alpha", false, 40, "");

                    FieldDetails("OIGN", "Batch", "Batch Number", "Alpha", false, 100, "");
                    FieldDetails("OIGN", "LOTNO", "Lot No", "Alpha", false, 100, "");
                    FieldDetails("OIGN", "PackList", "Packing List", "Alpha", false, 100, "");
                }
                #endregion

                #region Process Packing Slip
                if (TableName == "@PPS")
                {
                    FieldDetails(TableName, "TotGrey", "Total Grey", "Quantity", false, 20, "");
                    FieldDetails(TableName, "TotFin", "Total Finished", "Quantity", false, 20, "");
                    FieldDetails(TableName, "TotPiece", "Total Piece", "Quantity", false, 20, "");
                    FieldDetails(TableName, "ICode", "Item Code", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Iname", "Item name", "Alpha", false, 150, "");
                    FieldDetails(TableName, "Whse", "Warehouse", "Alpha", false, 100, "");
                    //FieldDetails(TableName, "Country", "Country", "Alpha", false, 100, "");

                    FieldDetails("OIGN", "Proc", "Process No", "Alpha", false, 100, "");
                }
                if (TableName == "@PPS1")
                {
                    FieldDetails(TableName, "LotNo", "Lot No", "Alpha", false, 150, "");
                    FieldDetails(TableName, "batchno", "Batch No", "Alpha", false, 150, "");
                    FieldDetails(TableName, "GreyMtr", "Grey Mtr", "Quantity", false, 20, "");
                    FieldDetails(TableName, "FINMtr", "Fin Mtr", "Quantity", false, 20, "");
                    FieldDetails(TableName, "Pcs", "Pieces", "Quantity", false, 20, "1");
                    FieldDetails(TableName, "AvlQty", "Available QTY", "Quantity", false, 20, "");
                    FieldDetails(TableName, "AvlPcs", "Available Pcs", "Quantity", false, 20, "");

                    FieldDetails("OIGN", "ExcQty", "Excess QTY", "Alpha", false, 20, "");
                }
                #endregion

                #region @PItem
                if (TableName == "@PItem")
                {
                    FieldDetails(TableName, "Active", "Active", "YN", false, 1, "");
                }
                #endregion

                #region Packing Detail
                if (TableName == "@OPCKDT")
                {

                    FieldDetails(TableName, "BuyrOdr", "Buyer Order No", "numeric", false, 10, "");
                    FieldDetails(TableName, "Jobwrk", "JobWorker", "Alpha", false, 50, "");
                    FieldDetails(TableName, "JobWrkrNm", "Job Worker Name", "Alpha", false, 200, "");
                    FieldDetails(TableName, "PrmNo", "Program No", "Integer", false, 10, "");
                    FieldDetails(TableName, "Quality", "Quality", "Alpha", false, 200, "");
                    FieldDetails(TableName, "SlvgUpr", "Selvage Upper", "Alpha", false, 100, "");
                    FieldDetails(TableName, "SlvgLwr", "Selvage Lower", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Remrk", "Comments", "Alpha", false, 200, "");
                    FieldDetails(TableName, "ItmCode", "ItemCode", "Alpha", false, 50, "");
                    FieldDetails(TableName, "ItmsDscr", "Item Description", "Alpha", false, 200, "");
                    FieldDetails(TableName, "YardTMtr", "Yard To Meter", "Quantity", false, 100, "0.9144");
                    
                   


                }
                else if (TableName == "@PCKDT1")
                {



                    FieldDetails(TableName, "DsgNo", "Design No", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Match", "Matching", "Alpha", false, 50, "");
                    FieldDetails(TableName, "BaleFrom", "Bales No From", "Integer", false, 10, "");
                    FieldDetails(TableName, "BaleTo", "Bales No To", "Integer", false, 10, "");
                    FieldDetails(TableName, "Bales", "Bales", "Quantity", false, 25, "");
                    FieldDetails(TableName, "Pcs", "PCS", "Quantity", false, 50, "");
                    FieldDetails(TableName, "CutPcs", "Cut Pcs", "Quantity", false, 50, "");

                    FieldDetails(TableName, "Mtrs", "Mtrs", "Quantity", false, 25, "");
                    FieldDetails(TableName, "Yards", "Yards", "Quantity", false, 25, "");

                    FieldDetails(TableName, "QTY", "Quantity", "Quantity", false, 100, "");
                    FieldDetails(TableName, "calcTick", "Calculation Tick", "YN", false, 1, "Y");
                    FieldDetails(TableName, "PcsBal", "Pcs Bales", "Quantity", false, 25, "");
                    FieldDetails(TableName, "BaleCal", "Bales Calculation", "Quantity", false, 25, "");
                    FieldDetails(TableName, "PrgNo", "Program no No", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Cut", "Cut", "Quantity", false, 25, "");
                    FieldDetails(TableName, "PcsBal", "Pcs Bales", "Quantity", false, 25, "");
                    FieldDetails(TableName, "Serial", "Serial No", "Alpha", false, 100, "");

                    FieldDetails(TableName, "Lable", "Lable", "Alpha", false, 50, "");

                   



                }

                #endregion

                #region Form Setting
                if (TableName == "@FormSet")
                {
                    FieldDetails("OPOR", "FormSet", "Form Setting", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Type", "Type", "Alpha", false, 200, "");
                    FieldDetails(TableName, "matrix", "Matrix Item ID", "Alpha", false, 200, "");
                    FieldDetails(TableName, "ObjType", "Object", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Series", "Series", "Alpha", false, 200, "");
                    FieldDetails(TableName, "SerCmb", "Series Combo", "Alpha", false, 20, "");
                    FieldDetails(TableName, "Account", "Account Code", "Alpha", false, 200, "");

                    FieldDetails("OCHP", "IGST", "IGST Tax Code", "Alpha", false, 50, "");
                    FieldDetails("OCHP", "CGST", "CGST & SGST Tax Code", "Alpha", false, 50, "");

                    FieldDetails("OSAC", "IGST", "IGST Tax Code", "Alpha", false, 50, "");
                    FieldDetails("OSAC", "CGST", "CGST & SGST Tax Code", "Alpha", false, 50, "");
                    


                }
                if (TableName == "@FormSet1")
                {
                    FieldDetails(TableName, "Type", "Type", "Alpha", false, 200, "");
                    FieldDetails(TableName, "TDesc", "Type Description", "Alpha", false, 200, "");
                }
                if (TableName == "@FormSet2")
                {
                    FieldDetails(TableName, "FieldName", "Field Name", "Alpha", false, 200, "");
                    FieldDetails(TableName, "FieldID", "Field ID", "Alpha", false, 200, "");
                    FieldDetails(TableName, "Enable", "Enabled", "YN", false, 2, "");
                }
                #endregion


                #region @TDSLimit
                if (TableName == "@TDSLimit1")
                {
                    FieldDetails(TableName, "FromDt", "From Date", "Date", false, 20, "");
                    FieldDetails(TableName, "ToDt", "To Date", "Date", false, 20, "");
                    FieldDetails(TableName, "CertNo", "Certificate No", "Alpha", false, 10, "");
                    FieldDetails(TableName, "CertDt", "Certificate Date", "Date", false, 20, "");
                    FieldDetails(TableName, "LowerLim", "Lower Limit", "Amount", false, 20, "");
                    FieldDetails(TableName, "TDSCd", "TDS Code", "Alpha", false, 50, "");

                }

                #endregion

                #region @Ready1
                if (TableName == "@Ready1")
                {
                    FieldDetails(TableName, "Split", "Split", "Alpha", false, 100, "");
                    FieldDetails(TableName, "PODE", "PO Docentry", "Alpha", false, 100, "");
                    FieldDetails(TableName, "PODNum", "PO Docnum", "Alpha", false, 100, "");
                    FieldDetails(TableName, "Broker", "Broker", "Alpha", false, 150, "");
                    FieldDetails(TableName, "IName", "Item Description", "Alpha", false, 150, "");
                    FieldDetails(TableName, "QTY", "QTY", "Quantity", false, 20, "");
                    FieldDetails(TableName, "Bale", "Bale", "Quantity", false, 20, "");
                    FieldDetails(TableName, "Pcs", "Pcs", "Quantity", false, 20, "");
                    FieldDetails(TableName, "Yards", "Yards", "Quantity", false, 20, "");

                    FieldDetails(TableName, "PackNo", "Packing List No", "Alpha", false, 100, "");
                    FieldDetails(TableName, "POLine", "PO Line", "Alpha", false, 100, "");
                }

                #endregion

                return true;
            }
            catch (Exception ex)
            {
                Packing.SBO_Application.MessageBox(ex.Message.ToString(), 1, "ok", "", "");
                return false;
            }
        }

        public bool FieldDetails(string TableName, string FieldName, string FieldDesc, string FieldType, bool Mandatory, int FieldSize, string DefaultVal)
        {
            string ErrMsg;
            int errCode;
            int IRetCode;
            oUserFieldsMD = null;
            SAPbobsCOM.Recordset oRecordSet = null;
            try
            {
                if (oUserFieldsMD == null)
                {
                    oUserFieldsMD = ((SAPbobsCOM.UserFieldsMD)(Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields)));
                }
                oUserFieldsMD.TableName = TableName;
                oUserFieldsMD.Name = FieldName;
                oUserFieldsMD.Description = FieldDesc;

                switch (FieldType)
                {
                    case "Alpha":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;
                        break;
                    case "Memo":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Memo; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;
                        break;
                    case "Link":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Memo;
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Link;
                        break;
                    
                    case "Integer":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Numeric; //  Integer type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_None;
                        oUserFieldsMD.EditSize = FieldSize;
                        break;
                    case "Quantity":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // 
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Quantity;
                        oUserFieldsMD.EditSize = FieldSize;
                        break;
                    
                    case "Date":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Date; // Date type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_None;
                        break;
                    case "Hour":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Date;
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Time; //Time
                        break;
                    case "Amount":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Sum; // Amount type
                        break;
                    case "Percent":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Percentage; // Amount type
                        break;
                    case "UnitTotal":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Measurement; // Amount type
                        break;
                    case "Rate":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Rate; // Amount type
                        break;
                    case "EType":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "-";
                        oUserFieldsMD.ValidValues.Description = "-";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Yarn";
                        oUserFieldsMD.ValidValues.Description = "Yarn";
                        oUserFieldsMD.ValidValues.Add();
                        
                        oUserFieldsMD.ValidValues.Value = "Process";
                        oUserFieldsMD.ValidValues.Description = "Process";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "ProcessDetail";
                        oUserFieldsMD.ValidValues.Description = "Process Details";
                        oUserFieldsMD.ValidValues.Add();
                        //Yarn

                        oUserFieldsMD.ValidValues.Value = "Printing";
                        oUserFieldsMD.ValidValues.Description = "Printing";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Stiching";
                        oUserFieldsMD.ValidValues.Description = "Stiching";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Packing";
                        oUserFieldsMD.ValidValues.Description = "Packing";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "-";
                        break;

                    case "RateBaseOn":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Mtr";
                        oUserFieldsMD.ValidValues.Description = "Meters";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Bale";
                        oUserFieldsMD.ValidValues.Description = "Bales";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Pcs";
                        oUserFieldsMD.ValidValues.Description = "Pieces";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Yard";
                        oUserFieldsMD.ValidValues.Description = "Yards";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "Mtr";
                        break;
                    case "stock_Status":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Open";
                        oUserFieldsMD.ValidValues.Description = "Open";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Close";
                        oUserFieldsMD.ValidValues.Description = "Close";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Cancel";
                        oUserFieldsMD.ValidValues.Description = "Cancel";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "Open";
                        break;

                    case "Packing_Status":

                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "R";
                        oUserFieldsMD.ValidValues.Description = "Reject";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "F";
                        oUserFieldsMD.ValidValues.Description = "RF";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "S";
                        oUserFieldsMD.ValidValues.Description = "Shortage";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "A";
                        oUserFieldsMD.ValidValues.Description = "Approved";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "H";
                        oUserFieldsMD.ValidValues.Description = "Hold";
                        oUserFieldsMD.ValidValues.Add();

                        break;

                    case "SelMode":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "FIFO";
                        oUserFieldsMD.ValidValues.Description = "FIFO";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "MANUAL";
                        oUserFieldsMD.ValidValues.Description = "MANUAL";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "FIFO";
                        break;
                    case "Grade":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "+ve";
                        oUserFieldsMD.ValidValues.Description = "+ve";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "-ve";
                        oUserFieldsMD.ValidValues.Description = "-ve";
                        oUserFieldsMD.ValidValues.Add();


                        oUserFieldsMD.ValidValues.Value = "";
                        oUserFieldsMD.ValidValues.Description = "";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;
                    case "RSelf":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Ref";
                        oUserFieldsMD.ValidValues.Description = "Ref";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Self";
                        oUserFieldsMD.ValidValues.Description = "Self";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;
                    case "Region":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "OUR";
                        oUserFieldsMD.ValidValues.Description = "OUR REGION";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "DEALER";
                        oUserFieldsMD.ValidValues.Description = "DEALER REGION";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "OUR";
                        break;

                    case "SrcTyp":

                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "OUR";
                        oUserFieldsMD.ValidValues.Description = "OUR";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "AGENCY";
                        oUserFieldsMD.ValidValues.Description = "AGENCY";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "OUR";
                        break;

                    case "YesNo":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Yes";
                        oUserFieldsMD.ValidValues.Description = "YES";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "No";
                        oUserFieldsMD.ValidValues.Description = "NO";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "No";
                        break;

                    //  new SRK //
                    //CRM FORM A//

                    case "RecycleDuct":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Recycle";
                        oUserFieldsMD.ValidValues.Description = "Recycle";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Duct";
                        oUserFieldsMD.ValidValues.Description = "Duct";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;



                    case "ExistingNew":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Existing";
                        oUserFieldsMD.ValidValues.Description = "Existing";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "New";
                        oUserFieldsMD.ValidValues.Description = "New";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;


                    case "CookTopCookHob":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Cook Top";
                        oUserFieldsMD.ValidValues.Description = "Cook Top";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Cook Hob";
                        oUserFieldsMD.ValidValues.Description = "Cook Hob";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;


                    case "OpenBuiltIn":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Open";
                        oUserFieldsMD.ValidValues.Description = "Open";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "BuiltIn";
                        oUserFieldsMD.ValidValues.Description = "BuiltIn";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;

                    case "OpnBltInTopFrnt":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Open";
                        oUserFieldsMD.ValidValues.Description = "Open";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Built In";
                        oUserFieldsMD.ValidValues.Description = "Built In";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Top";
                        oUserFieldsMD.ValidValues.Description = "Top";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Front";
                        oUserFieldsMD.ValidValues.Description = "Front";
                        oUserFieldsMD.ValidValues.Add();



                        oUserFieldsMD.DefaultValue = "";
                        break;
                    case "NOAGV":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Not Good";
                        oUserFieldsMD.ValidValues.Description = "Not Good";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "OK";
                        oUserFieldsMD.ValidValues.Description = "OK";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Average";
                        oUserFieldsMD.ValidValues.Description = "Average";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Good";
                        oUserFieldsMD.ValidValues.Description = "Good";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Very Good";
                        oUserFieldsMD.ValidValues.Description = "Very Good";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";

                        break;
                    case "StdAloneBuiltIn":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Stand Alone";
                        oUserFieldsMD.ValidValues.Description = "Stand Alone";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Built In";
                        oUserFieldsMD.ValidValues.Description = "Built In";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;
                    //CRM FORM A//

                    //FORMA2//


                    case "CompletePending":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Complete";
                        oUserFieldsMD.ValidValues.Description = "Complete";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Pending";
                        oUserFieldsMD.ValidValues.Description = "Pending";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;

                    case "SideBack":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Side";
                        oUserFieldsMD.ValidValues.Description = "Side";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Back";
                        oUserFieldsMD.ValidValues.Description = "Back";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;

                    case "WallFloor":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Wall";
                        oUserFieldsMD.ValidValues.Description = "Wall";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Floor";
                        oUserFieldsMD.ValidValues.Description = "Floor";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;
                    case "Rea":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "REA";
                        oUserFieldsMD.ValidValues.Description = "REA";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "DB";
                        oUserFieldsMD.ValidValues.Description = "DB";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "OBB";
                        oUserFieldsMD.ValidValues.Description = "OBB";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Other";
                        oUserFieldsMD.ValidValues.Description = "Other";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;
                    case "MKGF":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Marble";
                        oUserFieldsMD.ValidValues.Description = "Marble";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Kadappa";
                        oUserFieldsMD.ValidValues.Description = "Kadappa";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Granite";
                        oUserFieldsMD.ValidValues.Description = "Granite";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Floor Tile";
                        oUserFieldsMD.ValidValues.Description = "Floor Tile";
                        oUserFieldsMD.ValidValues.Add();



                        oUserFieldsMD.DefaultValue = "";
                        break;

                    case "MKP":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Marble";
                        oUserFieldsMD.ValidValues.Description = "Marble";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Kadappa";
                        oUserFieldsMD.ValidValues.Description = "Kadappa";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Ply";
                        oUserFieldsMD.ValidValues.Description = "Ply";
                        oUserFieldsMD.ValidValues.Add();


                        oUserFieldsMD.DefaultValue = "";
                        break;

                    case "Age":

                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "21 to 30";
                        oUserFieldsMD.ValidValues.Description = "21 yrs to 30 yrs";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "31 to 40";
                        oUserFieldsMD.ValidValues.Description = "31 yrs to 40 yrs";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "41 to 50";
                        oUserFieldsMD.ValidValues.Description = "41 yrs to 50 yrs";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "51 yrs & above";
                        oUserFieldsMD.ValidValues.Description = "51 yrs & above";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;

                    //FORMA2//
                    //  new SRK //

                    case "YN":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Y";
                        oUserFieldsMD.ValidValues.Description = "Yes";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "N";
                        oUserFieldsMD.ValidValues.Description = "No";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "N";
                        break;

                    case "MainSrc":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "IB";
                        oUserFieldsMD.ValidValues.Description = "Internet Business";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "RT";
                        oUserFieldsMD.ValidValues.Description = "Retail";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "AC";
                        oUserFieldsMD.ValidValues.Description = "Accounts";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "IB";
                        break;

                    case "Catlog":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                              
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "1";
                        oUserFieldsMD.ValidValues.Description = "Soft Copy";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "2";
                        oUserFieldsMD.ValidValues.Description = "Hard Copy";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "3";
                        oUserFieldsMD.ValidValues.Description = "Both";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "4";
                        oUserFieldsMD.ValidValues.Description = "No Catlouge";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "4";

                        break;

                    case "RateFor":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha;
                        oUserFieldsMD.Size = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "LOCAL";
                        oUserFieldsMD.ValidValues.Description = "LOCAL";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "FOREIGN";
                        oUserFieldsMD.ValidValues.Description = "FOREIGN";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "BD";
                        oUserFieldsMD.ValidValues.Description = "BD";
                        oUserFieldsMD.ValidValues.Add();

                        break;
                    case "Status":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "O";
                        oUserFieldsMD.ValidValues.Description = "Open";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "C";
                        oUserFieldsMD.ValidValues.Description = "Closed";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Can";
                        oUserFieldsMD.ValidValues.Description = "Cancelled";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "O";
                        break;
                    case "DefValues":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "P";
                        oUserFieldsMD.ValidValues.Description = "Planned";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "R";
                        oUserFieldsMD.ValidValues.Description = "Release";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "P";
                        break;

                    case "POStatus":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "O";
                        oUserFieldsMD.ValidValues.Description = "Open";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "C";
                        oUserFieldsMD.ValidValues.Description = "Closed";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "O";
                        break;
                    case "PO":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Y";
                        oUserFieldsMD.ValidValues.Description = "Yes";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "N";
                        oUserFieldsMD.ValidValues.Description = "No";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "Y";
                        break;
                    case "Lock":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "P";
                        oUserFieldsMD.ValidValues.Description = "Planned";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "U";
                        oUserFieldsMD.ValidValues.Description = "UnPlanned";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "U";
                        break;
                    case "Process":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "RM";
                        oUserFieldsMD.ValidValues.Description = "REGULAR";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "TL";
                        oUserFieldsMD.ValidValues.Description = "TOLLING";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "RM";
                        break;

                    
                    case "PaymentType"://Pravin
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Booking";
                        oUserFieldsMD.ValidValues.Description = "Booking";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Booking with 50%";
                        oUserFieldsMD.ValidValues.Description = "Booking with 50%";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Order Raising";
                        oUserFieldsMD.ValidValues.Description = "Order Raising";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Dispatch";
                        oUserFieldsMD.ValidValues.Description = "Dispatch";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Appliances";
                        oUserFieldsMD.ValidValues.Description = "Appliances";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;

                    case "PaymentMode"://Pravin
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "A/C Transfer";
                        oUserFieldsMD.ValidValues.Description = "A/C Transfer";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Card";
                        oUserFieldsMD.ValidValues.Description = "Card";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Cash";
                        oUserFieldsMD.ValidValues.Description = "Cash";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Cheque";
                        oUserFieldsMD.ValidValues.Description = "Cheque";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Finance";
                        oUserFieldsMD.ValidValues.Description = "Finance";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Collected by Brand";
                        oUserFieldsMD.ValidValues.Description = "Collected by Brand";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "";
                        break;

                    case "PayDesc"://Pravin
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Add";
                        oUserFieldsMD.ValidValues.Description = "Add";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Subtract";
                        oUserFieldsMD.ValidValues.Description = "Subtract";
                        oUserFieldsMD.ValidValues.Add();

                        break;


                }
                if (Mandatory)
                {
                    oUserFieldsMD.Mandatory = SAPbobsCOM.BoYesNoEnum.tYES;
                }
                if (DefaultVal != "")
                {
                    oUserFieldsMD.DefaultValue = DefaultVal;
                }

                // Add the field to the table
                IRetCode = oUserFieldsMD.Add();
                if (IRetCode != 0)
                {
                    Packing.oCompany.GetLastError(out errCode, out ErrMsg);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserFieldsMD);
                oUserFieldsMD = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        public void CreateUserObject(string CodeID, string Name, string TableName, string Child, string Child1, string Type) //used for registration of user defined table
        {
            int lRetCode = 0;
            string sErrMsg = null;

            oUserObjectMD = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();

            if (oUserObjectMD == null)
                oUserObjectMD = ((SAPbobsCOM.UserObjectsMD)(Packing.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)));

            oUserObjectMD.Code = CodeID;
            oUserObjectMD.Name = Name;
            oUserObjectMD.TableName = TableName;

            if (Type == "Master")
            {
                oUserObjectMD.ObjectType = SAPbobsCOM.BoUDOObjType.boud_MasterData;
                oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
                oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tNO;
                oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
                oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tNO;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tNO;
            }
            //else if (Type == "Master_Mat")
            //{
            //    oUserObjectMD.ObjectType = SAPbobsCOM.BoUDOObjType.boud_MasterData;
            //    oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
            //    oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tNO;
            //    oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
            //    oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tNO;
            //    oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tNO;
            //    oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;
            //    oUserObjectMD.CanCreateDefaultForm.
            //}
            else if (Type == "Document")
            {
                oUserObjectMD.ObjectType = SAPbobsCOM.BoUDOObjType.boud_Document;
                oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
                oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tNO;
                oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
                oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tNO;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }

            //services 

            oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;

            if (Child != "")
            {
                oUserObjectMD.ChildTables.TableName = Child;
                oUserObjectMD.ChildTables.Add();
            }
            if (Child1 != "")
            {
                oUserObjectMD.ChildTables.TableName = Child1;
                oUserObjectMD.ChildTables.Add();
            }

            
            // check for errors in the process
            lRetCode = oUserObjectMD.Add();

            // check for errors in the process
            if (lRetCode != 0)
                if (lRetCode == -1)
                { }
                else
                { Packing.oCompany.GetLastError(out lRetCode, out sErrMsg); }
            else
            { }

            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
            oUserObjectMD = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }


        
    }
}
